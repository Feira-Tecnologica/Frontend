-- Script para atualizar banco de dados para sistema A1/A2
-- Execute este script no phpMyAdmin ou MySQL

USE banco_feira;

-- Adicionar campo para identificar se é Avaliador 1 ou Avaliador 2
ALTER TABLE `nota` ADD COLUMN `avaliador_numero` TINYINT(1) DEFAULT 1 
COMMENT 'Identifica se é Avaliador 1 ou Avaliador 2 (1 ou 2)';

-- Adicionar campo para armazenar a menção final do projeto
ALTER TABLE `projeto` ADD COLUMN `mencao_final` VARCHAR(2) NULL 
COMMENT 'Menção final do projeto baseada na média das avaliações (I, R, B, MB)';

-- Adicionar campo para armazenar a média final do projeto
ALTER TABLE `projeto` ADD COLUMN `media_final` DECIMAL(3,1) NULL 
COMMENT 'Média final do projeto calculada a partir das avaliações A1 e A2';

-- Remover a restrição antiga que permitia apenas uma nota por professor/projeto
-- e criar nova restrição que permite 2 avaliadores por projeto
ALTER TABLE `nota` DROP INDEX IF EXISTS `unique_professor_projeto`;

-- Criar nova constraint única que permite no máximo 2 avaliações por projeto
-- mas garante que cada avaliador (1 ou 2) só avalie uma vez por projeto
ALTER TABLE `nota` ADD UNIQUE KEY `unique_avaliador_projeto` (`id_projeto`, `avaliador_numero`);

-- Atualizar dados existentes (marcar todas as notas atuais como Avaliador 1)
UPDATE `nota` SET `avaliador_numero` = 1 WHERE `avaliador_numero` IS NULL;

-- Criar view para facilitar consultas de projetos com status de avaliação
CREATE OR REPLACE VIEW `view_status_avaliacoes` AS
SELECT 
    p.id_projeto,
    p.titulo_projeto,
    p.media_final,
    p.mencao_final,
    COUNT(n.id_nota) as total_avaliacoes,
    CASE 
        WHEN COUNT(n.id_nota) = 0 THEN 'Aguardando Avaliação'
        WHEN COUNT(n.id_nota) = 1 THEN 'Avaliação Parcial (1/2)'
        WHEN COUNT(n.id_nota) = 2 THEN 'Avaliação Completa (2/2)'
        ELSE 'Erro - Mais de 2 avaliações'
    END as status_avaliacao,
    ROUND(AVG(n.media), 2) as media_calculada,
    GROUP_CONCAT(
        CONCAT('A', n.avaliador_numero, ': ', prof.nome_professor) 
        ORDER BY n.avaliador_numero 
        SEPARATOR ', '
    ) as avaliadores
FROM projeto p
LEFT JOIN nota n ON n.id_projeto = p.id_projeto
LEFT JOIN professor prof ON prof.id_professor = n.id_professor
GROUP BY p.id_projeto, p.titulo_projeto, p.media_final, p.mencao_final;

-- Inserir alguns dados de exemplo para demonstrar o funcionamento
-- (Remova este bloco se não quiser dados de teste)
/*
-- Exemplo: Projeto 1 com duas avaliações
INSERT INTO nota (criatividade, capricho, abordagem, dominio, postura, oralidade, organizacao, media, comentario, id_professor, id_projeto, avaliador_numero) 
VALUES 
    (8.0, 7.5, 8.5, 7.0, 8.0, 7.5, 8.0, 7.8, 'Ótimo projeto, parabéns!', 'PROF001', 1, 1),
    (7.5, 8.0, 7.0, 8.5, 7.5, 8.0, 7.5, 7.7, 'Projeto bem executado!', 'PROF002', 1, 2)
ON DUPLICATE KEY UPDATE 
    criatividade = VALUES(criatividade),
    capricho = VALUES(capricho),
    abordagem = VALUES(abordagem),
    dominio = VALUES(dominio),
    postura = VALUES(postura),
    oralidade = VALUES(oralidade),
    organizacao = VALUES(organizacao),
    media = VALUES(media),
    comentario = VALUES(comentario);
*/

-- Verificar o resultado
SELECT 'Estrutura atualizada com sucesso!' as status;
SELECT * FROM view_status_avaliacoes LIMIT 5;