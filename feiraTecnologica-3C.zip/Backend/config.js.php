<?php
header('Content-Type: application/javascript; charset=UTF-8');

// Ler .env a partir da raiz do projeto (um nível acima de Backend)
$envPath = __DIR__ . '/../.env';
$env = [];
if (file_exists($envPath)) {
    $parsed = parse_ini_file($envPath);
    if ($parsed !== false) {
        $env = $parsed;
    }
}

// Configuração mais robusta com fallbacks
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$basePath = '/feira_tecnologica_avaliacoes/Backend';

// Usar configuração do .env se disponível, senão usar configuração automática
$base = isset($env['base_url']) ? rtrim($env['base_url'], '/') : $protocol . '://' . $host . $basePath;
$base_escaped = str_replace("'", "\\'", $base);

// Variáveis JS expostas globalmente
echo "// Gerado por Backend/config.js.php - não editar manualmente\n";
echo "window.BASE_URL = '{$base_escaped}';\n";
echo "window.API_BASE = window.BASE_URL;\n";
echo "console.log('Configuração carregada: BASE_URL =', window.BASE_URL);\n";

?>
