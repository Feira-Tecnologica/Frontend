<?php
class ODSController {
    public function listarODS() {
        try {
            require_once __DIR__ . '/../Config/connection.php';

            $stmt = $conn->prepare("SELECT * FROM ods ORDER BY id_ods");
            $stmt->execute();

            $ods = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Garantir encoding UTF-8 correto
            foreach ($ods as &$item) {
                foreach ($item as $key => $value) {
                    if (is_string($value)) {
                        // Tentar converter de latin1 para UTF-8 se necessário
                        if (!mb_check_encoding($value, 'UTF-8')) {
                            $item[$key] = mb_convert_encoding($value, 'UTF-8', 'latin1');
                        }
                    }
                }
            }

            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode($ods, JSON_UNESCAPED_UNICODE);
            
        } catch (Exception $e) {
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(500);
            echo json_encode([
                'erro' => 'Erro interno do servidor',
                'mensagem' => $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
        }
    }
}
?>