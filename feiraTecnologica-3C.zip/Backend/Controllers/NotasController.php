<?php

class NotasController
{
    public function cadastroNota()
    {
        require_once __DIR__ . '/../Config/connection.php';

        $dados = json_decode(file_get_contents('php://input'), true);

        $criatividade = floatval($dados['criatividade'] ?? null);
        $capricho = floatval($dados['capricho'] ?? null);
        $abordagem = floatval($dados['abordagem'] ?? null);
        $dominio = floatval($dados['dominio'] ?? null);
        $postura = floatval($dados['postura'] ?? null);
        $oralidade = floatval($dados['oralidade'] ?? null);
        $organizacao = floatval($dados['organizacao'] ?? null);
        $comentario = $dados['comentario'] ?? '';
        $id_professor = $dados['id_professor'] ?? '';
        $id_projeto = $dados['id_projeto'] ?? '';

        if (
            is_null($criatividade) ||
            is_null($capricho) ||
            is_null($abordagem) ||
            is_null($dominio) ||
            is_null($postura) ||
            is_null($oralidade) ||
            is_null($organizacao) ||
            empty($id_professor) ||
            empty($id_projeto) 
        ) {
            http_response_code(400);
            echo json_encode(["erro" => "Preencha todas as notas obrigatórias."]);
            return;
        }

        try {
            // Verificar quantas avaliações já existem para este projeto
            $stmtCount = $conn->prepare("SELECT COUNT(*) as total FROM nota WHERE id_projeto = :id_projeto");
            $stmtCount->bindParam(':id_projeto', $id_projeto);
            $stmtCount->execute();
            $totalAvaliacoes = $stmtCount->fetch(PDO::FETCH_ASSOC)['total'];

            // Verificar se este professor já avaliou este projeto
            $stmtCheck = $conn->prepare("SELECT id_nota, avaliador_numero FROM nota WHERE id_professor = :id_professor AND id_projeto = :id_projeto");
            $stmtCheck->bindParam(':id_professor', $id_professor);
            $stmtCheck->bindParam(':id_projeto', $id_projeto);
            $stmtCheck->execute();
            $notaExistente = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            // Cálculo da média
            $media = round(($criatividade + $capricho + $abordagem + $dominio + $postura + $oralidade + $organizacao) / 7, 1);

            if ($notaExistente) {
                // Atualizar nota existente (mantém o mesmo número de avaliador)
                $stmt = $conn->prepare("
                    UPDATE nota SET 
                        criatividade = :criatividade, 
                        capricho = :capricho, 
                        abordagem = :abordagem, 
                        dominio = :dominio, 
                        postura = :postura, 
                        oralidade = :oralidade, 
                        organizacao = :organizacao, 
                        media = :media, 
                        comentario = :comentario
                    WHERE id_professor = :id_professor AND id_projeto = :id_projeto
                ");
                $operacao = "atualizada";
                $avaliador_numero = $notaExistente['avaliador_numero'];
            } else {
                // Verificar se já há 2 avaliações (limite máximo)
                if ($totalAvaliacoes >= 2) {
                    http_response_code(400);
                    echo json_encode(["erro" => "Este projeto já possui o máximo de 2 avaliações permitidas."]);
                    return;
                }

                // Determinar se será Avaliador 1 ou 2
                $avaliador_numero = $totalAvaliacoes + 1;

                // Inserir nova nota
                $stmt = $conn->prepare("
                    INSERT INTO nota (
                        criatividade, capricho, abordagem, dominio, postura, oralidade, comentario, organizacao, media, id_professor, id_projeto, avaliador_numero
                    ) VALUES (
                        :criatividade, :capricho, :abordagem, :dominio, :postura, :oralidade, :comentario, :organizacao, :media, :id_professor, :id_projeto, :avaliador_numero
                    )
                ");
                $operacao = "cadastrada";
                $stmt->bindParam(':avaliador_numero', $avaliador_numero);
            }

            // Bind dos parâmetros
            $stmt->bindParam(':criatividade', $criatividade);
            $stmt->bindParam(':capricho', $capricho);
            $stmt->bindParam(':abordagem', $abordagem);
            $stmt->bindParam(':dominio', $dominio);
            $stmt->bindParam(':postura', $postura);
            $stmt->bindParam(':oralidade', $oralidade);
            $stmt->bindParam(':organizacao', $organizacao);
            $stmt->bindParam(':media', $media);
            $stmt->bindParam(':id_professor', $id_professor);
            $stmt->bindParam(':id_projeto', $id_projeto);
            $stmt->bindParam(':comentario', $comentario);

            if ($stmt->execute()) {
                // Verificar se agora temos 2 avaliações para calcular média final
                $stmtFinalCount = $conn->prepare("SELECT COUNT(*) as total FROM nota WHERE id_projeto = :id_projeto");
                $stmtFinalCount->bindParam(':id_projeto', $id_projeto);
                $stmtFinalCount->execute();
                $totalFinal = $stmtFinalCount->fetch(PDO::FETCH_ASSOC)['total'];

                $mensagem = "Nota {$operacao} com sucesso como Avaliador {$avaliador_numero}.";
                
                if ($totalFinal == 2) {
                    // Calcular e salvar média final e menção no projeto
                    $stmtMedias = $conn->prepare("SELECT AVG(media) as media_final FROM nota WHERE id_projeto = :id_projeto");
                    $stmtMedias->bindParam(':id_projeto', $id_projeto);
                    $stmtMedias->execute();
                    $mediaFinalResult = $stmtMedias->fetch(PDO::FETCH_ASSOC);
                    $mediaFinal = round($mediaFinalResult['media_final'], 1);
                    $mencaoFinal = $this->calcularMencao($mediaFinal);
                    
                    // Atualizar tabela projeto com média final e menção
                    $stmtUpdateProjeto = $conn->prepare("
                        UPDATE projeto 
                        SET media_final = :media_final, mencao_final = :mencao_final 
                        WHERE id_projeto = :id_projeto
                    ");
                    $stmtUpdateProjeto->bindParam(':media_final', $mediaFinal);
                    $stmtUpdateProjeto->bindParam(':mencao_final', $mencaoFinal);
                    $stmtUpdateProjeto->bindParam(':id_projeto', $id_projeto);
                    $stmtUpdateProjeto->execute();
                    
                    $mensagem .= " Projeto agora possui avaliação completa (A1 + A2). Média final: {$mediaFinal} - Menção: {$mencaoFinal}.";
                } else {
                    $mensagem .= " Aguardando avaliação do segundo avaliador.";
                }

                http_response_code(201);
                echo json_encode([
                    "mensagem" => $mensagem,
                    "media" => $media,
                    "avaliador_numero" => $avaliador_numero,
                    "avaliacoes_completas" => $totalFinal == 2
                ]);
            } else {
                http_response_code(500);
                echo json_encode(["erro" => "Erro ao {$operacao} nota."]);
            }

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }

    public function buscarNota()
    {
        require_once __DIR__ . '/../Config/connection.php';

        $dados = json_decode(file_get_contents('php://input'), true);
        $id_professor = $dados['id_professor'] ?? '';
        $id_projeto = $dados['id_projeto'] ?? '';

        if (empty($id_professor) || empty($id_projeto)) {
            http_response_code(400);
            echo json_encode(["erro" => "ID do professor e projeto são obrigatórios."]);
            return;
        }

        try {
            $stmt = $conn->prepare("
                SELECT criatividade, capricho, abordagem, dominio, postura, oralidade, organizacao, media, comentario, avaliador_numero
                FROM nota 
                WHERE id_professor = :id_professor AND id_projeto = :id_projeto
            ");
            $stmt->bindParam(':id_professor', $id_professor);
            $stmt->bindParam(':id_projeto', $id_projeto);
            $stmt->execute();

            $nota = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($nota) {
                // Verificar quantas avaliações existem para este projeto
                $stmtCount = $conn->prepare("SELECT COUNT(*) as total FROM nota WHERE id_projeto = :id_projeto");
                $stmtCount->bindParam(':id_projeto', $id_projeto);
                $stmtCount->execute();
                $totalAvaliacoes = $stmtCount->fetch(PDO::FETCH_ASSOC)['total'];

                $nota['total_avaliacoes'] = $totalAvaliacoes;
                $nota['avaliacoes_completas'] = $totalAvaliacoes == 2;
                
                echo json_encode($nota);
            } else {
                // Verificar se já existem 2 avaliações (projeto completo)
                $stmtCount = $conn->prepare("SELECT COUNT(*) as total FROM nota WHERE id_projeto = :id_projeto");
                $stmtCount->bindParam(':id_projeto', $id_projeto);
                $stmtCount->execute();
                $totalAvaliacoes = $stmtCount->fetch(PDO::FETCH_ASSOC)['total'];

                if ($totalAvaliacoes >= 2) {
                    http_response_code(400);
                    echo json_encode(["erro" => "Este projeto já possui o máximo de 2 avaliações permitidas."]);
                } else {
                    http_response_code(404);
                    echo json_encode([
                        "mensagem" => "Nenhuma nota encontrada.",
                        "pode_avaliar" => true,
                        "sera_avaliador" => $totalAvaliacoes + 1
                    ]);
                }
            }

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }

    /**
     * Lista projetos com status de avaliação para o professor logado (opcional) ou geral.
     * Retorna média (global do projeto calculada pela média das médias dos professores) e status.
     */
    public function listarProjetosComNotas()
    {
        require_once __DIR__ . '/../Config/connection.php';

        // Permitir filtragem opcional por professor (via query string ?id_professor=...)
        $id_professor = isset($_GET['id_professor']) ? $_GET['id_professor'] : null;

        try {
            if ($id_professor) {
                // Consulta específica para um professor - mostra todos os projetos e se ele já avaliou
                $sql = "
                    SELECT 
                        p.id_projeto,
                        p.titulo_projeto,
                        p.posicao,
                        p.turma,
                        p.orientador,
                        GROUP_CONCAT(DISTINCT a.nome_aluno ORDER BY a.nome_aluno SEPARATOR ', ') AS integrantes,
                        COUNT(DISTINCT n_all.id_nota) AS qtd_avaliacoes_total,
                        n_prof.avaliador_numero as meu_avaliador_numero,
                        CASE 
                            WHEN n_prof.id_nota IS NOT NULL THEN 'Já Avaliado por Mim'
                            WHEN COUNT(DISTINCT n_all.id_nota) >= 2 THEN 'Completo (2/2)'
                            ELSE CONCAT('Disponível (', COUNT(DISTINCT n_all.id_nota), '/2)')
                        END AS status_avaliacao,
                        ROUND(AVG(DISTINCT n_all.media),1) AS media_projeto,
                        n_prof.media as minha_nota
                    FROM projeto p
                    LEFT JOIN projeto_aluno pa ON pa.id_projeto = p.id_projeto
                    LEFT JOIN aluno a ON a.id_aluno = pa.id_aluno
                    LEFT JOIN nota n_all ON n_all.id_projeto = p.id_projeto
                    LEFT JOIN nota n_prof ON n_prof.id_projeto = p.id_projeto AND n_prof.id_professor = :id_professor
                    GROUP BY p.id_projeto
                    ORDER BY 
                        CASE 
                            WHEN n_prof.id_nota IS NULL AND COUNT(DISTINCT n_all.id_nota) < 2 THEN 1
                            ELSE 2
                        END,
                        p.titulo_projeto ASC
                ";
                
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':id_professor', $id_professor);
            } else {
                // Consulta geral - overview de todos os projetos
                $sql = "
                    SELECT 
                        p.id_projeto,
                        p.titulo_projeto,
                        p.posicao,
                        p.turma,
                        p.orientador,
                        GROUP_CONCAT(DISTINCT a.nome_aluno ORDER BY a.nome_aluno SEPARATOR ', ') AS integrantes,
                        COALESCE(nota_count.qtd_avaliacoes, 0) AS qtd_avaliacoes_total,
                        ROUND(nota_count.media_projeto, 1) AS media_projeto,
                        CASE 
                            WHEN COALESCE(nota_count.qtd_avaliacoes, 0) = 0 THEN 'Aguardando Avaliação (0/2)'
                            WHEN COALESCE(nota_count.qtd_avaliacoes, 0) = 1 THEN 'Avaliação Parcial (1/2)'
                            WHEN COALESCE(nota_count.qtd_avaliacoes, 0) = 2 THEN 'Avaliação Completa (2/2)'
                            ELSE CONCAT('Erro - Excesso de Avaliações (', COALESCE(nota_count.qtd_avaliacoes, 0), ')')
                        END AS status_avaliacao,
                        nota_count.avaliadores
                    FROM projeto p
                    LEFT JOIN projeto_aluno pa ON pa.id_projeto = p.id_projeto
                    LEFT JOIN aluno a ON a.id_aluno = pa.id_aluno
                    LEFT JOIN (
                        SELECT 
                            n.id_projeto,
                            COUNT(n.id_nota) as qtd_avaliacoes,
                            AVG(n.media) as media_projeto,
                            GROUP_CONCAT(
                                CONCAT('A', n.avaliador_numero, ': ', prof.nome_professor) 
                                ORDER BY n.avaliador_numero 
                                SEPARATOR ', '
                            ) as avaliadores
                        FROM nota n
                        LEFT JOIN professor prof ON prof.id_professor = n.id_professor
                        GROUP BY n.id_projeto
                    ) nota_count ON nota_count.id_projeto = p.id_projeto
                    GROUP BY p.id_projeto, p.titulo_projeto, p.posicao, p.turma, p.orientador, 
                             nota_count.qtd_avaliacoes, nota_count.media_projeto, nota_count.avaliadores
                    ORDER BY 
                        COALESCE(nota_count.qtd_avaliacoes, 0) ASC,
                        p.titulo_projeto ASC
                ";
                
                $stmt = $conn->prepare($sql);
            }

            $stmt->execute();
            $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            http_response_code(200);
            echo json_encode($projetos, JSON_UNESCAPED_UNICODE);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }

    /**
     * Busca notas detalhadas dos projetos do aluno
     */
    public function buscarNotasDoAluno()
    {
        require_once __DIR__ . '/../Config/connection.php';

        $id_aluno = isset($_GET['id_aluno']) ? $_GET['id_aluno'] : null;

        if (empty($id_aluno)) {
            http_response_code(400);
            echo json_encode(["erro" => "ID do aluno é obrigatório."]);
            return;
        }

        try {
            // Buscar todos os projetos do aluno (seja como criador ou integrante)
            $sql = "
                SELECT 
                    p.id_projeto,
                    p.titulo_projeto,
                    p.descricao,
                    p.turma,
                    p.orientador,
                    p.posicao,
                    p.media_final,
                    p.mencao_final,
                    prof.nome_professor as nome_orientador
                FROM projeto p
                LEFT JOIN professor prof ON p.orientador = prof.id_professor
                WHERE p.criador_id = :id_aluno
                   OR p.id_projeto IN (
                       SELECT pa.id_projeto 
                       FROM projeto_aluno pa 
                       WHERE pa.id_aluno = :id_aluno2
                   )
                ORDER BY p.titulo_projeto ASC
            ";

            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':id_aluno', $id_aluno);
            $stmt->bindParam(':id_aluno2', $id_aluno);
            $stmt->execute();

            $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Para cada projeto, buscar suas avaliações
            foreach ($projetos as &$projeto) {
                $sqlNotas = "
                    SELECT 
                        n.criatividade,
                        n.capricho,
                        n.abordagem,
                        n.dominio,
                        n.postura,
                        n.oralidade,
                        n.organizacao,
                        n.media,
                        n.comentario,
                        n.avaliador_numero,
                        prof.nome_professor
                    FROM nota n
                    INNER JOIN professor prof ON prof.id_professor = n.id_professor
                    WHERE n.id_projeto = :id_projeto
                    ORDER BY n.avaliador_numero ASC
                ";
                
                $stmtNotas = $conn->prepare($sqlNotas);
                $stmtNotas->bindParam(':id_projeto', $projeto['id_projeto']);
                $stmtNotas->execute();
                
                $projeto['avaliacoes'] = $stmtNotas->fetchAll(PDO::FETCH_ASSOC);
                
                // Determinar status e usar dados já calculados do banco
                $qtdAvaliacoes = count($projeto['avaliacoes']);
                
                if ($qtdAvaliacoes == 2) {
                    // Projeto completamente avaliado - usar dados do banco ou calcular se necessário
                    if ($projeto['media_final'] !== null && $projeto['mencao_final'] !== null) {
                        // Usar dados já salvos no banco
                        $projeto['media_final'] = (float) $projeto['media_final'];
                        // mencao_final já vem do banco, não precisa reatribuir
                    } else {
                        // Calcular e salvar no banco (caso não tenha sido salvo ainda)
                        $somaMedias = array_sum(array_column($projeto['avaliacoes'], 'media'));
                        $projeto['media_final'] = round($somaMedias / 2, 1);
                        $projeto['mencao_final'] = $this->calcularMencao($projeto['media_final']);
                        
                        // Salvar no banco
                        $stmtUpdate = $conn->prepare("
                            UPDATE projeto 
                            SET media_final = :media_final, mencao_final = :mencao_final 
                            WHERE id_projeto = :id_projeto
                        ");
                        $stmtUpdate->bindParam(':media_final', $projeto['media_final']);
                        $stmtUpdate->bindParam(':mencao_final', $projeto['mencao_final']);
                        $stmtUpdate->bindParam(':id_projeto', $projeto['id_projeto']);
                        $stmtUpdate->execute();
                    }
                    $projeto['status_avaliacao'] = 'Avaliação Completa (A1 + A2)';
                    $projeto['avaliacoes_completas'] = true;
                } elseif ($qtdAvaliacoes == 1) {
                    // Projeto parcialmente avaliado
                    $projeto['media_final'] = null;
                    $projeto['mencao_final'] = null;
                    $projeto['status_avaliacao'] = 'Avaliação Parcial (1/2)';
                    $projeto['avaliacoes_completas'] = false;
                } else {
                    // Projeto não avaliado
                    $projeto['media_final'] = null;
                    $projeto['mencao_final'] = null;
                    $projeto['status_avaliacao'] = 'Aguardando Avaliação (0/2)';
                    $projeto['avaliacoes_completas'] = false;
                }
                
                $projeto['qtd_avaliacoes'] = $qtdAvaliacoes;
            }

            http_response_code(200);
            echo json_encode($projetos, JSON_UNESCAPED_UNICODE);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }

    /**
     * Calcula a menção baseada na média final
     * @param float $media A média final do projeto
     * @return string A menção (I, R, B, MB)
     */
    private function calcularMencao($media)
    {
        if ($media >= 7.6) return "MB"; // Muito Bom
        if ($media >= 5.1) return "B";  // Bom
        if ($media >= 2.6) return "R";  // Regular
        return "I"; // Insuficiente
    }
}
