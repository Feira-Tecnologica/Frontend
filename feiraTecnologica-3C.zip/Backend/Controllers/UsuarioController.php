<?php
 class UsuarioController{
    public function listarUsuarios() {
        require_once __DIR__ . '/../Config/connection.php';

        $turma = $_GET['turma'] ?? '';

        $stmt = $conn->prepare("SELECT * FROM aluno WHERE id_aluno LIKE :turma AND disponivel = true");
        $stmt->bindValue(':turma', $turma . "_%");
        $stmt->execute();

        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($usuarios, JSON_UNESCAPED_UNICODE);
    }

    public function listarProfessores() {
        require_once __DIR__ . '/../Config/connection.php';

        try {
            $stmt = $conn->prepare("SELECT id_professor, nome_professor, email FROM professor ORDER BY nome_professor ASC");
            $stmt->execute();

            $professores = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode($professores, JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro ao buscar professores: " . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
    }
 }
?>