-- Script de atualização adicional para sistema A1/A2
-- Execute este script APÓS ter executado o update_banco_sistema_a1_a2.sql principal
-- Este script adiciona as colunas de média final e menção final

USE banco_feira;

-- Verificar se as colunas já existem antes de adicionar
SET @sql = 'SELECT COUNT(*) INTO @col_exists FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "projeto" AND COLUMN_NAME = "mencao_final"';
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Adicionar campo para armazenar a menção final do projeto (se não existir)
SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE `projeto` ADD COLUMN `mencao_final` VARCHAR(2) NULL COMMENT "Menção final do projeto baseada na média das avaliações (I, R, B, MB)"',
    'SELECT "Coluna mencao_final já existe" as status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verificar se a coluna media_final já existe
SET @sql = 'SELECT COUNT(*) INTO @col_exists FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "projeto" AND COLUMN_NAME = "media_final"';
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Adicionar campo para armazenar a média final do projeto (se não existir)
SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE `projeto` ADD COLUMN `media_final` DECIMAL(3,1) NULL COMMENT "Média final do projeto calculada a partir das avaliações A1 e A2"',
    'SELECT "Coluna media_final já existe" as status');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Recriar a view com os novos campos
DROP VIEW IF EXISTS `view_status_avaliacoes`;

CREATE VIEW `view_status_avaliacoes` AS
SELECT 
    p.id_projeto,
    p.titulo_projeto,
    p.media_final,
    p.mencao_final,
    COUNT(n.id_nota) as total_avaliacoes,
    CASE 
        WHEN COUNT(n.id_nota) = 0 THEN 'Aguardando Avaliação'
        WHEN COUNT(n.id_nota) = 1 THEN 'Avaliação Parcial (1/2)'
        WHEN COUNT(n.id_nota) = 2 THEN 'Avaliação Completa (2/2)'
        ELSE 'Erro - Mais de 2 avaliações'
    END as status_avaliacao,
    ROUND(AVG(n.media), 2) as media_calculada,
    GROUP_CONCAT(
        CONCAT('A', n.avaliador_numero, ': ', prof.nome_professor) 
        ORDER BY n.avaliador_numero 
        SEPARATOR ', '
    ) as avaliadores
FROM projeto p
LEFT JOIN nota n ON n.id_projeto = p.id_projeto
LEFT JOIN professor prof ON prof.id_professor = n.id_professor
GROUP BY p.id_projeto, p.titulo_projeto, p.media_final, p.mencao_final;

-- Calcular e atualizar médias finais e menções para projetos que já têm 2 avaliações
UPDATE projeto p 
SET 
    media_final = (
        SELECT ROUND(AVG(n.media), 1)
        FROM nota n 
        WHERE n.id_projeto = p.id_projeto
        HAVING COUNT(*) = 2
    ),
    mencao_final = (
        SELECT CASE 
            WHEN ROUND(AVG(n.media), 1) >= 7.6 THEN 'MB'
            WHEN ROUND(AVG(n.media), 1) >= 5.1 THEN 'B'
            WHEN ROUND(AVG(n.media), 1) >= 2.6 THEN 'R'
            ELSE 'I'
        END
        FROM nota n 
        WHERE n.id_projeto = p.id_projeto
        HAVING COUNT(*) = 2
    )
WHERE (
    SELECT COUNT(*) 
    FROM nota n 
    WHERE n.id_projeto = p.id_projeto
) = 2;

-- Verificar o resultado
SELECT 'Atualização adicional concluída com sucesso!' as status;
SELECT 'Projetos com média final calculada:' as info, COUNT(*) as quantidade 
FROM projeto WHERE media_final IS NOT NULL;

-- Mostrar alguns exemplos
SELECT 
    id_projeto,
    titulo_projeto,
    media_final,
    mencao_final,
    (SELECT COUNT(*) FROM nota WHERE nota.id_projeto = projeto.id_projeto) as total_avaliacoes
FROM projeto 
WHERE media_final IS NOT NULL 
LIMIT 5;