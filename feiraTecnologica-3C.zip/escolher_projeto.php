<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolher projeto</title>
    <link rel="stylesheet" href="css/styleB.css">
    <link rel="stylesheet" href="css/escolher_projeto.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- Simplify Material Icons import -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body>
    <?php session_start(); ?>



    <div class="container">
        <img src="img/topo.png" alt="Elemento decorativo" class="top-vector">
        <img src="img/etec-logo.png" alt="Logo ETEC" class="logo">

        <div class="content-container">
            <div class="header-section">
                <div class="saudacao-container">
                    <h2 id="saudacao"></h2>
                    <a href="dashboard_aluno.html" class="dashboard-link" id="dashboard-link">
                        <i class="material-icons">dashboard</i>
                        <span>Meu Dashboard</span>
                    </a>
                </div>
            </div>
            <h3 style="text-align: left; color: black; margin-left: 2.5%;">Projetos</h3>

            <div class="controls">
                <div class="search">
                    <span class="material-icons" style="color: #672D91;">search</span>
                    <input type="text" placeholder="Pesquisar projeto...">
                </div>

                <div class="controls-actions">
                    <button class="btn-create" onclick="location.href='criar_projeto.html'">CRIAR PROJETO</button>
                    <button class="btn-logout" onclick="logout()" title="Sair">SAIR</button>
                </div>
            </div>

            <!-- Os cards de projetos serão inseridos aqui dinamicamente pelo JavaScript -->
            <div class="projects-grid" aria-live="polite"></div>

            <h3 style="text-align: left; color: black; margin-left: 2.5%; margin-bottom: 2%;">Suas Publicações</h3>
            <div class="pub-grid"></div>
            <button class="btn-create" onclick="location.href='CadImagem.php'">CRIAR PUBLICAÇÃO</button>
        </div>

            <!-- Modal de Logout (Escolher Projeto) -->
            <div id="logoutModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <i class="material-icons warning-icon">exit_to_app</i>
                        <h2>Confirmar Saída</h2>
                    </div>
                    <div class="modal-body">
                        <p>Tem certeza que deseja sair do sistema?</p>
                    </div>
                    <div class="modal-footer">
                        <button onclick="confirmarLogout()" class="btn-modal btn-sim">Sim, Sair</button>
                        <button onclick="cancelarLogout()" class="btn-modal btn-nao">Cancelar</button>
                    </div>
                </div>
            </div>

        <script src="Backend/config.js.php"></script>
        <script src="js/escolher_projeto.js"></script>
</body>

</html>