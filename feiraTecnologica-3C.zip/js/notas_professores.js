// Variáveis globais
let projetoAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    const btnConfirmar = document.getElementById('btnConfirmar');
    const confirmModal = document.getElementById('confirmModal');
    const successModal = document.getElementById('successModal');
    const btnSim = document.getElementById('btnSim');
    const btnNao = document.getElementById('btnNao');
    const btnOk = document.getElementById('btnOk');

    // Carregar informações do projeto (pode vir da URL ou localStorage)
    carregarProjeto();

    // Adicionar listeners para cálculo de média em tempo real
    const inputs = document.querySelectorAll('.form-control');
    inputs.forEach(input => {
        input.addEventListener('input', calcularMediaTempo);
        input.addEventListener('change', calcularMediaTempo);
    });

    // Abrir o modal quando clicar em "Confirmar"
    btnConfirmar.addEventListener('click', function() {
        if (validarNotas()) {
            atualizarPreviewMedia();
            confirmModal.classList.add('show');
        }
    });

    // Fechar o modal quando clicar em "Não"
    btnNao.addEventListener('click', function() {
        confirmModal.classList.remove('show');
    });

    // Quando clicar em "Sim"
    btnSim.addEventListener('click', function() {
        enviarNotas();
    });

    // Quando clicar em "OK" no modal de sucesso
    btnOk.addEventListener('click', function() {
        successModal.classList.remove('show');
        // Redirecionar para dashboard principal
        window.location.href = 'dash-prof.html';
    });

    // Fechar os modais se clicar fora deles
    window.addEventListener('click', function(event) {
        if (event.target === confirmModal) {
            confirmModal.classList.remove('show');
        }
        if (event.target === successModal) {
            successModal.classList.remove('show');
        }
    });
});

function carregarProjeto() {
    // Verificar se há um ID de projeto na URL ou localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const idProjeto = urlParams.get('id') || localStorage.getItem('projeto_avaliacao');
    
    if (idProjeto) {
        buscarDadosProjeto(idProjeto);
    } else {
        // Se não há projeto específico, pode carregar uma lista ou mostrar erro
        console.warn('Nenhum projeto selecionado para avaliação');
    }
}

async function buscarDadosProjeto(idProjeto) {
    try {
        console.log('Buscando projeto com ID:', idProjeto);
        
        // Buscar todos os projetos e filtrar pelo ID
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const [projetosResponse, alunosResponse] = await Promise.all([
            fetch(apiBase + '/api/projetos'),
            fetch(apiBase + '/api/projetos/alunos', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id_projeto: idProjeto })
            })
        ]);

        if (!projetosResponse.ok) {
            throw new Error(`Erro HTTP: ${projetosResponse.status}`);
        }

        const responseText = await projetosResponse.text();
        console.log('Resposta da API projetos:', responseText);

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (e) {
            console.error('Erro ao parsear JSON:', e);
            throw new Error('Resposta inválida do servidor');
        }

        // Normalizar o formato da resposta
        let projetos = [];
        if (Array.isArray(data)) {
            projetos = data;
        } else if (data && Array.isArray(data.data)) {
            projetos = data.data;
        } else if (data && Array.isArray(data.projetos)) {
            projetos = data.projetos;
        }

        // Encontrar o projeto pelo ID
        projetoAtual = projetos.find(p => String(p.id_projeto) === String(idProjeto));
        
        if (projetoAtual) {
            console.log('Projeto encontrado:', projetoAtual);
            
            // Buscar alunos do projeto
            let alunos = [];
            if (alunosResponse.ok) {
                alunos = await alunosResponse.json();
                console.log('Alunos do projeto:', alunos);
            }
            
            atualizarInterfaceProjeto(alunos);
            // Carregar notas existentes se houver
            carregarNotasExistentes();
        } else {
            console.error('Projeto não encontrado com ID:', idProjeto);
            alert('Projeto não encontrado');
        }

    } catch (error) {
        console.error('Erro ao buscar dados do projeto:', error);
        alert('Erro ao carregar dados do projeto: ' + error.message);
    }
}

function atualizarInterfaceProjeto(alunos = []) {
    if (!projetoAtual) return;

    console.log('Atualizando interface com projeto:', projetoAtual);

    // Atualizar título do projeto
    const tituloElement = document.getElementById('titulo-projeto');
    if (tituloElement) {
        tituloElement.innerHTML = `<strong>${projetoAtual.titulo_projeto || 'Projeto sem título'}</strong>`;
    }

    // Atualizar informações do stand
    const standElement = document.getElementById('stand-info');
    if (standElement) {
        standElement.textContent = `Stand: ${projetoAtual.posicao || 'N/A'}`;
    }

    // Atualizar informações da turma
    const turmaElement = document.getElementById('turma-info');
    if (turmaElement) {
        turmaElement.textContent = `Turma: ${projetoAtual.turma || 'N/A'}`;
    }

    // Atualizar informações do orientador
    const orientadorElement = document.getElementById('orientador-info');
    if (orientadorElement) {
        orientadorElement.textContent = `Orientador: ${projetoAtual.orientador || 'N/A'}`;
    }

    // Atualizar lista de alunos
    const alunosElement = document.getElementById('lista-alunos');
    if (alunosElement) {
        if (alunos && alunos.length > 0) {
            alunosElement.innerHTML = alunos.map(aluno => 
                `<span class="aluno-nome">${aluno.nome_aluno}</span>`
            ).join(', ');
        } else {
            alunosElement.textContent = 'Nenhum aluno cadastrado';
        }
    }

    // Atualizar descrição do projeto
    const descricaoElement = document.getElementById('descricao-projeto');
    if (descricaoElement) {
        descricaoElement.textContent = projetoAtual.descricao || 'Sem descrição disponível';
    }
}

async function carregarNotasExistentes() {
    const usuarioLogado = JSON.parse(localStorage.getItem('usuario_logado') || sessionStorage.getItem('usuario') || '{}');
    const usuario = usuarioLogado.usuario || usuarioLogado;
    const idProfessor = usuario.id_professor || usuario.id;
    
    if (!idProfessor || !projetoAtual) {
        return;
    }

    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/notas/buscar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id_professor: idProfessor,
                id_projeto: projetoAtual.id_projeto
            })
        });

        if (response.ok) {
            const nota = await response.json();
            console.log('Nota existente encontrada:', nota);
            preencherFormularioComNotas(nota);
            atualizarStatusAvaliacao(nota);
        } else if (response.status === 404) {
            const errorData = await response.json();
            console.log('Resposta 404:', errorData);
            
            if (errorData.sera_avaliador) {
                atualizarStatusAvaliacao({
                    sera_avaliador: errorData.sera_avaliador,
                    pode_avaliar: errorData.pode_avaliar
                });
            }
        } else if (response.status === 400) {
            // Projeto já tem 2 avaliações
            const errorData = await response.json();
            mostrarProjetoCompleto(errorData.erro);
        } else {
            console.error('Erro ao buscar notas existentes');
        }
    } catch (error) {
        console.error('Erro ao carregar notas existentes:', error);
    }
}

function atualizarStatusAvaliacao(dados) {
    const statusElement = document.getElementById('status-avaliacao');
    const avaliadorElement = document.getElementById('meu-avaliador');
    
    if (!statusElement || !avaliadorElement) return;
    
    // Atualizar status baseado nos dados recebidos
    if (dados.avaliador_numero) {
        // Professor já avaliou
        statusElement.innerHTML = `<span>Status: Já Avaliado</span>`;
        statusElement.className = 'status-badge completo';
        
        avaliadorElement.innerHTML = `<span>Você é: Avaliador ${dados.avaliador_numero}</span>`;
        avaliadorElement.className = `avaliador-badge a${dados.avaliador_numero}`;
        
        // Alterar texto do botão
        const btnConfirmar = document.getElementById('btnConfirmar');
        if (btnConfirmar) {
            btnConfirmar.textContent = 'Atualizar Avaliação';
        }
    } else if (dados.sera_avaliador && dados.pode_avaliar) {
        // Professor pode avaliar - mostrar qual avaliador será
        statusElement.innerHTML = `<span>Status: Disponível para Avaliação</span>`;
        statusElement.className = 'status-badge';
        
        avaliadorElement.innerHTML = `<span>Você será: Avaliador ${dados.sera_avaliador}</span>`;
        avaliadorElement.className = `avaliador-badge a${dados.sera_avaliador}`;
    } else {
        // Status padrão
        statusElement.innerHTML = `<span>Status: Verificando...</span>`;
        statusElement.className = 'status-badge';
        
        avaliadorElement.innerHTML = `<span>Posição: Verificando...</span>`;
        avaliadorElement.className = 'avaliador-badge';
    }
}

function mostrarProjetoCompleto(mensagem) {
    // Desabilitar o formulário
    const inputs = document.querySelectorAll('.form-control');
    inputs.forEach(input => input.disabled = true);
    
    const comentario = document.getElementById('comentario');
    if (comentario) comentario.disabled = true;
    
    const btnConfirmar = document.getElementById('btnConfirmar');
    if (btnConfirmar) {
        btnConfirmar.disabled = true;
        btnConfirmar.textContent = 'Projeto Já Avaliado Completamente';
        btnConfirmar.style.backgroundColor = '#ccc';
        btnConfirmar.style.cursor = 'not-allowed';
    }
    
    // Atualizar status
    const statusElement = document.getElementById('status-avaliacao');
    const avaliadorElement = document.getElementById('meu-avaliador');
    
    if (statusElement) {
        statusElement.innerHTML = `<span>Status: Completo (2/2)</span>`;
        statusElement.className = 'status-badge completo';
    }
    
    if (avaliadorElement) {
        avaliadorElement.innerHTML = `<span>${mensagem}</span>`;
        avaliadorElement.className = 'status-badge bloqueado';
    }
    
    // Mostrar mensagem
    alert(mensagem);
}

function preencherFormularioComNotas(nota) {
    const inputs = document.querySelectorAll('.form-control');
    
    inputs.forEach(input => {
        const criterio = input.getAttribute('data-criterio');
        if (criterio && nota[criterio] !== undefined) {
            input.value = nota[criterio];
        }
    });
    
    // Preencher comentário se existir
    const comentarioElement = document.getElementById('comentario');
    if (comentarioElement && nota.comentario) {
        comentarioElement.value = nota.comentario;
    }
    
    // Atualizar título para indicar que é uma edição
    const tituloElement = document.getElementById('titulo-projeto');
    if (tituloElement && nota.media) {
        tituloElement.innerHTML = `<strong>${projetoAtual.titulo_projeto || 'Projeto sem título'}</strong><small style="color: #666; font-size: 0.8em; display: block;">(Editando avaliação - Média atual: ${nota.media})</small>`;
    }

    // Alterar texto do botão
    const btnConfirmar = document.getElementById('btnConfirmar');
    if (btnConfirmar) {
        btnConfirmar.textContent = 'Atualizar Avaliação';
    }
    
    // Calcular média inicial
    calcularMediaTempo();
}

function validarNotas() {
    const inputs = document.querySelectorAll('.form-control');
    let todasValidas = true;
    let soma = 0;
    let count = 0;
    
    inputs.forEach(input => {
        const valor = parseFloat(input.value);
        if (isNaN(valor) || valor < 0 || valor > 10) {
            todasValidas = false;
            input.style.borderColor = '#ff4444';
        } else {
            input.style.borderColor = '';
            soma += valor;
            count++;
        }
    });

    if (!todasValidas) {
        mostrarToast('Por favor, preencha todas as notas com valores entre 0 e 10.');
    }

    return todasValidas;
}

function calcularMediaTempo() {
    const inputs = document.querySelectorAll('.form-control');
    let soma = 0;
    let count = 0;
    let validas = true;
    
    inputs.forEach(input => {
        const valor = parseFloat(input.value);
        if (!isNaN(valor) && valor >= 0 && valor <= 10) {
            soma += valor;
            count++;
            input.style.borderColor = '';
        } else if (input.value !== '') {
            validas = false;
            input.style.borderColor = '#ff4444';
        } else {
            input.style.borderColor = '';
        }
    });

    const mediaElement = document.getElementById('media-preview');
    if (mediaElement) {
        if (count === 7 && validas) {
            const media = (soma / 7).toFixed(1);
            mediaElement.textContent = media;
            mediaElement.style.color = '#2ecc71';
        } else if (count > 0) {
            const media = count > 0 ? (soma / count).toFixed(1) : '0.0';
            mediaElement.textContent = `${media} (${count}/7)`;
            mediaElement.style.color = '#f39c12';
        } else {
            mediaElement.textContent = '0.0';
            mediaElement.style.color = '#666';
        }
    }
    
    return { validas, media: count === 7 ? (soma / 7).toFixed(1) : null };
}

function atualizarPreviewMedia(){
    return calcularMediaTempo();
}

// Cria um pequeno toast reutilizável
function mostrarToast(msg){
    let toast = document.getElementById('app-toast');
    if(!toast){
        toast = document.createElement('div');
        toast.id = 'app-toast';
        toast.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:10px 18px;border-radius:6px;font-size:14px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,.25);opacity:0;transition:opacity .3s';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    requestAnimationFrame(()=>{ toast.style.opacity = '1'; });
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(()=>{ toast.style.opacity='0'; }, 3000);
}

function voltarParaProjetos() {
    window.location.href = 'dash-prof.html';
}

async function enviarNotas() {
    if (!projetoAtual) {
        mostrarToast('Erro: Projeto não identificado.');
        return;
    }

    // Obter dados do professor logado
    const usuarioLogado = JSON.parse(localStorage.getItem('usuario_logado') || sessionStorage.getItem('usuario') || '{}');
    const usuario = usuarioLogado.usuario || usuarioLogado;
    const idProfessor = usuario.id_professor || usuario.id;
    
    if (!idProfessor) {
        mostrarToast('Erro: Professor não identificado. Faça login novamente.');
        return;
    }

    // Capturar valores dos inputs usando data-criterio
    const inputs = document.querySelectorAll('.form-control');
    const valores = {};
    
    inputs.forEach(input => {
        const criterio = input.getAttribute('data-criterio');
        if (criterio) {
            valores[criterio] = parseFloat(input.value);
        }
    });

    // Capturar comentário
    const comentarioElement = document.getElementById('comentario');
    const comentario = comentarioElement ? comentarioElement.value.trim() : '';

    const dadosNota = {
        id_projeto: projetoAtual.id_projeto,
        id_professor: idProfessor,
        criatividade: valores.criatividade || 0,
        capricho: valores.capricho || 0,
        abordagem: valores.abordagem || 0,
        dominio: valores.dominio || 0,
        postura: valores.postura || 0,
        oralidade: valores.oralidade || 0,
        organizacao: valores.organizacao || 0,
        comentario: comentario
    };

    console.log('Enviando dados da nota:', dadosNota);

    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/notas/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dadosNota)
        });

        const resultado = await response.json();
        console.log('Resposta do servidor:', resultado);

        if (response.ok) {
            // Fechar modal de confirmação
            document.getElementById('confirmModal').classList.remove('show');
            
            // Mostrar modal de sucesso
            document.getElementById('successModal').classList.add('show');
            
            // Atualizar texto do modal de sucesso
            const successMessage = document.querySelector('#successModal .modal-body p');
            if (successMessage && resultado.media) {
                successMessage.innerHTML = `
                    Avaliação confirmada com sucesso!<br>
                    <strong>Média final: ${resultado.media}</strong>
                `;
            }
        } else {
            console.error('Erro do servidor:', response.status, resultado);
            mostrarToast('Erro ao salvar notas: ' + (resultado.erro || resultado.mensagem || 'Erro desconhecido'));
            document.getElementById('confirmModal').classList.remove('show');
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarToast('Erro de conexão. Tente novamente.');
        document.getElementById('confirmModal').classList.remove('show');
    }
}
