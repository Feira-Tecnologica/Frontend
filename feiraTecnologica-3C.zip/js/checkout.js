document.addEventListener('DOMContentLoaded', () => {
  const step1Form = document.getElementById('step1');
  const btnNext = document.getElementById('btnNext');
  const confirmModal = document.getElementById('confirmModal');
  const confirmText = document.getElementById('confirmText');
  const btnConfirm = document.getElementById('btnConfirm');
  const btnCancel = document.getElementById('btnCancel');
  const codeModal = document.getElementById('codeModal');
  const codeInput = document.getElementById('codeInput');
  const btnVerify = document.getElementById('btnVerify');
  const passwordModal = document.getElementById('passwordModal');
  const newPassword = document.getElementById('newPassword');
  const confirmPassword = document.getElementById('confirmPassword');
  const btnChange = document.getElementById('btnChange');
  const successModal = document.getElementById('successModal');
  const btnLogin = document.getElementById('btnLogin');

  let role = 'aluno';
  let email = '';
  let identifier = '';

  // Password toggle functionality
  document.querySelectorAll('.toggle-password').forEach(toggle => {
    toggle.addEventListener('click', function() {
      const targetId = this.getAttribute('data-target');
      const input = document.getElementById(targetId);
      const icon = this.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
      }
    });
  });

  function showModal(modal) {
    modal.classList.add('show');
  }
  function hideModal(modal) {
    modal.classList.remove('show');
  }

  btnNext.addEventListener('click', () => {
    // esta página é exclusivamente para alunos
    role = 'aluno';
    email = document.getElementById('email').value.trim();
    identifier = document.getElementById('identifier').value.trim();
    if (!email || !identifier) {
      alert('Preencha todos os campos.');
      return;
    }
    const name = email.split('@')[0];
    confirmText.textContent = `Seu nome é ${name}?`;
    showModal(confirmModal);
  });

  btnCancel.addEventListener('click', () => {
    hideModal(confirmModal);
  });

  btnConfirm.addEventListener('click', () => {
    hideModal(confirmModal);
  // solicitar envio do código
  const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
  fetch(apiBase + '/api/senha/enviar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, role, identifier })
    })
      .then(res => {
        if (!res.ok) throw new Error('Erro ao enviar código');
        return res.text();
      })
      .then(text => {
        const data = text.trim() ? JSON.parse(text) : {};
        return data;
      })
      .then(() => {
        showModal(codeModal);
      })
      .catch(err => alert(err.message));
  });

  btnVerify.addEventListener('click', () => {
    const code = codeInput.value.trim();
    if (!code) {
      alert('Digite o código recebido.');
      return;
    }
    // verificar código via login
  const apiBase2 = (window.BASE_URL || '').replace(/\/$/, '');
  const url = role === 'aluno' ? apiBase2 + '/api/login/aluno' : apiBase2 + '/api/login/professor';
    const payload = role === 'aluno'
      ? { rm: identifier, email, senha: code }
      : { matricula: identifier, email };
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(res => {
        if (!res.ok) throw new Error('Código inválido');
        return res.json();
      })
      .then(() => {
        hideModal(codeModal);
        showModal(passwordModal);
      })
      .catch(err => alert(err.message));
  });

  btnChange.addEventListener('click', () => {
    const pass = newPassword.value.trim();
    const confirmPass = confirmPassword.value.trim();
    if (!pass || !confirmPass) {
      alert('Preencha as senhas.');
      return;
    }
    if (pass !== confirmPass) {
      alert('As senhas não conferem.');
      return;
    }
  const apiBase3 = (window.BASE_URL || '').replace(/\/$/, '');
  fetch(apiBase3 + '/api/senha/trocar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, senha_nova: pass })
    })
      .then(res => {
        if (!res.ok) throw new Error('Erro ao alterar senha');
        return res.json();
      })
      .then(() => {
        hideModal(passwordModal);
        showModal(successModal);
      })
      .catch(err => alert(err.message));
  });

  btnLogin.addEventListener('click', () => {
    window.location.href = 'login_aluno.php';
  });
});
