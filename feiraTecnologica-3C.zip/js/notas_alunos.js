// JavaScript para a página de notas dos alunos
let todosOsProjetos = [];
let projetoAtualSelecionado = null;

document.addEventListener("DOMContentLoaded", function () {
    carregarNotasDoAluno();
});

// Função para obter ID do aluno do sessionStorage
function obterIdAluno() {
    const usuarioStr = sessionStorage.getItem("usuario");
    if (!usuarioStr) {
        console.error("Usuário não autenticado");
        return null;
    }
    
    try {
        const data = JSON.parse(usuarioStr);
        const usuario = data.usuario || data;
        
        return usuario.id_aluno || 
               usuario.RM || 
               usuario.rm || 
               data.id_aluno ||
               data.RM ||
               data.rm;
    } catch (error) {
        console.error("Erro ao processar dados do usuário:", error);
        return null;
    }
}

// Função para calcular a menção baseada na média
function calcularMencao(media) {
    if (media >= 7.6) return "MB"; // Muito Bom
    if (media >= 5.1) return "B";  // Bom
    if (media >= 2.6) return "R";  // Regular
    return "I"; // Insuficiente
}

// Função para carregar as notas do aluno
async function carregarNotasDoAluno() {
    const id_aluno = obterIdAluno();
    
    if (!id_aluno) {
        mostrarErro("Erro: Usuário não autenticado ou ID do aluno não encontrado.");
        return;
    }

    try {
        const response = await fetch(`${BASE_URL}/api/notas/aluno?id_aluno=${id_aluno}`);
        
        if (!response.ok) {
            throw new Error(`Erro ${response.status}: ${response.statusText}`);
        }
        
        const projetos = await response.json();
        console.log("Projetos carregados:", projetos);
        
        todosOsProjetos = projetos;
        
        if (projetos.length === 0) {
            mostrarMensagemSemProjetos();
            return;
        }
        
        // Mostrar seletor de projetos
        exibirSeletorProjetos(projetos);
        
    } catch (error) {
        console.error("Erro ao carregar notas:", error);
        mostrarErro("Erro ao carregar suas notas. Tente novamente mais tarde.");
    }
}

// Função para exibir o seletor de projetos
function exibirSeletorProjetos(projetos) {
    const seletorContainer = document.getElementById('projeto-selector');
    const projetosLista = document.getElementById('projetos-lista');
    
    if (!projetosLista) {
        console.error("Elemento projetos-lista não encontrado");
        return;
    }
    
    // Limpar lista
    projetosLista.innerHTML = '';
    
    // Categorizar projetos
    const projetosCompletos = projetos.filter(p => p.qtd_avaliacoes === 2);
    const projetosParciais = projetos.filter(p => p.qtd_avaliacoes === 1);
    const projetosAguardando = projetos.filter(p => p.qtd_avaliacoes === 0);
    
    // Criar cards para cada categoria
    if (projetosCompletos.length > 0) {
        const sectionCompletos = criarSecaoProjetos('Projetos com Avaliação Completa (2/2)', projetosCompletos, 'completo');
        projetosLista.appendChild(sectionCompletos);
    }
    
    if (projetosParciais.length > 0) {
        const sectionParciais = criarSecaoProjetos('Projetos com Avaliação Parcial (1/2)', projetosParciais, 'parcial');
        projetosLista.appendChild(sectionParciais);
    }
    
    if (projetosAguardando.length > 0) {
        const sectionAguardando = criarSecaoProjetos('Projetos Aguardando Avaliação (0/2)', projetosAguardando, 'aguardando');
        projetosLista.appendChild(sectionAguardando);
    }
    
    // Mostrar seletor
    seletorContainer.style.display = 'block';
}

// Função para criar seção de projetos por categoria
function criarSecaoProjetos(titulo, projetos, tipo) {
    const section = document.createElement('div');
    section.className = `projetos-section projetos-${tipo}`;
    
    const header = document.createElement('div');
    header.className = 'section-header';
    header.innerHTML = `<h4>${titulo}</h4>`;
    section.appendChild(header);
    
    const grid = document.createElement('div');
    grid.className = 'projetos-grid';
    
    projetos.forEach(projeto => {
        const card = criarCardProjeto(projeto, tipo);
        grid.appendChild(card);
    });
    
    section.appendChild(grid);
    return section;
}

// Função para criar card de projeto no seletor
function criarCardProjeto(projeto, tipo) {
    const card = document.createElement('div');
    card.className = `projeto-card projeto-${tipo}`;
    
    let statusInfo = '';
    let botaoTexto = 'Ver Notas';
    let desabilitado = false;
    
    if (tipo === 'completo') {
        const mencao = projeto.mencao_final || calcularMencao(projeto.media_final);
        statusInfo = `
            <div class="status-info completo">
                <span class="status-badge completo">2/2 Completo</span>
                <div class="nota-info">
                    <span class="nota-valor">${parseFloat(projeto.media_final).toFixed(2)}</span>
                    <span class="mencao mencao-${mencao.toLowerCase()}">${mencao}</span>
                </div>
            </div>
        `;
        botaoTexto = 'Ver Notas Completas';
    } else if (tipo === 'parcial') {
        statusInfo = `
            <div class="status-info parcial">
                <span class="status-badge parcial">1/2 Parcial</span>
                <p class="status-desc">Apenas 1 professor avaliou</p>
            </div>
        `;
        botaoTexto = 'Ver Avaliação Parcial';
    } else {
        statusInfo = `
            <div class="status-info aguardando">
                <span class="status-badge aguardando">0/2 Aguardando</span>
                <p class="status-desc">Nenhuma avaliação ainda</p>
            </div>
        `;
        botaoTexto = 'Sem Avaliações';
        desabilitado = true;
    }
    
    card.innerHTML = `
        <div class="card-header">
            <h5>${projeto.titulo_projeto}</h5>
            ${statusInfo}
        </div>
        <div class="card-body">
            <p class="projeto-desc">${projeto.descricao || 'Sem descrição'}</p>
            <div class="projeto-meta">
                <span><strong>Orientador:</strong> ${projeto.nome_orientador || projeto.orientador || "Não definido"}</span>
                ${projeto.posicao ? `<br><span><strong>Stand:</strong> ${projeto.posicao}</span>` : ''}
            </div>
        </div>
        <div class="card-footer">
            <button class="btn-ver-notas ${desabilitado ? 'disabled' : ''}" 
                    onclick="selecionarProjeto(${projeto.id_projeto})" 
                    ${desabilitado ? 'disabled' : ''}>
                ${botaoTexto}
            </button>
        </div>
    `;
    
    return card;
}

// Função para selecionar um projeto e mostrar suas notas
function selecionarProjeto(idProjeto) {
    // Tentar encontrar o projeto com conversão de tipo
    let projeto = todosOsProjetos.find(p => p.id_projeto == idProjeto); // usar == ao invés de ===
    
    if (!projeto) {
        // Tentar com conversão para string
        projeto = todosOsProjetos.find(p => String(p.id_projeto) === String(idProjeto));
    }
    
    if (!projeto) {
        // Tentar com conversão para number
        projeto = todosOsProjetos.find(p => Number(p.id_projeto) === Number(idProjeto));
    }
    
    if (!projeto) {
        console.error("Projeto não encontrado:", idProjeto);
        return;
    }
    
    if (projeto.qtd_avaliacoes === 0) {
        alert("Este projeto ainda não possui avaliações.");
        return;
    }
    
    projetoAtualSelecionado = projeto;
    
    // Ocultar seletor e mostrar notas
    document.getElementById('projeto-selector').style.display = 'none';
    document.getElementById('notas-container').style.display = 'block';
    
    // Atualizar título do projeto atual
    const tituloElement = document.getElementById('projeto-atual-titulo');
    if (tituloElement) {
        tituloElement.textContent = projeto.titulo_projeto;
    }
    
    // Exibir notas na tabela
    exibirNotasNaTabela(projeto);
}

// Função para voltar à seleção de projetos
function voltarParaSelecao() {
    document.getElementById('notas-container').style.display = 'none';
    document.getElementById('projeto-selector').style.display = 'block';
    projetoAtualSelecionado = null;
}

// Função para exibir as notas na tabela
function exibirNotasNaTabela(projeto) {
    const avaliacoes = projeto.avaliacoes;
    
    // Criar cabeçalho da tabela
    const table = document.querySelector('.avaliacao table');
    if (!table) {
        console.error("Tabela não encontrada");
        return;
    }
    
    // Limpar tabela existente
    table.innerHTML = '';
    
    // Verificar se há avaliações
    if (!avaliacoes || avaliacoes.length === 0) {
        mostrarMensagem("Este projeto ainda não foi avaliado por nenhum professor.");
        return;
    }
    
    // Criar cabeçalho
    const headerRow = document.createElement('tr');
    headerRow.innerHTML = '<th>Critérios</th>';
    
    // Adicionar colunas para cada avaliador ordenando por avaliador_numero
    avaliacoes.sort((a, b) => a.avaliador_numero - b.avaliador_numero);
    
    avaliacoes.forEach((avaliacao) => {
        headerRow.innerHTML += `<th>A${avaliacao.avaliador_numero}</th>`;
    });
    
    // Se só tem 1 avaliação, adicionar coluna para o A2 pendente
    if (avaliacoes.length === 1) {
        const proximoAvaliador = avaliacoes[0].avaliador_numero === 1 ? 2 : 1;
        headerRow.innerHTML += `<th>A${proximoAvaliador} <small>(Pendente)</small></th>`;
    }
    
    // Adicionar coluna da média final (só se tiver 2 avaliações)
    if (avaliacoes.length === 2) {
        headerRow.innerHTML += '<th>Média Final</th>';
    }
    
    table.appendChild(headerRow);
    
    // Critérios de avaliação
    const criterios = [
        { nome: 'Oralidade', campo: 'oralidade' },
        { nome: 'Postura', campo: 'postura' },
        { nome: 'Organização', campo: 'organizacao' },
        { nome: 'Criatividade', campo: 'criatividade' },
        { nome: 'Capricho', campo: 'capricho' },
        { nome: 'Domínio', campo: 'dominio' },
        { nome: 'Abordagem', campo: 'abordagem' }
    ];
    
    // Adicionar linhas para cada critério
    criterios.forEach(criterio => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${criterio.nome}</td>`;
        
        avaliacoes.forEach(avaliacao => {
            row.innerHTML += `<td>${parseFloat(avaliacao[criterio.campo]).toFixed(1)}</td>`;
        });
        
        // Se só tem 1 avaliação, adicionar célula vazia para o avaliador pendente
        if (avaliacoes.length === 1) {
            row.innerHTML += `<td class="pendente">-</td>`;
        }
        
        // Se tem 2 avaliações, não adicionar média por critério (só média geral)
        if (avaliacoes.length === 2) {
            row.innerHTML += `<td class="media-final">-</td>`;
        }
        
        table.appendChild(row);
    });
    
    // Linha com média por avaliador
    const mediaRow = document.createElement('tr');
    mediaRow.className = 'linha-destaque';
    mediaRow.innerHTML = '<td><strong>Média por avaliador</strong></td>';
    
    avaliacoes.forEach(avaliacao => {
        mediaRow.innerHTML += `<td><strong>${parseFloat(avaliacao.media).toFixed(2)}</strong></td>`;
    });
    
    if (avaliacoes.length === 1) {
        mediaRow.innerHTML += `<td class="pendente"><strong>-</strong></td>`;
    }
    
    if (avaliacoes.length === 2) {
        const mediaFinal = projeto.media_final || 0;
        mediaRow.innerHTML += `<td class="media-final"><strong>${mediaFinal.toFixed(2)}</strong></td>`;
    }
    
    table.appendChild(mediaRow);
    
    // Linha com status
    const statusRow = document.createElement('tr');
    statusRow.className = 'linha-info';
    
    if (avaliacoes.length === 1) {
        statusRow.innerHTML = `
            <td><strong>Status</strong></td>
            <td colspan="${avaliacoes.length + 1}" class="status-parcial">
                ${projeto.status_avaliacao} - Aguardando segundo avaliador
            </td>
        `;
    } else if (avaliacoes.length === 2) {
        // Calcular e exibir menção apenas quando há 2 avaliações
        const mediaFinal = projeto.media_final || 0;
        const mencao = projeto.mencao_final || calcularMencao(mediaFinal);
        
        statusRow.innerHTML = `
            <td><strong>Status</strong></td>
            <td colspan="${avaliacoes.length + 1}" class="status-completo">
                ${projeto.status_avaliacao} - Menção: <span class="mencao">${mencao}</span>
            </td>
        `;
    }
    
    table.appendChild(statusRow);
    
    // Atualizar feedbacks
    atualizarFeedbacks(avaliacoes);
}

// Função para atualizar os feedbacks
function atualizarFeedbacks(avaliacoes) {
    const feedbacksContainer = document.querySelector('.feedbacks');
    if (!feedbacksContainer) return;
    
    // Limpar feedbacks existentes
    const feedbacksExistentes = feedbacksContainer.querySelectorAll('.feedback');
    feedbacksExistentes.forEach(feedback => feedback.remove());
    
    // Remover mensagem de carregamento se existir
    const loadingFeedback = feedbacksContainer.querySelector('.loading-feedback');
    if (loadingFeedback) {
        loadingFeedback.remove();
    }
    
    // Ordenar avaliações por avaliador_numero
    const avaliacoesOrdenadas = avaliacoes.sort((a, b) => a.avaliador_numero - b.avaliador_numero);
    
    // Adicionar novos feedbacks
    avaliacoesOrdenadas.forEach((avaliacao) => {
        if (avaliacao.comentario && avaliacao.comentario.trim() !== '') {
            const feedbackDiv = document.createElement('div');
            feedbackDiv.className = 'feedback';
            feedbackDiv.innerHTML = `
                <div>
                    <strong>Avaliador ${avaliacao.avaliador_numero} - ${avaliacao.nome_professor || `Professor ${avaliacao.avaliador_numero}`}</strong>
                    <p>${avaliacao.comentario}</p>
                </div>
                <img src="img/Vector.png" alt="">
            `;
            feedbacksContainer.appendChild(feedbackDiv);
        }
    });
    
    // Se não há feedbacks, mostrar mensagem
    const temFeedbacks = avaliacoes.some(av => av.comentario && av.comentario.trim() !== '');
    if (!temFeedbacks) {
        const noFeedbackDiv = document.createElement('div');
        noFeedbackDiv.className = 'no-feedback';
        noFeedbackDiv.innerHTML = '<p style="text-align: center; color: #666; font-style: italic;">Nenhum feedback fornecido pelos avaliadores.</p>';
        feedbacksContainer.appendChild(noFeedbackDiv);
    }
}

// Função para mostrar mensagem quando não há projetos
function mostrarMensagemSemProjetos() {
    const seletorContainer = document.getElementById('projeto-selector');
    const projetosLista = document.getElementById('projetos-lista');
    
    if (projetosLista) {
        projetosLista.innerHTML = `
            <div class="empty-state">
                <i class="material-icons" style="font-size: 4rem; color: #ccc;">assignment</i>
                <h3>Nenhum projeto encontrado</h3>
                <p>Você ainda não possui projetos cadastrados.</p>
                <button class="btn-create" onclick="window.location.href='dashboard_aluno.html'">
                    <i class="material-icons">arrow_back</i>
                    Voltar ao Dashboard
                </button>
            </div>
        `;
    }
    
    if (seletorContainer) {
        seletorContainer.style.display = 'block';
    }
}

// Função para mostrar erro
function mostrarErro(mensagem) {
    const seletorContainer = document.getElementById('projeto-selector');
    const projetosLista = document.getElementById('projetos-lista');
    
    if (projetosLista) {
        projetosLista.innerHTML = `
            <div class="error-message" style="text-align: center; padding: 2rem; color: #d32f2f;">
                <i class="material-icons" style="font-size: 3rem;">error</i>
                <h3>Erro</h3>
                <p>${mensagem}</p>
                <button onclick="window.location.reload()" 
                        style="margin-top: 1rem; padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Tentar Novamente
                </button>
            </div>
        `;
    }
    
    if (seletorContainer) {
        seletorContainer.style.display = 'block';
    }
}

// Função para mostrar mensagem
function mostrarMensagem(mensagem) {
    const seletorContainer = document.getElementById('projeto-selector');
    const projetosLista = document.getElementById('projetos-lista');
    
    if (projetosLista) {
        projetosLista.innerHTML = `
            <div class="info-message" style="text-align: center; padding: 2rem;">
                <i class="material-icons" style="font-size: 3rem; color: #ffa726;">info</i>
                <h3>Informação</h3>
                <p>${mensagem}</p>
                <button onclick="window.location.href='dashboard_aluno.html'" 
                        style="margin-top: 1rem; padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Voltar ao Dashboard
                </button>
            </div>
        `;
    }
    
    if (seletorContainer) {
        seletorContainer.style.display = 'block';
    }
}