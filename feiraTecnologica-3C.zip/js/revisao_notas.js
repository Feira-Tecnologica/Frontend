// Variáveis globais
let projetosComNotas = [];
let professorAtual = null;
let isLoading = false;

document.addEventListener('DOMContentLoaded', function() {
    // Adicionar classe de animação inicial
    document.body.classList.add('fade-in-up');
    
    verificarAutenticacao();
    carregarProjetosComNotas();
    
    // Configurar navegação com botão voltar
    configurarNavegacao();
});

function verificarAutenticacao() {
    const dadosUsuario = localStorage.getItem('usuario_logado') || sessionStorage.getItem('professor_logado');
    if (!dadosUsuario) {
        mostrarNotificacao('Você precisa fazer login primeiro!', 'error');
        setTimeout(() => {
            window.location.href = 'login professor.html';
        }, 2000);
        return;
    }
    
    try {
        const usuario = JSON.parse(dadosUsuario);
        professorAtual = usuario.usuario || usuario;
    } catch (e) {
        console.error('Erro ao recuperar dados do professor:', e);
        mostrarNotificacao('Erro nos dados do usuário', 'error');
        setTimeout(() => {
            window.location.href = 'login professor.html';
        }, 2000);
        return;
    }
}

function configurarNavegacao() {
    // Configurar botão voltar no header
    const btnVoltar = document.querySelector('.header-avaliacao .material-icons');
    if (btnVoltar) {
        btnVoltar.addEventListener('click', function() {
            animarSaida(() => {
                window.location.href = 'dash-prof2.html';
            });
        });
    }
    
    // Configurar botão voltar nos botões de ação
    const btnVoltarAcoes = document.getElementById('btnVoltar');
    if (btnVoltarAcoes) {
        btnVoltarAcoes.addEventListener('click', function() {
            animarSaida(() => {
                window.location.href = 'dash-prof2.html';
            });
        });
    }
}

async function carregarProjetosComNotas() {
    if (isLoading) return;
    
    isLoading = true;
    mostrarLoading(true);
    
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const idProf = (professorAtual && (professorAtual.id || professorAtual.id_professor)) || '';
        const response = await fetch(`${apiBase}/api/notas/projetos?id_professor=${idProf}`);
        
        if (response.ok) {
            const data = await response.json();
            // Filtrar: mostrar apenas projetos que EU avaliei (minha_nota presente)
            const apenasMeus = Array.isArray(data) ? data.filter(p => p.minha_nota !== null && p.minha_nota !== undefined) : [];
            projetosComNotas = apenasMeus;
            renderizarListaProjetos();
            // Mensagem de sucesso apenas se houver itens
            if (projetosComNotas.length > 0) {
                mostrarNotificacao('Projetos carregados com sucesso!', 'success');
            }
        } else {
            console.error('Erro ao carregar projetos com notas');
            mostrarMensagemErro('Erro ao carregar projetos');
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarMensagemErro('Erro de conexão');
    } finally {
        isLoading = false;
        mostrarLoading(false);
    }
}

function renderizarListaProjetos() {
    const container = document.querySelector('.content-container');
    
    // Criar nova estrutura para lista de projetos com sistema A1/A2
    container.innerHTML = `
        <div class="avaliacao fade-in-up">
            <div class="header-avaliacao">
                <i class="material-icons" style="cursor: pointer;" onclick="voltarPagina()">arrow_back_ios</i>
                <div class="breadcrumb">
                    <a href="dash-prof2.html">Projeto</a> &gt; <span>Revisão de Notas</span>
                </div>
            </div>
            
            <div class="projetos-avaliados">
                <h1><strong>Projetos</strong><br>com Avaliações</h1>
                
                <div class="filtros">
                    <div class="search">
                        <i class="material-icons">search</i>
                        <input type="text" placeholder="Pesquisar projeto..." id="searchInput">
                    </div>
                    <select id="filtroStatus">
                        <option value="">Todos os projetos</option>
                        <option value="completo">Avaliação Completa (A1 + A2)</option>
                        <option value="parcial">Avaliação Parcial (A1 ou A2)</option>
                        <option value="meus">Minhas Avaliações</option>
                    </select>
                </div>
                
                <div class="lista-projetos" id="listaProjetos">
                    <!-- Projetos serão inseridos aqui -->
                </div>
            </div>
        </div>
    `;

    configurarFiltros();
    renderizarProjetos();
}

function configurarFiltros() {
    const searchInput = document.getElementById('searchInput');
    const filtroStatus = document.getElementById('filtroStatus');

    if (searchInput) {
        // Adicionar debounce para melhor performance
        let timeoutId;
        searchInput.addEventListener('input', function() {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                filtrarProjetos();
                // Adicionar animação de busca
                searchInput.parentElement.classList.add('searching');
                setTimeout(() => {
                    searchInput.parentElement.classList.remove('searching');
                }, 300);
            }, 300);
        });
    }

    if (filtroStatus) {
        filtroStatus.addEventListener('change', function() {
            filtrarProjetos();
            // Adicionar feedback visual
            this.classList.add('changed');
            setTimeout(() => {
                this.classList.remove('changed');
            }, 300);
        });
    }
}

function filtrarProjetos() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('filtroStatus')?.value || '';

    let projetosFiltrados = projetosComNotas;

    // Filtrar por termo de busca
    if (searchTerm) {
        projetosFiltrados = projetosFiltrados.filter(projeto =>
            (projeto.nome_projeto || projeto.titulo_projeto || '').toLowerCase().includes(searchTerm) ||
            (projeto.integrantes && projeto.integrantes.toLowerCase().includes(searchTerm))
        );
    }

    // Filtrar por status A1/A2 usando campos do endpoint por professor (qtd_avaliacoes_total)
    if (statusFilter) {
        const professorId = professorAtual.id || professorAtual.id_professor;
        switch(statusFilter) {
            case 'completo':
                projetosFiltrados = projetosFiltrados.filter(projeto => {
                    const qtd = parseInt(projeto.qtd_avaliacoes_total || 0, 10) || 0;
                    return qtd >= 2;
                });
                break;
            case 'parcial':
                projetosFiltrados = projetosFiltrados.filter(projeto => {
                    const qtd = parseInt(projeto.qtd_avaliacoes_total || 0, 10) || 0;
                    return qtd === 1;
                });
                break;
            case 'meus':
                // A lista já está pré-filtrada para "meus"; manter sem alteração
                projetosFiltrados = projetosFiltrados;
                break;
        }
    }

    renderizarProjetos(projetosFiltrados);
}

function renderizarProjetos(projetos = projetosComNotas) {
    const listaProjetos = document.getElementById('listaProjetos');
    
    if (!listaProjetos) return;

    // Adicionar animação de saída para projetos existentes
    const projetosExistentes = listaProjetos.querySelectorAll('.projeto-card');
    projetosExistentes.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(-20px)';
    });

    setTimeout(() => {
        if (projetos.length === 0) {
            listaProjetos.innerHTML = `
                <div class="no-projects fade-in-up" style="text-align:center;">
                    <i class="material-icons" style="font-size: 48px; color: #ccc; margin-bottom: 15px;">inbox</i>
                    <p>Você ainda não avaliou nenhum projeto.</p>
                    <div style="margin-top: 12px;">
                        <a href="dash-prof2.html" class="btn-avaliar" style="padding:10px 16px; background:#6C1BA8; color:#fff; border-radius:8px; text-decoration:none;">Ir para Projetos</a>
                    </div>
                </div>
            `;
            return;
        }

        listaProjetos.innerHTML = projetos.map((projeto, index) => `
            <div class="projeto-card ${projeto.status_avaliacao.toLowerCase()} fade-in-up" style="animation-delay: ${index * 0.1}s">
                <div class="projeto-info">
                    <h3 class="projeto-titulo">${projeto.titulo_projeto}</h3>
                    <div class="projeto-detalhes">
                        <span class="stand">STAND ${projeto.posicao || 'N/A'}</span>
                        <span class="turma">${projeto.turma || 'Turma não definida'}</span>
                        <span class="orientador">Orientador: ${projeto.orientador || 'Não definido'}</span>
                    </div>
                    <div class="integrantes">
                        <i class="material-icons">group</i>
                        <span>${projeto.integrantes || 'Sem integrantes'}</span>
                    </div>
                </div>
                
                <div class="status-avaliacao">
                    <span class="status-badge ${projeto.status_avaliacao.toLowerCase()}">
                        ${projeto.status_avaliacao}
                    </span>
                    ${projeto.media_projeto ? `
                        <div class="media-projeto">
                            <span class="media-label">Média:</span>
                            <span class="media-valor">${projeto.media_projeto}</span>
                        </div>
                    ` : ''}
                </div>
                
                <div class="acoes-projeto">
                    <button class="btn-visualizar" onclick="visualizarNotas('${projeto.id_projeto}')">
                        <i class="material-icons">visibility</i>
                        Visualizar
                    </button>
                    ${projeto.status_avaliacao === 'Pendente' ? `
                        <button class="btn-avaliar" onclick="avaliarProjeto('${projeto.id_projeto}')">
                            <i class="material-icons">grade</i>
                            Avaliar
                        </button>
                    ` : `
                        <button class="btn-editar" onclick="editarNotas('${projeto.id_projeto}')">
                            <i class="material-icons">edit</i>
                            Editar Nota
                        </button>
                    `}
                </div>
            </div>
        `).join('');
    }, 150);
}

function visualizarNotas(idProjeto) {
    mostrarLoading(true);
    localStorage.setItem('projeto_visualizacao', idProjeto);
    
    animarSaida(() => {
        window.location.href = 'visualizar_projeto.html';
    });
}

function avaliarProjeto(idProjeto) {
    mostrarLoading(true);
    localStorage.setItem('projeto_avaliacao', idProjeto);
    
    animarSaida(() => {
        window.location.href = 'notas_professores.html';
    });
}

function editarNotas(idProjeto) {
    mostrarLoading(true);
    localStorage.setItem('projeto_avaliacao', idProjeto);
    
    animarSaida(() => {
        window.location.href = 'notas_professores.html';
    });
}

function voltarPagina() {
    animarSaida(() => {
        window.location.href = 'dash-prof2.html';
    });
}

function mostrarMensagemErro(mensagem) {
    const container = document.querySelector('.content-container');
    if (container) {
        container.innerHTML = `
            <div class="error-container fade-in-up">
                <i class="material-icons" style="font-size: 64px; color: #ff4444; margin-bottom: 20px;">error_outline</i>
                <h2>Erro</h2>
                <p>${mensagem}</p>
                <button onclick="voltarPagina()" class="btn-voltar">
                    <i class="material-icons">arrow_back</i>
                    Voltar aos Projetos
                </button>
            </div>
        `;
    }
}

// Funções de utilidade para melhor UX
function mostrarLoading(show) {
    let loader = document.querySelector('.loading-overlay');
    
    if (show && !loader) {
        loader = document.createElement('div');
        loader.className = 'loading-overlay';
        loader.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner"></div>
                <p>Carregando...</p>
            </div>
        `;
        document.body.appendChild(loader);
    } else if (!show && loader) {
        loader.remove();
    }
}

function mostrarNotificacao(mensagem, tipo = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${tipo}`;
    notification.innerHTML = `
        <i class="material-icons">${tipo === 'success' ? 'check_circle' : tipo === 'error' ? 'error' : 'info'}</i>
        <span>${mensagem}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remover após 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

function animarSaida(callback) {
    const elements = document.querySelectorAll('.fade-in-up');
    elements.forEach((el, index) => {
        setTimeout(() => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
        }, index * 50);
    });
    
    setTimeout(callback, elements.length * 50 + 300);
}

// Adicionar estilos dinâmicos para componentes JavaScript
const dynamicStyles = `
    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        backdrop-filter: blur(5px);
    }
    
    .loading-spinner {
        text-align: center;
        color: white;
    }
    
    .spinner {
        width: 40px;
        height: 40px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top: 4px solid #9957E4;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto 15px;
    }
    
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 10000;
        transform: translateX(100%);
        opacity: 0;
        transition: all 0.3s ease;
    }
    
    .notification.show {
        transform: translateX(0);
        opacity: 1;
    }
    
    .notification.success {
        border-left: 4px solid #2ecc71;
    }
    
    .notification.error {
        border-left: 4px solid #e74c3c;
    }
    
    .notification.info {
        border-left: 4px solid #9957E4;
    }
    
    .search.searching {
        animation: pulse 0.3s ease;
    }
    
    select.changed {
        animation: pulse 0.3s ease;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`;

// Adicionar estilos ao head
const styleSheet = document.createElement('style');
styleSheet.textContent = dynamicStyles;
document.head.appendChild(styleSheet);