// Variáveis globais
let professorAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    verificarAutenticacao();
    carregarDadosProfessor();
    carregarProjetos();
    
    // Deixar link ativo no nav
    const navLinks = document.querySelectorAll("nav a");
    window.addEventListener("scroll", () => {
      let fromTop = window.scrollY + 70;
      navLinks.forEach(link => {
        const section = document.querySelector(link.hash);
        if (section && section.offsetTop <= fromTop && section.offsetTop + section.offsetHeight > fromTop) {
          link.classList.add("active");
        } else {
          link.classList.remove("active");
        }
      });
    });
});

function verificarAutenticacao() {
    // Verificar se há dados do professor no localStorage
    const dadosUsuario = localStorage.getItem('usuario_logado');
    if (!dadosUsuario) {
        alert('Você precisa fazer login primeiro!');
        window.location.href = 'login professor.html';
        return;
    }
    
    try {
        professorAtual = JSON.parse(dadosUsuario);
        
        // Normalizar dados - pode estar em professorAtual.usuario ou direto em professorAtual
        const usuario = professorAtual.usuario || professorAtual;
        
        // Verificar se é realmente um professor de forma mais robusta
        const isProfessor = usuario.tipo === 'professor' || 
                           usuario.matricula || 
                           usuario.id_professor || 
                           usuario.nome_professor;
        
        console.log('Dados do usuário:', usuario);
        console.log('É professor?', isProfessor);
        
        if (!isProfessor) {
            alert('Acesso negado! Esta área é apenas para professores.');
            window.location.href = 'escolha-login.html';
            return;
        }
        
        // Garantir que professorAtual tenha a estrutura correta
        if (professorAtual.usuario) {
            professorAtual = professorAtual.usuario;
        }
    } catch (e) {
        console.error('Erro ao recuperar dados do professor:', e);
        window.location.href = 'login professor.html';
        return;
    }
}

function carregarDadosProfessor() {
    if (!professorAtual) return;
    
    // Atualizar o nome do professor na página
    const bemVindoElement = document.querySelector('.banner-text h1');
    if (bemVindoElement) {
        bemVindoElement.textContent = `Bem-vindo, Prof. ${professorAtual.nome || professorAtual.nome_professor || 'Professor'}`;
    }
    
    console.log('Professor logado:', professorAtual);
}

async function carregarProjetos() {
    if (!professorAtual) return;
    
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        
        // Fazer duas chamadas: uma para projetos completos e outra para status de avaliação específico do professor
        const [projetosResponse, statusResponse] = await Promise.all([
            fetch(apiBase + '/api/projetos'),
            fetch(apiBase + `/api/notas/projetos?id_professor=${professorAtual.id || professorAtual.id_professor}`)
        ]);
        
        if (!projetosResponse.ok) {
            throw new Error('Erro ao carregar projetos');
        }
        
        const projetosData = await projetosResponse.json();
        let todosProjetos = [];
        
        // Normalizar formato da resposta dos projetos
        if (Array.isArray(projetosData)) {
            todosProjetos = projetosData;
        } else if (projetosData && Array.isArray(projetosData.data)) {
            todosProjetos = projetosData.data;
        } else if (projetosData && Array.isArray(projetosData.projetos)) {
            todosProjetos = projetosData.projetos;
        }
        
        // Buscar informações de status de avaliação específicas para este professor
        let statusProjetos = [];
        if (statusResponse.ok) {
            statusProjetos = await statusResponse.json();
        }
        
        // Combinar dados completos dos projetos com status de avaliação específico do professor
        const projetosComStatus = todosProjetos.map(projeto => {
            // Encontrar o status específico para este professor
            const statusProjeto = statusProjetos.find(s => 
                parseInt(s.id_projeto) === parseInt(projeto.id_projeto)
            );
            
            // Verificar se este professor específico avaliou (não confundir com avaliações de outros professores)
            const avaliadoPorMim = statusProjeto && statusProjeto.minha_nota !== null && statusProjeto.minha_nota !== undefined;
            
            return {
                ...projeto, // Dados completos do projeto (descrição, justificativa, objetivo, etc.)
                avaliado: avaliadoPorMim,
                media: avaliadoPorMim ? statusProjeto.minha_nota : null,
                status_avaliacao_geral: statusProjeto ? statusProjeto.status_avaliacao : 'Disponível',
                qtd_avaliacoes_total: statusProjeto ? statusProjeto.qtd_avaliacoes_total : 0
            };
        });
        
        // Contar projetos pendentes (não avaliados por mim E ainda com vagas de avaliação)
        const projetosPendentes = projetosComStatus.filter(projeto => {
            const qtd = parseInt(projeto.qtd_avaliacoes_total ?? 0, 10) || 0;
            // Só é pendente se eu não avaliei e ainda há menos de 2 avaliações
            return !projeto.avaliado && qtd < 2;
        });
        
        console.log('Todos os projetos:', projetosComStatus);
        console.log('Projetos pendentes de avaliação por mim:', projetosPendentes);
        
        // Atualizar contador de projetos pendentes
        atualizarContadorProjetos(projetosPendentes, projetosComStatus.length);
        
    } catch (error) {
        console.error('Erro ao carregar projetos:', error);
        
        // Se não conseguir carregar, mostrar dados padrão
        atualizarContadorProjetos([], 0);
    }
}

function atualizarContadorProjetos(projetosPendentes, totalProjetos = 0) {
    const numeroProjetosElement = document.querySelector('.numero-projetos');
    const textoProjetosElement = document.querySelector('.texto-projetos');
    const subtextoElement = document.querySelector('.subtexto');
    
    if (numeroProjetosElement) {
        numeroProjetosElement.textContent = projetosPendentes.length;
    }
    
    if (textoProjetosElement) {
        textoProjetosElement.textContent = projetosPendentes.length === 1 ? 'PROJETO' : 'PROJETOS';
    }
    
    if (subtextoElement) {
        if (projetosPendentes.length === 0) {
            if (totalProjetos === 0) {
                subtextoElement.textContent = 'Nenhum projeto disponível';
            } else {
                // Sem pendências para este professor (mesmo que não tenha avaliado, se já estiver 2/2)
                subtextoElement.textContent = 'Sem pendências para você';
            }
        } else {
            subtextoElement.textContent = 'Pendentes de avaliação';
        }
    }
    
    // Atualizar texto de pendências
    const textoPendenciaElement = document.querySelector('.texto-pendencia');
    if (textoPendenciaElement) {
        if (projetosPendentes.length === 0) {
            if (totalProjetos === 0) {
                textoPendenciaElement.textContent = 'Nenhum projeto disponível!';
            } else {
                // Evita sugerir que o evento terminou; indica apenas que não há pendências para o professor
                textoPendenciaElement.textContent = 'Sem pendências para você!';
            }
        } else {
            textoPendenciaElement.textContent = 'Você possui pendências!';
        }
    }
    
    // Mostrar informações adicionais se houver projetos avaliados
    if (totalProjetos > projetosPendentes.length) {
        const projetosAvaliados = totalProjetos - projetosPendentes.length;
        console.log(`Projetos avaliados: ${projetosAvaliados}/${totalProjetos}`);
        
        // Adicionar indicador visual de progresso (opcional)
        const progressoElement = document.querySelector('.progresso-avaliacoes');
        if (progressoElement) {
            const percentual = Math.round((projetosAvaliados / totalProjetos) * 100);
            progressoElement.textContent = `Progresso: ${percentual}% (${projetosAvaliados}/${totalProjetos})`;
        }
    }
}

function sairSistema() {
    // Mostrar modal de confirmação
    const modal = document.getElementById('logoutModal');
    modal.classList.add('show');
}

function confirmarLogout() {
    // Limpar dados de autenticação
    localStorage.removeItem('usuario_logado');
    sessionStorage.removeItem('usuario');
    
    // Redirecionar para página de escolha de login
    window.location.href = 'escolha-login.html';
}

function cancelarLogout() {
    // Fechar modal
    const modal = document.getElementById('logoutModal');
    modal.classList.remove('show');
}
