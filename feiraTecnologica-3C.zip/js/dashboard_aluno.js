// JavaScript para o Dashboard do Aluno
let meusProjetos = [];
let minhasNotas = [];

document.addEventListener("DOMContentLoaded", function () {
    exibirSaudacaoUsuario();
    carregarMeusProjetos();
    carregarPerfilUsuario();
    configurarPesquisa();
});

// Função para exibir a saudação personalizada
function exibirSaudacaoUsuario() {
    const saudacaoElem = document.getElementById("saudacao");
    const usuarioStr = sessionStorage.getItem("usuario");
    
    if (usuarioStr && saudacaoElem) {
        const data = JSON.parse(usuarioStr);
        const usuario = data.usuario || data;
        const nome = usuario.nome || usuario.nome_aluno || usuario.nome_professor || "Aluno";
        saudacaoElem.textContent = `Olá, ${nome}!`;
    }
}

// Sistema de abas
function showTab(tabName) {
    // Esconder todas as abas
    const tabPanes = document.querySelectorAll('.tab-pane');
    tabPanes.forEach(pane => {
        pane.classList.remove('active');
    });
    
    // Remover active de todos os botões
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Mostrar aba selecionada
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // Ativar botão correspondente
    const activeBtn = document.getElementById(`tab-${tabName.split('-')[1]}`);
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
    
    // Carregar conteúdo específico da aba
    switch(tabName) {
        case 'meus-projetos':
            if (meusProjetos.length === 0) {
                carregarMeusProjetos();
            }
            break;
        case 'minhas-notas':
            if (minhasNotas.length === 0) {
                carregarMinhasNotas();
            }
            break;
        case 'meu-perfil':
            carregarPerfilUsuario();
            break;
    }
}

// Carregamento dos projetos do usuário
async function carregarMeusProjetos() {
    try {
        const grid = document.getElementById("meus-projetos-grid");
        grid.innerHTML = '<div class="loading">Carregando seus projetos...</div>';
        
        // Obter ID do usuário do sessionStorage
        const usuarioStr = sessionStorage.getItem("usuario");
        if (!usuarioStr) {
            mostrarErro(grid, "Usuário não autenticado. Faça login novamente.");
            return;
        }
        
        let data, usuario, id_aluno;
        
        try {
            data = JSON.parse(usuarioStr);
            usuario = data.usuario || data;
            
            // Tentar várias formas de obter o ID do aluno
            id_aluno = usuario.id_aluno || 
                      usuario.RM || 
                      usuario.rm || 
                      data.id_aluno ||
                      data.RM ||
                      data.rm;
                      
            console.log("SessionStorage bruto:", usuarioStr);
            console.log("Dados parseados:", data);
            console.log("Usuario extraído:", usuario);
            console.log("ID aluno encontrado:", id_aluno);
            
        } catch (e) {
            console.error("Erro ao processar sessionStorage:", e);
            mostrarErro(grid, "Erro ao processar dados do usuário.");
            return;
        }
        
        if (!id_aluno) {
            console.error("ID do aluno não encontrado. Dados disponíveis:", {data, usuario});
            mostrarErro(grid, "ID do usuário não encontrado. Verifique o console para mais detalhes.");
            return;
        }
        
        // Use endpoint que traz projetos em que sou criador OU integrante
        const url = `${window.BASE_URL}/api/notas/aluno?id_aluno=${encodeURIComponent(id_aluno)}`;
        const response = await fetch(url, { method: 'GET', credentials: 'include' });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Erro ao carregar projetos: ${response.status} ${errorText}`);
        }

    const dataResp = await response.json();
    meusProjetos = Array.isArray(dataResp) ? dataResp : [];
    renderizarMeusProjetos();
    // Atualiza cards e estatísticas do perfil após carregamento
    carregarPerfilUsuario();
    } catch (error) {
        console.error("Erro ao carregar projetos:", error);
        const grid = document.getElementById("meus-projetos-grid");
        mostrarErro(grid, "Erro de conexão. Verifique sua conexão com a internet.");
    }
}

// Renderizar projetos do usuário
async function renderizarMeusProjetos() {
    const grid = document.getElementById("meus-projetos-grid");
    grid.innerHTML = "";
    
    if (meusProjetos.length === 0) {
            grid.innerHTML = `
                <div class="empty-state">
                <i class="material-icons" style="color: #672D91;">assignment</i>
                <h3 style="color: #672D91;">Nenhum projeto encontrado</h3>
                <p style="color: #8A5ABF;">Você ainda não participa de nenhum projeto. Clique em "CRIAR PROJETO" para começar!</p>
                </div>
            `;
        return;
    }
    
    meusProjetos.forEach(projeto => {
        const card = criarCardMeuProjeto(projeto);
        grid.appendChild(card);
    });
}

// Criar card para projeto do usuário
function criarCardMeuProjeto(projeto) {
    const card = document.createElement("div");
    card.className = "project-card meu-projeto";
    
    // Determinar status baseado na nova estrutura A1/A2
    let statusInfo = determinarStatusAvaliacao(projeto);
    
    card.innerHTML = `
        <div class="project-header">
            <h3>${projeto.titulo_projeto}</h3>
            <div class="status-badges">
                <span class="projeto-status ${statusInfo.statusClass}">${statusInfo.statusText}</span>
                ${statusInfo.progressBadge}
            </div>
        </div>
        <p class="project-description">${projeto.descricao || 'Sem descrição'}</p>
        <div class="project-info">
            <p><strong>Orientador:</strong> ${projeto.nome_orientador || projeto.orientador || "Não definido"}</p>
            <p><strong>Turma:</strong> ${projeto.turma || "N/A"}</p>
            <p><strong>Stand:</strong> ${projeto.posicao || "N/A"}</p>
            ${statusInfo.avaliacoesInfo}
            ${statusInfo.notaFinalInfo}
        </div>
        <div class="card-actions">
            <button class="btn-enter" onclick="visualizarProjeto('${projeto.id_projeto}')">
                <i class="material-icons">visibility</i> Visualizar
            </button>
            <button class="btn-edit" onclick="editarProjeto('${projeto.id_projeto}')">
                <i class="material-icons">edit</i> Editar
            </button>
            ${statusInfo.verNotasButton}
        </div>
    `;
    
    return card;
}

// Função para determinar status de avaliação A1/A2
function determinarStatusAvaliacao(projeto) {
    const qtdAvaliacoes = projeto.qtd_avaliacoes || 0;
    const avaliacoesCompletas = projeto.avaliacoes_completas || false;
    const mediaFinal = projeto.media_final;
    
    let statusInfo = {
        statusClass: '',
        statusText: '',
        progressBadge: '',
        avaliacoesInfo: '',
        notaFinalInfo: '',
        verNotasButton: ''
    };
    
    // Determinar status baseado no número de avaliações
    if (qtdAvaliacoes === 0) {
        statusInfo.statusClass = 'status-aguardando';
        statusInfo.statusText = 'Aguardando Avaliação';
        statusInfo.progressBadge = '<span class="progress-badge aguardando">0/2</span>';
        statusInfo.avaliacoesInfo = '<p><strong>Avaliações:</strong> Nenhuma ainda</p>';
        statusInfo.notaFinalInfo = '<p class="nota-pendente"><strong>Nota Final:</strong> Aguardando avaliações</p>';
    } else if (qtdAvaliacoes === 1) {
        statusInfo.statusClass = 'status-parcial';
        statusInfo.statusText = 'Avaliação Parcial';
        statusInfo.progressBadge = '<span class="progress-badge parcial">1/2</span>';
        statusInfo.avaliacoesInfo = '<p><strong>Avaliações:</strong> 1 professor avaliou (falta 1)</p>';
        statusInfo.notaFinalInfo = '<p class="nota-pendente"><strong>Nota Final:</strong> Aguardando segunda avaliação</p>';
        statusInfo.verNotasButton = `
            <button class="btn-notes-partial" onclick="window.location.href='notas_alunos.html'">
                <i class="material-icons">visibility</i> Ver Avaliação Parcial
            </button>
        `;
    } else if (qtdAvaliacoes >= 2) {
        statusInfo.statusClass = 'status-completo';
        statusInfo.statusText = 'Avaliação Completa';
        statusInfo.progressBadge = '<span class="progress-badge completo">2/2</span>';
        statusInfo.avaliacoesInfo = '<p><strong>Avaliações:</strong> Completa (A1 + A2)</p>';
        
        if (mediaFinal !== null && mediaFinal !== undefined) {
            const mencao = calcularMencao(mediaFinal);
            statusInfo.notaFinalInfo = `
                <p class="nota-final-completa">
                    <strong>Nota Final:</strong> 
                    <span class="nota-valor">${parseFloat(mediaFinal).toFixed(2)}</span>
                    <span class="mencao mencao-${mencao.toLowerCase()}">${mencao}</span>
                </p>
            `;
        } else {
            statusInfo.notaFinalInfo = '<p class="nota-erro"><strong>Nota Final:</strong> Erro no cálculo</p>';
        }
        
        statusInfo.verNotasButton = `
            <button class="btn-notes-complete" onclick="window.location.href='notas_alunos.html'">
                <i class="material-icons">grade</i> Ver Notas Completas
            </button>
        `;
    }
    
    return statusInfo;
}

// Função para calcular menção (mesma lógica do notas_alunos.js)
function calcularMencao(media) {
    if (media >= 7.6) return "MB"; // Muito Bom
    if (media >= 5.1) return "B";  // Bom
    if (media >= 2.6) return "R";  // Regular
    return "I"; // Insuficiente
}

// Carregamento das notas do usuário
async function carregarMinhasNotas() {
    try {
        const container = document.getElementById("notas-container");
        container.innerHTML = '<div class="loading">Carregando suas avaliações...</div>';
        
        // Obter ID do usuário do sessionStorage
        const usuarioStr = sessionStorage.getItem("usuario");
        if (!usuarioStr) {
            mostrarErro(container, "Usuário não autenticado. Faça login novamente.");
            return;
        }
        
        let data, usuario, id_aluno;
        
        try {
            data = JSON.parse(usuarioStr);
            usuario = data.usuario || data;
            
            // Tentar várias formas de obter o ID do aluno
            id_aluno = usuario.id_aluno || 
                      usuario.RM || 
                      usuario.rm || 
                      data.id_aluno ||
                      data.RM ||
                      data.rm;
                      
        } catch (parseError) {
            console.error("Erro ao processar dados do usuário:", parseError);
            mostrarErro(container, "Erro nos dados do usuário");
            return;
        }
        
        if (!id_aluno) {
            mostrarErro(container, "ID do aluno não encontrado");
            return;
        }
        
        // Buscar notas do backend
        const response = await fetch(`${BASE_URL}/api/notas/aluno?id_aluno=${id_aluno}`);
        
        if (!response.ok) {
            throw new Error(`Erro ${response.status}: ${response.statusText}`);
        }
        
        const projetos = await response.json();
        console.log("Projetos com notas:", projetos);
        
        if (projetos.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="material-icons" style="font-size: 3rem; color: #ccc;">assignment</i>
                    <h4>Nenhum projeto encontrado</h4>
                    <p>Você ainda não possui projetos cadastrados.</p>
                    <button class="btn-create" onclick="window.location.href='criar_projeto.html'">
                        CRIAR PRIMEIRO PROJETO
                    </button>
                </div>
            `;
            return;
        }
        
        // Categorizar projetos por status de avaliação
        const projetosCompletos = projetos.filter(p => p.avaliacoes_completas === true);
        const projetosParciais = projetos.filter(p => p.qtd_avaliacoes === 1);
        const projetosAguardando = projetos.filter(p => p.qtd_avaliacoes === 0);
        
        let html = '<div class="notas-summary">';
        
        // Resumo das avaliações com sistema A1/A2
        html += `
            <div class="stats-row">
                <div class="stat-item total">
                    <span class="stat-number">${projetos.length}</span>
                    <span class="stat-label">Total de Projetos</span>
                </div>
                <div class="stat-item completos">
                    <span class="stat-number">${projetosCompletos.length}</span>
                    <span class="stat-label">Completos (2/2)</span>
                </div>
                <div class="stat-item parciais">
                    <span class="stat-number">${projetosParciais.length}</span>
                    <span class="stat-label">Parciais (1/2)</span>
                </div>
                <div class="stat-item aguardando">
                    <span class="stat-number">${projetosAguardando.length}</span>
                    <span class="stat-label">Aguardando (0/2)</span>
                </div>
            </div>
        `;
        
        // Calcular média geral apenas dos projetos completos
        if (projetosCompletos.length > 0) {
            const somaMedias = projetosCompletos.reduce((soma, projeto) => soma + parseFloat(projeto.media_final || 0), 0);
            const mediaGeral = (somaMedias / projetosCompletos.length).toFixed(2);
            const mencaoGeral = calcularMencao(parseFloat(mediaGeral));
            
            html += `
                <div class="media-geral">
                    <h4>Sua Média Geral</h4>
                    <div class="media-display">
                        <span class="media-numero">${mediaGeral}</span>
                        <span class="mencao mencao-${mencaoGeral.toLowerCase()}">${mencaoGeral}</span>
                    </div>
                    <p>Baseada em ${projetosCompletos.length} projeto(s) completamente avaliado(s)</p>
                </div>
            `;
        }
        
        if (projetosCompletos.length > 0) {
            html += `
                <div class="notas-redirect">
                    <h4>🎉 Você possui ${projetosCompletos.length} projeto(s) completamente avaliado(s)!</h4>
                    <p>Clique no botão abaixo para ver todas as suas avaliações detalhadas com A1 e A2.</p>
                    <button class="btn-create" onclick="window.location.href='notas_alunos.html'">
                        <i class="material-icons">grade</i>
                        VER MINHAS NOTAS COMPLETAS
                    </button>
                </div>
            `;
        }
        
        if (projetosParciais.length > 0) {
            html += `
                <div class="notas-parciais">
                    <h4>⚠️ ${projetosParciais.length} projeto(s) com avaliação parcial</h4>
                    <p>Apenas 1 professor avaliou. Aguardando segundo avaliador (A2).</p>
                    <button class="btn-secondary" onclick="window.location.href='notas_alunos.html'">
                        <i class="material-icons">visibility</i>
                        VER AVALIAÇÕES PARCIAIS
                    </button>
                </div>
            `;
        }
        
        if (projetosAguardando.length > 0) {
            html += `
                <div class="notas-pending">
                    <h4>⏳ ${projetosAguardando.length} projeto(s) aguardando avaliação</h4>
                    <p>Seus projetos ainda não foram avaliados por nenhum professor.</p>
                    <i class="material-icons" style="font-size: 3rem; color: #ffa726;">pending</i>
                </div>
            `;
        }
        
        html += '</div>';
        
        // Lista de projetos com status
        html += '<div class="projetos-status">';
        html += '<h4>Status dos Seus Projetos</h4>';
        
        projetos.forEach(projeto => {
            const completo = projeto.avaliacoes_completas === true;
            const statusClass = completo ? 'avaliado' : 'pendente';
            const statusIcon = completo ? 'check_circle' : 'pending';
            const media = projeto.media_final ? `(Nota: ${projeto.media_final})` : '';
            
            html += `
                <div class="projeto-status ${statusClass}">
                    <div class="projeto-info">
                        <h5>${projeto.titulo_projeto}</h5>
                        <p class="projeto-status-text">
                            <i class="material-icons">${statusIcon}</i>
                            ${projeto.status_avaliacao} ${media}
                        </p>
                        ${projeto.nome_orientador ? `<p class="projeto-orientador">Orientador: ${projeto.nome_orientador}</p>` : ''}
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        
        container.innerHTML = html;
        
        // Armazenar para uso em outras funções
        minhasNotas = projetos;
        
    } catch (error) {
        console.error("Erro ao carregar notas:", error);
        const container = document.getElementById("notas-container");
        mostrarErro(container, "Erro ao carregar avaliações. Tente novamente.");
    }
}

// Carregamento do perfil do usuário
function carregarPerfilUsuario() {
    const usuarioStr = sessionStorage.getItem("usuario");
    
    if (usuarioStr) {
        const data = JSON.parse(usuarioStr);
        const usuario = data.usuario || data;
        
        // Preencher dados do perfil
        document.getElementById("profile-nome").textContent = 
            usuario.nome || usuario.nome_aluno || "Nome não disponível";
        document.getElementById("profile-rm").textContent = 
            `RM: ${usuario.rm || usuario.RM || "----"}`;
        document.getElementById("profile-email").textContent = 
            usuario.email || usuario.email_institucional || "email@etec.sp.gov.br";
        document.getElementById("profile-total-projetos").textContent = 
            `Total de projetos: ${meusProjetos.length}`;
        
        // Atualizar estatísticas
        document.getElementById("stat-projetos").textContent = meusProjetos.length;
        
        // Calcular nota média baseada nas notas reais dos projetos carregados
        const projetosComNota = meusProjetos.filter(p => p.media_final && p.media_final > 0);
        if (projetosComNota.length > 0) {
            const media = (projetosComNota.reduce((sum, p) => sum + parseFloat(p.media_final || 0), 0) / projetosComNota.length).toFixed(1);
            document.getElementById("stat-media").textContent = media;
        } else {
            document.getElementById("stat-media").textContent = "0.0";
        }
    }
}

// Configurar pesquisa nos projetos
function configurarPesquisa() {
    const inputPesquisa = document.getElementById("searchMeusProjetos");
    if (inputPesquisa) {
        inputPesquisa.addEventListener("input", function(e) {
            const termo = e.target.value.toLowerCase();
            filtrarMeusProjetos(termo);
        });
    }
}

// Filtrar projetos do usuário
function filtrarMeusProjetos(termo) {
    const projetosFiltrados = termo ? 
        meusProjetos.filter(projeto => 
            projeto.titulo_projeto.toLowerCase().includes(termo) ||
            (projeto.descricao && projeto.descricao.toLowerCase().includes(termo)) ||
            (projeto.nome_orientador && projeto.nome_orientador.toLowerCase().includes(termo))
        ) : meusProjetos;
    
    renderizarProjetosFiltrados(projetosFiltrados);
}

// Renderizar projetos filtrados
function renderizarProjetosFiltrados(projetos) {
    const grid = document.getElementById("meus-projetos-grid");
    grid.innerHTML = "";
    
    if (projetos.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <i class="material-icons">search_off</i>
                <h3>Nenhum projeto encontrado</h3>
                <p>Nenhum projeto corresponde aos termos da sua pesquisa.</p>
            </div>
        `;
        return;
    }
    
    projetos.forEach(projeto => {
        const card = criarCardMeuProjeto(projeto);
        grid.appendChild(card);
    });
}

// Navegação para outras páginas
function visualizarProjeto(idProjeto) {
    localStorage.setItem("projeto_visualizacao", idProjeto);
    window.location.href = "visualizar_projeto.html";
}

function editarProjeto(idProjeto) {
    localStorage.setItem("projeto_edicao", idProjeto);
    window.location.href = "editar_projeto.html";
}

// Funções de logout com modal (mesmo padrão do professor)
function logout() {
    const modal = document.getElementById('logoutModal');
    if (modal) {
        modal.classList.add('show');
    } else {
        // Fallback se modal não estiver presente
        if (confirm('Tem certeza que deseja sair?')) {
            confirmarLogout();
        }
    }
}

function confirmarLogout() {
    // Limpar dados da sessão
    sessionStorage.clear();
    localStorage.clear();
    
    // Redirecionar para a página de login
    window.location.href = 'escolha-login.html';
}

function cancelarLogout() {
    const modal = document.getElementById('logoutModal');
    if (modal) modal.classList.remove('show');
}

// Expor para escopo global quando necessário (botões inline)
window.logout = logout;
window.confirmarLogout = confirmarLogout;
window.cancelarLogout = cancelarLogout;

// Mostrar erro
function mostrarErro(container, mensagem) {
    container.innerHTML = `
        <div class="error-state">
            <i class="material-icons">error_outline</i>
            <h3>Erro</h3>
            <p>${mensagem}</p>
        </div>
    `;
}

// CSS adicional inline para novos estilos
const style = document.createElement('style');
style.textContent = `
    .meu-projeto {
        border-left: 4px solid #672D91;
    }
    
    .project-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;
    }
    
    .projeto-status {
        font-size: 0.8rem;
        padding: 0.3rem 0.8rem;
        border-radius: 12px;
        font-weight: 500;
    }
    
    .status-avaliado {
        background: rgba(76, 175, 80, 0.2);
        color: #4CAF50;
        border: 1px solid rgba(76, 175, 80, 0.3);
    }
    
    .status-pendente {
        background: rgba(255, 193, 7, 0.2);
        color: #FFC107;
        border: 1px solid rgba(255, 193, 7, 0.3);
    }
    
    .project-description {
        color: rgba(85, 85, 85, 0.9);
        margin-bottom: 1rem;
        font-size: 0.9rem;
    }
    
    .project-info {
        margin-bottom: 1.5rem;
    }
    
    .project-info p {
        color: rgba(51, 51, 51, 0.8);
        margin-bottom: 0.3rem;
        font-size: 0.9rem;
    }
    
    .btn-edit {
        background: linear-gradient(135deg, #672D91, #8A5ABF);
        color: #FFFFFF;
        border: none;
        padding: 0.6rem 1rem;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-family: 'Poppins', sans-serif;
        font-size: 0.9rem;
    }
    
    .btn-edit:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(103, 45, 145, 0.3);
    }
    
    .notas-redirect {
        text-align: center;
        padding: 2rem;
    }
    
    .notas-redirect h4 {
        color: #FFFFFF;
        margin-bottom: 1rem;
    }
    
    .notas-redirect p {
        color: #D2B4FF;
        margin-bottom: 2rem;
    }
    
    .projeto-orientador {
        color: rgba(255, 255, 255, 0.6);
        font-size: 0.85rem;
        margin-top: 0.5rem;
        font-style: italic;
    }
`;
document.head.appendChild(style);