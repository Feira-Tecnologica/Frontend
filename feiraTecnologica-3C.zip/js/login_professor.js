document.addEventListener('DOMContentLoaded', () => {
  // Procura pelo formulário esperado; fallback para .form-lg ou primeiro <form>
  const form = document.getElementById('loginProfessorForm') || document.querySelector('.form-lg') || document.querySelector('form');
  const erroLogin = document.getElementById('erroLogin') || document.querySelector('#erroLogin') || document.createElement('div');

  // Se não existir um elemento visível para erros, anexa um pequeno nó para mostrar mensagens (não intrusivo)
  if (!document.getElementById('erroLogin')) {
    erroLogin.id = 'erroLogin';
    erroLogin.style.color = 'red';
    erroLogin.style.marginTop = '8px';
    if (form) form.appendChild(erroLogin);
  }

  if (!form) {
    console.error('Formulário de login não encontrado');
    return;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Estratégia de seleção: ids preferenciais, depois placeholders, depois ordem de inputs com classe
    const findByPlaceholder = (txt) => form.querySelector(`input[placeholder*="${txt}"]`);

    let matriculaElement = document.getElementById('matricula') || findByPlaceholder('Matr') || (function(){
      const arr = form.querySelectorAll('.email-2');
      return arr.length > 0 ? arr[0] : null;
    })();

    let emailElement = document.getElementById('email') || findByPlaceholder('E-mail') || (function(){
      const arr = form.querySelectorAll('.email-2');
      return arr.length > 1 ? arr[1] : (arr.length === 1 ? arr[0] : null);
    })();

    if (!emailElement || !matriculaElement) {
      console.error('Email or Matricula input not found', { emailElement, matriculaElement });
      erroLogin.textContent = 'Campos de login não encontrados na página.';
      return;
    }

    const email = emailElement.value.trim();
    const matricula = matriculaElement.value.trim();

    try {
      const response = await fetch((window.BASE_URL || '') + '/api/login/professor', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, matricula }),
        credentials: 'include' // Importante para manter sessão
      });
      const data = await response.json();

      if (response.ok) {
        // Salvar apenas os dados do usuário no localStorage para usar nas outras páginas
        localStorage.setItem('usuario_logado', JSON.stringify(data.usuario));
        sessionStorage.setItem('usuario', JSON.stringify(data));
        
        // Redirecionar para o dashboard do professor
        window.location.href = 'dash-prof.html';
      } else {
        erroLogin.textContent = data.message || 'Erro ao fazer login';
      }
    } catch (err) {
      console.error(err);
      erroLogin.textContent = 'Erro de rede. Tente novamente.';
    }
  });
});