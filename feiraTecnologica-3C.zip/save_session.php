<?php
    // Inicia a sessão PHP
    session_start();
    include('Backend/Config/connection.php');
    // Define o cabeçalho para permitir requisições de qualquer origem (CORS)
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    header("Access-Control-Allow-Methods: POST, OPTIONS");
    header('Content-Type: application/json');

    // Lida com requisições OPTIONS (preflight requests)
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }

    // Decodifica o JSON recebido do JavaScript
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    // Verifica se os dados necessários foram recebidos
    if (isset($data['user']) && isset($data['type'])) {
        $user = $data['user'];
        $type = $data['type'];

        // Armazena os dados do usuário na sessão
        $_SESSION['logged_in'] = true;
        $_SESSION['user_id'] = $user['id_aluno'] ?? $user['id_professor'] ?? null; // Pega o ID do aluno ou professor
        $_SESSION['user_type'] = $type;
        $_SESSION['user_data'] = $user; // Armazena todos os dados do usuário, se necessário

        // Retorna uma resposta de sucesso
        echo json_encode(["mensagem" => "Sessão salva com sucesso!"]);
        http_response_code(200);
    } else {
        // Retorna uma resposta de erro se os dados estiverem faltando
        echo json_encode(["erro" => "Dados do usuário ou tipo de usuário ausentes."]);
        http_response_code(400);
    }
?>
