<?php
  session_start(); // Inicia a sessão

  // lógica para receber os dados do formulário
  $email = $_POST['email'];
  $senha = $_POST['senha'];
  $rm = $_POST['rm'];

  // Determina a base URL da API a partir do .env (ou fallback)
  $envPath = __DIR__ . '/.env';
  $base = 'http://localhost/feira_tecnologica_avaliacoes/Backend'; // fallback
  if (file_exists($envPath)) {
    $parsed = parse_ini_file($envPath);
    if ($parsed !== false && isset($parsed['base_url']) && $parsed['base_url']) {
      $base = rtrim($parsed['base_url'], '/');
    }
  }

  // Chamada com cURL para a API para verificar o login
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $base . '/api/login/aluno');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['email' => $email, 'senha' => $senha, 'rm' => $rm]));
  curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

  $response = curl_exec($ch);
  curl_close($ch);

  $result = json_decode($response, true);

  if (isset($result['mensagem']) && $result['mensagem'] === "Login bem-sucedido") {
      // Armazenamento dos dados do aluno na sessão
      $_SESSION['id_aluno'] = $result['usuario']['id_aluno']; // Armazena o ID do aluno
      $_SESSION['logged_in'] = true; // Marca como logado
      $_SESSION['user_type'] = 'aluno'; // Define o tipo de usuário
      $_SESSION['rm'] = $result['usuario']['RM']; // Armazena o RM do aluno
      $_SESSION['nome_aluno'] = $result['usuario']['nome_aluno']; // Armazena o nome do aluno
      $_SESSION['email'] = $result['usuario']['email_institucional']; // Armazena o email do aluno
      // Redireciona para a página de escolha de projeto
      header("Location: escolher_projeto.php");
      exit();
  } else {
      // Tratativa de erro de login
      echo "Erro: " . $result['erro'];
  }
?>
