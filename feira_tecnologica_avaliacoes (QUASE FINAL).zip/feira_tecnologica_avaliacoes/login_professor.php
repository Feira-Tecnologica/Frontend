
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Login Professor</title>
  <link rel="stylesheet" href="css/login.css" />
</head>
<body>
  <div class="container" id="container">
    <div class="form-container login-container">
      <form id="loginProfessorForm">
        <h1>Entrar</h1>
        <?php if (!empty($erro_login)) echo "<p style='color:red;'>$erro_login</p>"; ?>
        <div class="form-control">
          <input type="text" name="matricula" placeholder="Matrícula" required />
        </div>
        <div class="form-control">
          <input type="email" name="email" placeholder="E-mail institucional" required />
        </div>
        
        <button type="submit">Entrar</button>
      </form>
    </div>
  </div>
  <script src="Backend/config.js.php"></script>
  <script src="js/login_professor.js"></script>
</body>
</html>
