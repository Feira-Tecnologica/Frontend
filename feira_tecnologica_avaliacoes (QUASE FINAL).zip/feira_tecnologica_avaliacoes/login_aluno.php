<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8" />
  <title>Login Aluno</title>
  <link rel="stylesheet" href="css/login.css">
</head>

<body>
  <div class="container" id="container">
    <div class="form-container login-container">
  <form id="loginAlunoForm">
  <h1>Entrar</h1>
  <!-- Área para exibir mensagem de erro via JS -->
  <div id="erroLogin" style="color:red; margin-bottom:1rem;"></div>
        <div class="form-control">
          <input id="email" type="email" name="email" placeholder="E-mail institucional" required />
        </div>
        <div class="form-control">
          <input id="rm" type="text" name="rm" placeholder="RM" required />
        </div>
        <div class="form-control">
          <input id="senha" type="password" name="senha" placeholder="Senha" required />
        </div>
        <button type="submit">Entrar</button>
  </form>
  <script src="Backend/config.js.php"></script>
  <script src="js/login_aluno.js"></script>
    </div>
  </div>
</body>

</html>