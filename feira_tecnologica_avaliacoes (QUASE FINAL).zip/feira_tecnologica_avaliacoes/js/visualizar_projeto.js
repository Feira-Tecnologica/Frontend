// Variáveis globais
let projetoAtual = null;
let usuarioAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    verificarUsuarioLogado();
    carregarProjeto();
});

function verificarUsuarioLogado() {
    // Verificar se há dados do usuário no localStorage
    const dadosUsuario = localStorage.getItem('usuario_logado');
    if (dadosUsuario) {
        try {
            usuarioAtual = JSON.parse(dadosUsuario);
        } catch (e) {
            console.error('Erro ao recuperar dados do usuário:', e);
        }
    }
}

function carregarProjeto() {
    // Verificar se há um ID de projeto na URL ou localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const idProjeto = urlParams.get('id') || localStorage.getItem('projeto_visualizacao');
    console.log('Visualizar Projeto ID:', idProjeto);
    if (idProjeto) {
        buscarDadosProjeto(idProjeto);
    } else {
        mostrarErro('Nenhum projeto selecionado para visualização');
    }
}

async function buscarDadosProjeto(idProjeto) {
    console.log('Buscando dados do projeto com ID:', idProjeto);
    try {
        // Busca direta pelo GET /api/projetos e seleciona o projeto pelo id (sem depender de rota POST inexistente)
    const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
    const listResp = await fetch(apiBase + '/api/projetos');
        if (!listResp.ok) {
            const txt = await listResp.text();
            console.error('GET /api/projetos retornou erro:', listResp.status, txt);
            mostrarErro('Não foi possível carregar os dados do projeto.');
            return;
        }

        const listText = await listResp.text();
        let listData;
        try {
            listData = JSON.parse(listText);
        } catch (e) {
            console.error('Erro ao parsear resposta de /api/projetos:', e, listText);
            mostrarErro('Resposta inválida do servidor ao obter lista de projetos.');
            return;
        }

        // Normalizar formatos possíveis: array direto, { status:'success', data: [...] }, { projetos: [...] }
        let projetosLista = [];
        if (Array.isArray(listData)) {
            projetosLista = listData;
        } else if (listData && Array.isArray(listData.data)) {
            projetosLista = listData.data;
        } else if (listData && Array.isArray(listData.projetos)) {
            projetosLista = listData.projetos;
        } else {
            console.warn('Formato inesperado para lista de projetos:', listData);
        }

        // Procurar pelo projeto pelo id (string ou number)
        const found = projetosLista.find(p => String(p.id_projeto) === String(idProjeto) || String(p.id) === String(idProjeto));
        if (found) {
            projetoAtual = found;
            console.log('Projeto encontrado:', projetoAtual);
            console.log('Campo orientador do projeto:', projetoAtual.orientador);
            atualizarInterface();
            return;
        }

        // Se não encontrou, tenta também buscar por título como último recurso
        const foundByTitle = projetosLista.find(p => p.titulo_projeto && p.titulo_projeto.toLowerCase().includes(String(idProjeto).toLowerCase()));
        if (foundByTitle) {
            projetoAtual = foundByTitle;
            atualizarInterface();
            return;
        }

        mostrarErro('Projeto não encontrado.');
        return;
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarErro('Erro de conexão');
    }
}

// Função para exibir erros na tela
function mostrarErro(mensagem) {
    console.error(mensagem);
    const container = document.querySelector('.content-container');
    if (container) {
        const erro = document.createElement('div');
        erro.className = 'error-message';
        erro.style.textAlign = 'center';
        erro.style.padding = '20px';
        erro.style.color = '#ff4444';
        erro.innerHTML = `<p>${mensagem}</p>`;
        container.innerHTML = '';
        container.appendChild(erro);
    }
}

function atualizarInterface() {
    if (!projetoAtual) return;

    // Agora usamos os campos separados do banco de dados
    const descText = projetoAtual.descricao || '';
    const objText = projetoAtual.objetivo || '';
    const justText = projetoAtual.justificativa || '';

    // Atualizar título do projeto
    const tituloElement = document.querySelector('.project-name');
    if (tituloElement) {
        tituloElement.textContent = projetoAtual.titulo_projeto || 'Projeto sem título';
    }

    // Atualizar informações do stand
    const standElement = document.querySelector('.stand-info strong');
    if (standElement) {
        standElement.textContent = `STAND ${projetoAtual.posicao || 'N/A'}`;
    }

    const turmaElement = document.querySelector('.class-info span');
    if (turmaElement) {
        turmaElement.innerHTML = `${projetoAtual.turma || 'Turma não definida'}<br>`;
    }

    // Atualizar integrantes
    atualizarIntegrantes();

    // Atualizar professor orientador
    atualizarOrientador();

    // Atualizar descrição
    const descricaoElement = document.getElementById('descricao-content');
    if (descricaoElement) {
        descricaoElement.textContent = descText || 'Descrição não disponível';
    }

    // Atualizar objetivo
    const objetivoElement = document.getElementById('objetivo-content');
    if (objetivoElement) {
        objetivoElement.textContent = objText || 'Objetivo não definido';
    }

    // Atualizar justificativa
    const justificativaElement = document.getElementById('justificativa-content');
    if (justificativaElement) {
        justificativaElement.textContent = justText || 'Justificativa não definida';
    }

    // Atualizar ODS
    atualizarODS();
    
    // Verificar permissões e atualizar interface
    verificarPermissoesEdicao();
    
    // Atualizar links de edição
    atualizarLinksEdicao();
}

function atualizarIntegrantes() {
    const integrantesContainer = document.querySelector('.integrantes-display');
    if (!integrantesContainer) return;

    integrantesContainer.innerHTML = '';

    // Se já vierem os integrantes no objeto do projeto, usa direto
    if (projetoAtual.integrantes) {
        const integrantes = projetoAtual.integrantes.split(', ');
        integrantes.forEach(nome => {
            const card = document.createElement('div');
            card.className = 'integrante-card';
            card.textContent = nome.trim();
            integrantesContainer.appendChild(card);
        });
        return;
    }

    // Buscar alunos usando a rota correta do backend
    if (projetoAtual.id_projeto) {
        const apiBaseInt = (window.BASE_URL || '').replace(/\/$/, '');
        fetch(apiBaseInt + '/api/projetos/alunos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_projeto: projetoAtual.id_projeto
            })
        })
        .then(resp => {
            if (!resp.ok) throw new Error('Erro ao obter integrantes');
            return resp.json();
        })
        .then(data => {
            if (!Array.isArray(data) || data.length === 0) {
                integrantesContainer.innerHTML = '<p style="color: #666;">Nenhum integrante cadastrado</p>';
                return;
            }

            data.forEach(aluno => {
                const card = document.createElement('div');
                card.className = 'integrante-card';
                card.textContent = aluno.nome_aluno || aluno.nome || aluno.id_aluno;
                integrantesContainer.appendChild(card);
            });
        })
        .catch(err => {
            console.error('Falha ao carregar integrantes:', err);
            integrantesContainer.innerHTML = '<p style="color: #666;">Nenhum integrante cadastrado</p>';
        });
        return;
    }

    integrantesContainer.innerHTML = '<p style="color: #666;">Nenhum integrante cadastrado</p>';
}

async function atualizarOrientador() {
    const orientadorContainer = document.getElementById('orientador-display');
    if (!orientadorContainer) return;

    console.log('=== ATUALIZAR ORIENTADOR ===');
    console.log('Projeto atual:', projetoAtual);
    console.log('Campo orientador:', projetoAtual.orientador);
    console.log('Tipo do orientador:', typeof projetoAtual.orientador);

    // Verificar se o projeto tem orientador definido (incluindo string vazia, null, undefined)
    if (!projetoAtual.orientador || projetoAtual.orientador === '' || projetoAtual.orientador === 'null') {
        console.log('Nenhum orientador definido para o projeto');
        orientadorContainer.innerHTML = '<p style="color: #666;">Nenhum orientador definido</p>';
        return;
    }

    // Mostrar loading
    orientadorContainer.innerHTML = '<p style="color: #666;">Carregando orientador...</p>';

    try {
        // Buscar dados do professor orientador
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/professores', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao carregar professores');
        }

        const professores = await response.json();
        console.log('Professores carregados:', professores);
        
        if (!Array.isArray(professores)) {
            throw new Error('Formato inválido de resposta');
        }

        // Encontrar o professor orientador - tentar múltiplas comparações
        const orientadorId = String(projetoAtual.orientador).trim();
        const orientador = professores.find(prof => {
            const profId = String(prof.id_professor).trim();
            const profNome = String(prof.nome_professor || '').trim().toLowerCase();
            const orientadorNome = orientadorId.toLowerCase();
            
            return profId === orientadorId || 
                   profNome === orientadorNome ||
                   prof.nome_professor === projetoAtual.orientador;
        });

        console.log('Orientador encontrado:', orientador);
        console.log('Comparação: Procurando por ID/Nome =', orientadorId);

        if (orientador) {
            // Exibir informações do orientador
            orientadorContainer.innerHTML = `
                <div class="orientador-card">
                    <div class="orientador-info">
                        <strong>${orientador.nome_professor}</strong>
                        <p style=" font-size: 0.9em;">${orientador.email}</p>
                    </div>
                </div>
            `;
        } else {
            // Se não encontrou o professor, exibir o valor como estava
            orientadorContainer.innerHTML = `
                <div class="orientador-card">
                    <div class="orientador-info">
                        <strong>${projetoAtual.orientador}</strong>
                        <p style=" font-size: 0.9em;">Professor não encontrado no sistema</p>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar orientador:', error);
        orientadorContainer.innerHTML = '<p style="color: #666;">Erro ao carregar orientador</p>';
    }
}

function atualizarODS() {
    const odsContainer = document.getElementById('ods-display');
    if (!odsContainer) return;

    odsContainer.innerHTML = '';

    // Se o projeto já traz dados das ODS, usa-os
    if (projetoAtual.ods_ids && projetoAtual.ods_nomes) {
        const odsIds = projetoAtual.ods_ids.split(',');
        const odsNomes = projetoAtual.ods_nomes.split(' | ');
        const odsColors = {
            '1': '#E5243B', '2': '#DDA83A', '3': '#4C9F38', '4': '#C5192D', '5': '#FF3A21',
            '6': '#26BDE2', '7': '#FCC30B', '8': '#A21942', '9': '#FD6925', '10': '#DD1367',
            '11': '#FD9D24', '12': '#BF8B2E', '13': '#3F7E44', '14': '#0A97D9', '15': '#56C02B',
            '16': '#00689D', '17': '#19486A'
        };
        odsIds.forEach((id, index) => {
            if (odsNomes[index]) {
                const odsItem = document.createElement('div');
                odsItem.className = 'ods-item-display';
                odsItem.innerHTML = `
                    <div class="ods-icon" style="background-color: ${odsColors[id.trim()] || '#666'}">${id.trim()}</div>
                    <div class="ods-info">
                        <strong>ODS ${id.trim()} - ${odsNomes[index].trim()}</strong>
                    </div>
                `;
                odsContainer.appendChild(odsItem);
            }
        });
        return;
    }

    // Buscar ODS usando a rota correta do backend
    if (projetoAtual.id_projeto) {
        const apiBaseOds = (window.BASE_URL || '').replace(/\/$/, '');
        fetch(apiBaseOds + '/api/projetos/ods-projeto', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_projeto: projetoAtual.id_projeto
            })
        })
        .then(resp => {
            if (!resp.ok) throw new Error('Erro ao obter ODS');
            return resp.json();
        })
        .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    odsContainer.innerHTML = '<p style="color: #666;">Nenhuma ODS associada ao projeto</p>';
                    return;
                }

                const odsColors = {
                    '1': '#E5243B', '2': '#DDA83A', '3': '#4C9F38', '4': '#C5192D', '5': '#FF3A21',
                    '6': '#26BDE2', '7': '#FCC30B', '8': '#A21942', '9': '#FD6925', '10': '#DD1367',
                    '11': '#FD9D24', '12': '#BF8B2E', '13': '#3F7E44', '14': '#0A97D9', '15': '#56C02B',
                    '16': '#00689D', '17': '#19486A'
                };

                data.forEach(item => {
                    const id = String(item.id_ods || item.id);
                    const name = item.nome || '';
                    const odsItem = document.createElement('div');
                    odsItem.className = 'ods-item-display';
                    odsItem.innerHTML = `
                        <div class="ods-icon" style="background-color: ${odsColors[id.trim()] || '#666'}">${id.trim()}</div>
                        <div class="ods-info">
                            <strong>ODS ${id.trim()}${name ? ' - ' + name : ''}</strong>
                        </div>
                    `;
                    odsContainer.appendChild(odsItem);
                });
            })
            .catch(err => {
                console.error('Falha ao carregar ODS:', err);
                odsContainer.innerHTML = '<p style="color: #666;">Nenhuma ODS associada ao projeto</p>';
            });
        return;
    }

    odsContainer.innerHTML = '<p style="color: #666;">Nenhuma ODS associada ao projeto</p>';
}

function verificarPermissoesEdicao() {
    const editButton = document.querySelector('#btn-edit-projeto');
    
    // SEMPRE começar com o botão oculto
    if (editButton) editButton.style.display = 'none';
    
    // Se não há usuário logado ou projeto, oculta todas as opções de edição
    if (!usuarioAtual || !projetoAtual) {
        mostrarMensagemPermissao('Faça login para visualizar opções de edição');
        return;
    }
    
    // Por padrão, não pode editar
    let podeEditar = false;
    let motivoNegacao = '';
    
    console.log('=== VERIFICAÇÃO DE PERMISSÕES ===');
    console.log('Usuario logado:', usuarioAtual);
    console.log('Projeto atual:', projetoAtual);
    
    // Para professores, verificar se é o professor responsável pelo projeto
    if (usuarioAtual.tipo === 'professor') {
        const professorLogadoId = usuarioAtual.id || usuarioAtual.id_professor;
        const professorProjetoId = projetoAtual.id_professor;
        
        console.log('VERIFICAÇÃO PROFESSOR:');
        console.log('- ID do professor logado:', professorLogadoId);
        console.log('- ID do professor do projeto:', professorProjetoId);
        console.log('- Tipos:', typeof professorLogadoId, typeof professorProjetoId);
        
        if (professorLogadoId && professorProjetoId) {
            podeEditar = String(professorLogadoId) === String(professorProjetoId);
            console.log('- Comparação String(', professorLogadoId, ') === String(', professorProjetoId, '):', podeEditar);
        } else {
            console.log('- Um dos IDs está vazio/null');
            podeEditar = false;
        }
        
        if (!podeEditar) {
            motivoNegacao = 'Apenas o professor responsável pelo projeto pode editá-lo';
        }
    }
    
    // Para alunos, verificar se é um dos integrantes/criadores do projeto
    if (usuarioAtual.tipo === 'aluno') {
        console.log('VERIFICAÇÃO ALUNO:');
        console.log('- ID do aluno logado:', usuarioAtual.id);
        console.log('- ID do criador do projeto:', projetoAtual.criado_por);
        console.log('- ID do aluno do projeto:', projetoAtual.id_aluno);
        
        // Verificar se é o criador
        if (projetoAtual.criado_por) {
            podeEditar = String(usuarioAtual.id) === String(projetoAtual.criado_por);
            console.log('- É o criador?', podeEditar);
        } else if (projetoAtual.id_aluno) {
            podeEditar = String(usuarioAtual.id) === String(projetoAtual.id_aluno);
            console.log('- É o aluno do projeto?', podeEditar);
        }
        
        // Se não é o criador direto, verificar se é integrante (função assíncrona)
        if (!podeEditar) {
            console.log('- Verificando se é integrante...');
            verificarSeEIntegrante().then(isIntegrante => {
                console.log('- É integrante?', isIntegrante);
                if (isIntegrante) {
                    if (editButton) {
                        editButton.style.display = 'inline-flex';
                        console.log('- Botão EXIBIDO (integrante)');
                    }
                    removerMensagemPermissao();
                } else {
                    if (editButton) {
                        editButton.style.display = 'none';
                        console.log('- Botão OCULTADO (não é integrante)');
                    }
                    mostrarMensagemPermissao('Apenas integrantes do projeto podem editá-lo');
                }
            });
            return; // Sai da função aqui para aguardar o resultado assíncrono
        }
        
        if (!podeEditar && !motivoNegacao) {
            motivoNegacao = 'Apenas integrantes do projeto podem editá-lo';
        }
    }
    
    console.log('RESULTADO FINAL:');
    console.log('- Pode editar:', podeEditar);
    console.log('- Motivo da negação:', motivoNegacao);
    
    // FORÇAR a atualização do botão
    if (editButton) {
        if (podeEditar) {
            editButton.style.display = 'inline-flex';
            console.log('- Botão EXIBIDO');
            removerMensagemPermissao();
        } else {
            editButton.style.display = 'none';
            console.log('- Botão OCULTADO');
            if (motivoNegacao) {
                mostrarMensagemPermissao(motivoNegacao);
            }
        }
    }
    
    console.log('=== FIM DA VERIFICAÇÃO ===');
}

async function verificarSeEIntegrante() {
    if (!projetoAtual.id_projeto || !usuarioAtual.id) return false;
    
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/alunos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_projeto: projetoAtual.id_projeto
            })
        });
        
        if (!response.ok) return false;
        
        const integrantes = await response.json();
        if (!Array.isArray(integrantes)) return false;
        
        return integrantes.some(integrante => 
            String(integrante.id_aluno) === String(usuarioAtual.id) ||
            String(integrante.id) === String(usuarioAtual.id)
        );
    } catch (error) {
        console.error('Erro ao verificar integrantes:', error);
        return false;
    }
}

function mostrarMensagemPermissao(mensagem) {
    const container = document.querySelector('.action-buttons');
    if (!container) return;
    
    // Remover mensagem anterior se existir
    removerMensagemPermissao();
    
    const info = document.createElement('p');
    info.className = 'permission-info';
    info.textContent = mensagem;
    container.appendChild(info);
}

function removerMensagemPermissao() {
    const infoExistente = document.querySelector('.permission-info');
    if (infoExistente) {
        infoExistente.remove();
    }
}

function atualizarLinksEdicao() {
    if (!projetoAtual) return;
    
    // Atualizar o botão de editar projeto
    const editButton = document.querySelector('#btn-edit-projeto');
    if (editButton) {
        editButton.onclick = () => {
            window.location.href = `editar_projeto.html?id=${projetoAtual.id_projeto}`;
        };
    }
}

async function verificarNotas() {
    try {
    const apiBaseNotas = (window.BASE_URL || '').replace(/\/$/, '');
    const response = await fetch(apiBaseNotas + '/api/notas/buscar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id_projeto: projetoAtual.id_projeto })
        });

        if (response.ok) {
            const dadosNota = await response.json();
            if (dadosNota.criatividade !== null) {
                mostrarNotas(dadosNota);
            }
        }
    } catch (error) {
        console.error('Erro ao verificar notas:', error);
    }
}

function mostrarNotas(dadosNota) {
    // Criar seção de notas se não existir
    let secaoNotas = document.querySelector('.secao-notas');
    if (!secaoNotas) {
        secaoNotas = document.createElement('div');
        secaoNotas.className = 'section secao-notas';
        secaoNotas.innerHTML = `
            <h4 class="section-title">
                <i class="material-icons">grade</i>
                Avaliação
            </h4>
            <div class="notas-container"></div>
        `;
        
        const projectContent = document.querySelector('.project-content');
        if (projectContent) {
            projectContent.appendChild(secaoNotas);
        }
    }

    const notasContainer = secaoNotas.querySelector('.notas-container');
    if (notasContainer) {
        notasContainer.innerHTML = `
            <div class="notas-grid">
                <div class="nota-item">
                    <span>Criatividade:</span>
                    <span class="nota-valor">${dadosNota.criatividade}</span>
                </div>
                <div class="nota-item">
                    <span>Capricho:</span>
                    <span class="nota-valor">${dadosNota.capricho}</span>
                </div>
                <div class="nota-item">
                    <span>Abordagem:</span>
                    <span class="nota-valor">${dadosNota.abordagem}</span>
                </div>
                <div class="nota-item">
                    <span>Domínio:</span>
                    <span class="nota-valor">${dadosNota.dominio}</span>
                </div>
                <div class="nota-item">
                    <span>Postura:</span>
                    <span class="nota-valor">${dadosNota.postura}</span>
                </div>
                <div class="nota-item">
                    <span>Oralidade:</span>
                    <span class="nota-valor">${dadosNota.oralidade}</span>
                </div>
                <div class="nota-resumo">
                    <div class="media-final">
                        <span>Média:</span>
                        <span class="nota-valor destaque">${dadosNota.media}</span>
                    </div>
                    <div class="mencao-final">
                        <span>Menção:</span>
                        <span class="mencao-valor destaque">${dadosNota.mencao}</span>
                    </div>
                </div>
                ${dadosNota.comentario ? `
                    <div class="comentario">
                        <strong>Comentário:</strong>
                        <p>${dadosNota.comentario}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }
}
