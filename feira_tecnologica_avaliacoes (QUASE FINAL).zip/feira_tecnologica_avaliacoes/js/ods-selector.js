class ODSSelector {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.selectedODS = new Set();
        this.allODS = [];
        this.init();
    }

    async init() {
        await this.carregarODS();
        this.render();
        this.bindEvents();
    }

    async carregarODS() {
        try {
            console.log('Carregando ODS do banco...');
            
           
            
            const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
            const response = await fetch(apiBase + '/api/ods');

            if (response.ok) {
                // A API retorna um array puro de ODS
                const odsArray = await response.json();
                
                // Check if the response is an error object
                if (odsArray && typeof odsArray === 'object' && odsArray.error) {
                    console.error('Erro da API:', odsArray.error);
                    alert('Erro ao carregar ODS: ' + odsArray.error);
                    this.allODS = [];
                    return;
                }
                
                if (!Array.isArray(odsArray)) {
                    console.error('Formato inesperado de retorno de ODS:', odsArray);
                    this.allODS = [];
                } else {
                    this.allODS = odsArray.map(ods => ({
                        id: ods.id_ods,
                        title: ods.nome,
                        description: ods.descricao
                    }));
                    console.log('ODS carregadas:', this.allODS);
                }
            } else {
                console.error('Erro HTTP ao carregar ODS:', response.status);
                const errorText = await response.text();
                console.error('Resposta de erro:', errorText);
                alert('Erro HTTP ao carregar ODS: ' + response.status + ' - ' + errorText);
                this.allODS = [];
            }
        } catch (error) {
            console.error('Erro ao carregar ODS:', error);
            alert('Erro de conexão ao carregar ODS: ' + error.message + '\n\nVerifique:\n1. XAMPP está rodando\n2. Banco de dados foi importado\n3. Credenciais estão corretas');
            this.allODS = [];
        }
    }

    render() {
        this.container.innerHTML = `
            <div class="ods-container">
                <div class="ods-select-wrapper">
                    <select class="ods-select" id="odsSelect">
                        <option value="">Selecione um ODS...</option>
                        ${this.allODS.map(ods => 
                            `<option value="${ods.id}">ODS ${ods.id} - ${ods.title}</option>`
                        ).join('')}
                    </select>
                </div>
                <div class="ods-selected-list" id="selectedODSList"></div>
                <div class="ods-grid" id="odsGrid"></div>
            </div>
        `;
    }

    bindEvents() {
        const select = document.getElementById('odsSelect');
        select.addEventListener('change', (e) => {
            if (e.target.value) {
                this.addODS(parseInt(e.target.value));
                e.target.value = '';
            }
        });
    }

    addODS(odsId) {
        if (!this.selectedODS.has(odsId)) {
            this.selectedODS.add(odsId);
            this.updateDisplay();
        }
    }

    removeODS(odsId) {
        this.selectedODS.delete(odsId);
        this.updateDisplay();
    }

    updateDisplay() {
        this.updateSelectedList();
        this.updateGrid();
    }

    updateSelectedList() {
        const listContainer = document.getElementById('selectedODSList');
        const selectedArray = Array.from(this.selectedODS);
        
        if (selectedArray.length === 0) {
            listContainer.innerHTML = '';
            return;
        }
        
        listContainer.innerHTML = selectedArray.map(odsId => {
            const ods = this.allODS.find(o => o.id === odsId);
            return `
                <div class="ods-item">
                    <span class="ods-number">ODS ${ods.id}</span>
                    <span>${ods.title}</span>
                    <button class="remove-btn" onclick="odsSelector.removeODS(${ods.id})">×</button>
                </div>
            `;
        }).join('');
    }

    updateGrid() {
        const gridContainer = document.getElementById('odsGrid');
        const selectedArray = Array.from(this.selectedODS);
        
        if (selectedArray.length === 0) {
            gridContainer.innerHTML = '<div class="ods-empty-state">Nenhum ODS selecionado</div>';
            return;
        }
        
        gridContainer.innerHTML = selectedArray.map(odsId => {
            const ods = this.allODS.find(o => o.id === odsId);
            const colors = [
                '#E5243B', '#DDA63A', '#4C9F38', '#C5192D', '#FF3A21',
                '#26BDE2', '#FCC30B', '#A21942', '#FD6925', '#DD1367',
                '#FD9D24', '#BF8B2E', '#3F7E44', '#0A97D9', '#56C02B',
                '#00689D', '#19486A'
            ];
            
            return `
                <div class="ods-card">
                    <div class="ods-header">
                        <div class="ods-icon" style="background-color: ${colors[odsId - 1] || '#666'}">${ods.id}</div>
                        ODS ${ods.id} - ${ods.title}
                    </div>
                    <div class="ods-description">${ods.description}</div>
                </div>
            `;
        }).join('');
    }

    getSelectedODS() {
        return Array.from(this.selectedODS);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('odsContainer')) {
        window.odsSelector = new ODSSelector('odsContainer');
    }
});
