# Sistema de Avaliação da Feira Tecnológica (ETEC MCM)

Plataforma interna para a IV Feira Tecnológica da ETEC MCM: alunos cadastram e gerenciam projetos, professores realizam as avaliações (A1 e A2), e a média/menção final do projeto é calculada automaticamente.

## Visão Geral

- Perfis: Aluno e Professor.
- Aluno: cria/edita projeto, adiciona colegas, vincula ODS, acompanha status e visualiza notas/menção.
- Professor: faz login e avalia projetos como Avaliador 1 (A1) ou Avaliador 2 (A2); acompanha status geral; também pode criar projetos via a página de projetos do professor (`dash-prof2.html`) usando o botão "Criar Projeto" (abre `criar_projeto.html`).
- Cálculo automático: média final e menção final (I, R, B, MB) do projeto.
- Setup simples: um único arquivo SQL (`banco_feira.sql`) já cria e popula tudo (tabelas, dados iniciais, visões, constraints e campos A1/A2).

## Arquitetura

- Frontend: HTML/CSS/JS estático (páginas na raiz e em `css/` e `js/`).
- Backend: PHP (roteador simples em `Backend/`, controllers por domínio, CORS habilitado).
- API REST: endpoints sob `.../Backend/api/...` definidos em `Backend/Routes/rotas.php`.
- Banco: MySQL/MariaDB; dump completo em `banco_feira.sql` (inclui seeds e view `view_status_avaliacoes`).
- Config de URL para o frontend via `Backend/config.js.php` (expõe `window.BASE_URL`).

Fluxo em alto nível:
1) Usuário acessa `index.html` → 2) login (aluno ou professor) → 3) ações no dashboard → 4) backend atende via API → 5) dados persistidos no MySQL e refletidos na UI.

## Modelagem de Dados (principal)

- `aluno (id_aluno, nome_aluno, rm, email_institucional, senha, ...)`
- `professor (id_professor, nome_professor, email, matricula, ...)`
- `projeto (id_projeto, titulo_projeto, descricao, ...,
  media_final DECIMAL(3,1), mencao_final VARCHAR(2), criador_id)`
- `nota (id_nota, ... critérios ..., media, comentario, id_professor, id_projeto,
  avaliador_numero TINYINT [1=A1, 2=A2])`
  - Constraint única: `UNIQUE (id_projeto, avaliador_numero)` garante no máximo uma nota por avaliador por projeto.
- `projeto_aluno (id_projeto, id_aluno)` e `projeto_ods (id_projeto, id_ods)` relacionam projeto com alunos e ODS.
- `ods (id_ods, nome, descricao)`, `turma`, `postagem`, etc.
- View `view_status_avaliacoes`: agrega status de avaliação, média calculada e nomes dos avaliadores por projeto.

## Workflow de Avaliação (A1/A2)

- Cada projeto deve ser avaliado por 2 professores: Avaliador 1 (A1) e Avaliador 2 (A2).
- A tabela `nota` possui `avaliador_numero` (1 ou 2). A combinação `(id_projeto, avaliador_numero)` é única.
- A média final do projeto é a média aritmética das médias das avaliações existentes (quando há 2, fecha-se o ciclo).
- Menção final baseada na média final:
  - MB: média ≥ 7.6
  - B:  média ≥ 5.1 e < 7.6
  - R:  média ≥ 2.6 e < 5.1
  - I:  média < 2.6
- A view `view_status_avaliacoes` indica: 0, 1 ou 2 avaliações e lista quem avaliou (A1/A2).

## Instalação e Configuração (XAMPP/Windows)

Pré-requisitos:
- XAMPP (Apache + MariaDB/MySQL) e PHP 8.x
- Navegador moderno

Passo a passo:
1. Coloque esta pasta do projeto em `c:\xampp\htdocs\feira_tecnologica_avaliacoes`.
2. Crie o banco importando `banco_feira.sql` no phpMyAdmin (cria BD, tabelas, dados e view). 
3. Crie o arquivo de ambiente para o banco em `Backend/.env` com suas credenciais:
   - Exemplo:
     - DB_HOST=127.0.0.1
     - DB_NAME=banco_feira
     - DB_USER=root
     - DB_PASS=
4. (Opcional) Crie um `.env` na raiz do projeto para definir a base da API exposta ao JS:
   - Exemplo:
     - base_url=http://localhost/feira_tecnologica_avaliacoes/Backend
   - Se não definir, `Backend/config.js.php` tenta deduzir automaticamente via host/path.
5. Inicie Apache e MySQL no XAMPP.
6. Acesse no navegador: `http://localhost/feira_tecnologica_avaliacoes/index.html`.

Notas importantes:
- `Backend/Config/connection.php` lê `Backend/.env` (config do banco).
- `Backend/config.js.php` lê `.env` na raiz (base_url opcional) e expõe `window.BASE_URL`/`window.API_BASE` ao frontend.
- PHPMailer está configurado em `Backend/Controllers/EmailController.php`. Em produção, mova credenciais para `.env` e não as versione.

## Principais Páginas (Frontend)

- `index.html`: landing page (galeria e sobre), acesso ao login.
- `escolha-login.html`: escolha entre login de aluno e de professor.
- `login_aluno.html` / `login professor.html`: telas de login.
- `dashboard_aluno.html`: painel do aluno (meus projetos, status, atalho para notas).
- `escolher_projeto.php`: listar/criar/entrar em projeto e gerenciar equipe/ODS.
- `notas_alunos.html`: notas por projeto (detalhe de cada avaliador e menção/média final).
- `dash-prof.html`/`dash-prof2.html`: visões do professor (avaliação e acompanhamento).
- `visualizar_projeto.html`: detalhamento do projeto (inclui menção final quando disponível).

Observação: Fluxo de logout foi padronizado com modal de confirmação nas páginas do aluno (dashboard e escolher projeto).

## API (resumo dos endpoints)

Base da API: `${window.BASE_URL}/api` (por padrão, `http://localhost/feira_tecnologica_avaliacoes/Backend/api`).

- Autenticação
  - POST `/login/aluno` → body: `{ rm, email, senha }`
  - POST `/login/professor` → body: `{ matricula, email }`

- Usuários
  - GET `/usuarios` → lista geral
  - GET `/professores` → lista de professores

- Senha (aluno)
  - POST `/senha/enviar` → body: `{ email }` (envia código/gera senha)
  - POST `/senha/trocar` → body: `{ email, senha_nova }`

- Projetos
  - GET `/projetos` → todos os projetos
  - POST `/projetos/cadastrar` → criar
  - POST `/projetos/editar` → editar
  - GET|POST `/projetos/meus` → do criador logado
  - POST `/projetos/alunos` → membros de um projeto
  - POST `/projetos/inserir-aluno` → adicionar aluno ao projeto
  - POST `/projetos/inserir-ods` → vincular ODS
  - POST `/projetos/ods-projeto` → listar ODS de um projeto

- Notas / Avaliações
  - POST `/notas/cadastrar` → cadastrar/atualizar nota (A1/A2) de um projeto
  - POST `/notas/buscar` → buscar nota por critérios
  - GET `/notas/projetos` → projetos com notas (visão geral)
  - GET `/notas/aluno?id_aluno=...` → notas e status por aluno

- Postagens/Feed
  - GET `/postagem` → listar
  - POST `/postagem/criar` → criar
  - DELETE `/postagem/deletar` → deletar

- ODS/Turmas
  - GET `/ods` → lista ODS
  - GET `/turmas` → lista turmas

Erros retornam JSON com `{ "erro": "mensagem" }` e o HTTP status apropriado.

## Importação do Banco (banco_feira.sql)

O arquivo `banco_feira.sql` cria o banco `banco_feira`, todas as tabelas, chaves estrangeiras, populações iniciais (alunos/professores/ODS etc.), além de:
- Campos para avaliação A1/A2: `nota.avaliador_numero`, `projeto.media_final`, `projeto.mencao_final`.
- Constraint única para uma avaliação por avaliador por projeto.
- View `view_status_avaliacoes` com status e média calculada.
- Atualizações de consistência pós-import (preenchimento e recálculo quando há 2 avaliações).

## Dicas e Troubleshooting

- Se o frontend não consumir a API, verifique em DevTools se `window.BASE_URL` está correto (configurado por `Backend/config.js.php`).
- Se o login falhar, confira as credenciais no BD e a sessão PHP (Apache precisa permitir sessões; CORS habilitado por `Backend/Config/cors.php`).
- Ao importar o SQL, use `utf8mb4` e certifique-se de não haver erro de "caracteres"; o dump já define charset/colation.
- Para e-mails, configure PHPMailer (SMTP/usuário/senha) adequadamente e mova segredos para `.env`.

## Roadmap (ideias)

- Notificações para novas avaliações
- Exportação de notas em PDF
- Gráficos/histórico de desempenho
- Painel de administração

---

## 📓 Changelog

### 🚀 Atualizações - 17/09/2025

### ✅ Sistema de Notas Corrigido e Funcionando

**Problemas Resolvidos:**
- ❌ Dashboard do aluno sempre mostrava "Aguardando Avaliação"
- ❌ Página `notas_alunos.html` não estava integrada ao backend
- ❌ Dados estáticos (hardcoded) na exibição de notas
- ❌ Falta de endpoint para buscar notas específicas do aluno

---

### 📂 Arquivos Modificados

#### **Backend:**
- **`Backend/Controllers/NotasController.php`**
  - ✅ Novo método `buscarNotasDoAluno()`
  - ✅ Endpoint para buscar notas por ID do aluno
  - ✅ Cálculo automático de média final e status

- **`Backend/Routes/rotas.php`**
  - ✅ Nova rota: `/api/notas/aluno` (GET)

#### **Frontend:**
- **`notas_alunos.html`**
  - ✅ Integração completa com backend
  - ✅ Carregamento dinâmico das notas reais
  - ✅ Removidos dados estáticos

- **`js/dashboard_aluno.js`**
  - ✅ Status real das avaliações no dashboard
  - ✅ Estatísticas precisas (avaliados vs pendentes)
  - ✅ Corrigido cálculo da nota média no perfil

- **`css/dashboard_aluno.css`**
  - ✅ Indicadores visuais de status
  - ✅ Cards de estatísticas melhorados

#### **Novos Arquivos:**
- **`js/notas_alunos.js`** - JavaScript para página de notas
- **`teste_notas.html`** - Página de teste do sistema

---

### 🔧 Funcionalidades Implementadas

1. **Dashboard do Aluno Atualizado:**
   - Status correto: "Avaliado" ou "Aguardando Avaliação"
   - Contador de projetos avaliados vs pendentes
   - Indicadores visuais com cores (verde/amarelo)
   - Navegação direta para página de notas

2. **Página de Notas Integrada:**
   - Carregamento automático das notas do banco
   - Exibição de múltiplos avaliadores
   - Cálculo automático da média final
   - Feedbacks dos professores em tempo real
   - Sistema de menções (MB, B, R, I)

3. **Backend Robusto:**
   - Endpoint específico para notas do aluno
   - Tratamento de erros melhorado
   - Suporte a múltiplos avaliadores por projeto
   - Consultas SQL otimizadas

---

### 🚀 Como Testar

1. **Verificar Conectividade:**
   - Acesse: `teste_notas.html`

2. **Testar Sistema Completo:**
   - Faça login como aluno
   - Acesse `dashboard_aluno.html`
   - Vá para aba "Minhas Notas"
   - Verifique status dos projetos
   - Clique em "VER MINHAS NOTAS"

---

### 📊 Estrutura da API (exemplo rápido)

GET `/api/notas/aluno?id_aluno={id}`

Resposta (ex.):
[
  {
    "id_projeto": 1,
    "titulo_projeto": "Nome do Projeto",
    "status_avaliacao": "Avaliado|Aguardando Avaliação",
    "media_final": 8.5,
    "avaliacoes": [
      {
        "criatividade": 8.0,
        "capricho": 9.0,
        "media": 8.5,
        "comentario": "Feedback do professor",
        "nome_professor": "Prof. Nome"
      }
    ]
  }
]

---

### 🛠️ Tecnologias Utilizadas

- Backend: PHP, PDO, MySQL
- Frontend: HTML5, CSS3, JavaScript (Vanilla)
- Banco de Dados: MySQL/MariaDB
- Servidor: Apache (XAMPP)

---

### 📝 Próximas Melhorias

- [ ] Sistema de notificações para novas avaliações
- [ ] Exportação de notas em PDF
- [ ] Gráficos de desempenho
- [ ] Histórico de avaliações

---

Sistema totalmente funcional e integrado ✨

