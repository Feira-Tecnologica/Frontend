<?php
//Aqui é onde a API começa, você cria um objeto do Controller e dentro desse objeto você vai programar as funções 
class CadastroProjetoController
{

    public function AlunosProjeto(){
        require_once __DIR__ . '/../Config/connection.php';
        $dados = json_decode(file_get_contents('php://input'), true);

        $id_projeto = $dados['id_projeto'];

        if (empty($id_projeto)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Preencha todos os campos obrigatórios.']);
            exit;
        }

        try {
            $stmt = $conn->prepare("
                SELECT aluno.id_aluno, aluno.nome_aluno
                FROM aluno
                INNER JOIN projeto_aluno
                ON aluno.id_aluno = projeto_aluno.id_aluno WHERE projeto_aluno.id_projeto = :id_projeto;
            ");

            $stmt->bindParam(':id_projeto', $id_projeto);

            if ($stmt->execute()) {
                $alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($alunos, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'Erro ao puxar alunos do projeto.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }

    public function OdsProjeto(){
        require_once __DIR__ . '/../Config/connection.php';
        $dados = json_decode(file_get_contents('php://input'), true);

        $id_projeto = $dados['id_projeto'];

        if (empty($id_projeto)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Preencha todos os campos obrigatórios.']);
            exit;
        }

        try {
            $stmt = $conn->prepare("
                SELECT ods.id_ods, ods.nome
                FROM ods
                INNER JOIN projeto_ods
                ON ods.id_ods = projeto_ods.id_ods WHERE projeto_ods.id_projeto = :id_projeto;
            ");

            $stmt->bindParam(':id_projeto', $id_projeto);

            if ($stmt->execute()) {
                $ods = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($ods, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'Erro ao puxar ods do projeto.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }

    public function cadastroProjeto()
    {
        require_once __DIR__ . '/../Config/connection.php';
        session_start(); // Garante que a sessão está ativa
        $dados = json_decode(file_get_contents('php://input'), true);

        // Captura os valores enviados no payload
        $titulo_projeto = $dados['titulo_projeto'] ?? '';
        $descricao = $dados['descricao'] ?? '';
        $justificativa = $dados['justificativa'] ?? '';
        $objetivo = $dados['objetivo'] ?? '';
        $bloco = $dados['bloco'] ?? '';
        $sala = $dados['sala'] ?? '';
        $posicao = $dados['posicao'] ?? null;
        $orientador = $dados['orientador'] ?? '';
        $turma = $dados['turma'] ?? '';
        $integrantes = $dados['integrantes'] ?? [];
        $ods = $dados['ods'] ?? [];
        
        // Captura o ID do usuário logado da sessão PHP (aluno ou professor)
        $criador_id = $_SESSION['id_aluno'] ?? $_SESSION['id_professor'] ?? $dados['criador_id'] ?? null;
        $usuario_tipo = $_SESSION['usuario_tipo'] ?? null;

        // Validação simples (exemplo: alguns campos obrigatórios)
        if (empty($titulo_projeto) || empty($descricao)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Preencha todos os campos obrigatórios.']);
            exit;
        }
        
        // Verificar se o usuário está logado
        if (empty($criador_id)) {
            // Debug temporário - remover depois
            $debug_info = [
                'session_data' => $_SESSION,
                'post_data' => $dados,
                'criador_from_session_aluno' => $_SESSION['id_aluno'] ?? 'não encontrado',
                'criador_from_session_professor' => $_SESSION['id_professor'] ?? 'não encontrado',
                'criador_from_post' => $dados['criador_id'] ?? 'não encontrado',
                'usuario_tipo' => $usuario_tipo
            ];
            
            http_response_code(401);
            echo json_encode([
                'status' => 'error', 
                'message' => 'Usuário não autenticado. Faça login novamente.',
                'debug' => $debug_info
            ]);
            exit;
        }

        try {
            // Inicia transação
            $conn->beginTransaction();

            // Insere o projeto com o criador_id
            $stmt = $conn->prepare("
                    INSERT INTO projeto (
                        titulo_projeto, descricao, justificativa, objetivo, bloco, sala, posicao, orientador, turma, criador_id
                    ) VALUES (
                        :titulo_projeto, :descricao, :justificativa, :objetivo, :bloco, :sala, :posicao, :orientador, :turma, :criador_id
                    )
                ");

            $stmt->bindParam(':titulo_projeto', $titulo_projeto);
            $stmt->bindParam(':descricao', $descricao);
            $stmt->bindParam(':justificativa', $justificativa);
            $stmt->bindParam(':objetivo', $objetivo);
            $stmt->bindParam(':bloco', $bloco);
            $stmt->bindParam(':sala', $sala);
            $stmt->bindParam(':posicao', $posicao, PDO::PARAM_INT);
            $stmt->bindParam(':orientador', $orientador);
            $stmt->bindParam(':turma', $turma);
            $stmt->bindParam(':criador_id', $criador_id);

            if ($stmt->execute()) {
                $id_projeto = $conn->lastInsertId();
                
                // Insere os integrantes na tabela projeto_aluno
                if (!empty($integrantes)) {
                    $stmtAluno = $conn->prepare("INSERT INTO projeto_aluno (id_projeto, id_aluno) VALUES (:id_projeto, :id_aluno)");
                    foreach ($integrantes as $id_aluno) {
                        $stmtAluno->bindParam(':id_projeto', $id_projeto);
                        $stmtAluno->bindParam(':id_aluno', $id_aluno);
                        $stmtAluno->execute();
                    }
                }
                
                // Insere as ODS na tabela projeto_ods
                if (!empty($ods)) {
                    $stmtOds = $conn->prepare("INSERT INTO projeto_ods (id_projeto, id_ods) VALUES (:id_projeto, :id_ods)");
                    foreach ($ods as $id_ods) {
                        $stmtOds->bindParam(':id_projeto', $id_projeto);
                        $stmtOds->bindParam(':id_ods', $id_ods);
                        $stmtOds->execute();
                    }
                }
                
                // Confirma a transação
                $conn->commit();
                
                echo json_encode([
                    'status' => 'success', 
                    'message' => 'Projeto cadastrado com sucesso.',
                    'id_projeto' => $id_projeto
                ]);
            } else {
                $conn->rollback();
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'Erro ao cadastrar projeto.']);
            }
        } catch (PDOException $e) {
            $conn->rollback();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }


    public function mostrarProjetos()
    {
        require_once __DIR__ . '/../Config/connection.php';

        // JOIN com a tabela aluno para obter o nome do criador e com professor para o orientador
        $stmt = $conn->prepare("
            SELECT p.*, 
                   a.nome_aluno as nome_criador,
                   prof.nome_professor as nome_orientador
            FROM projeto p 
            LEFT JOIN aluno a ON p.criador_id = a.id_aluno
            LEFT JOIN professor prof ON p.orientador = prof.id_professor
        ");
        $stmt->execute();
        $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($projetos);
    }

    public function atualizarProjeto() {
        require_once __DIR__ . '/../Config/connection.php';
        session_start(); // Garante que a sessão está ativa
        $dados = json_decode(file_get_contents('php://input'), true);

        $id_projeto = $dados['id_projeto'] ?? null;
        if (empty($id_projeto)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Informe o id_projeto.']);
            exit;
        }
        
        // Verificar se o usuário está logado (aluno ou professor)
        $usuario_logado = $_SESSION['id_aluno'] ?? $_SESSION['id_professor'] ?? null;
        $usuario_tipo = $_SESSION['usuario_tipo'] ?? null;
        
        if (empty($usuario_logado)) {
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'Usuário não autenticado.']);
            exit;
        }
        
        // Verificar se o usuário é o criador do projeto (apenas para alunos)
        if ($usuario_tipo === 'aluno') {
            try {
                $stmtVerify = $conn->prepare("SELECT criador_id FROM projeto WHERE id_projeto = :id_projeto");
                $stmtVerify->bindParam(':id_projeto', $id_projeto);
                $stmtVerify->execute();
                $projeto = $stmtVerify->fetch(PDO::FETCH_ASSOC);
                
                if (!$projeto) {
                    http_response_code(404);
                    echo json_encode(['status' => 'error', 'message' => 'Projeto não encontrado.']);
                    exit;
                }
                
                if ($projeto['criador_id'] !== $usuario_logado) {
                    http_response_code(403);
                    echo json_encode(['status' => 'error', 'message' => 'Você não tem permissão para editar este projeto. Apenas o criador pode editá-lo.']);
                    exit;
                }
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'Erro ao verificar permissões: ' . $e->getMessage()]);
                exit;
            }
        }
        // Professores podem editar qualquer projeto

        // Campos possíveis (exceto PK)
        $colunas = [
            'titulo_projeto' => PDO::PARAM_STR,
            'descricao'      => PDO::PARAM_STR,
            'justificativa'  => PDO::PARAM_STR,
            'objetivo'       => PDO::PARAM_STR,
            'bloco'          => PDO::PARAM_STR,
            'sala'           => PDO::PARAM_STR,
            'posicao'        => PDO::PARAM_INT,
            'orientador'     => PDO::PARAM_STR,
            'turma'          => PDO::PARAM_STR,
        ];

        // Campos especiais
        $integrantes = $dados['integrantes'] ?? null;
        $ods = $dados['ods'] ?? null;

        // Monta SET dinamicamente apenas com o que veio no payload
        $setParts = [];
        $binds = [];
        foreach ($colunas as $col => $type) {
            if (array_key_exists($col, $dados)) {
                $setParts[] = "$col = :$col";
                $binds[] = ['name' => $col, 'value' => $dados[$col], 'type' => $type];
            }
        }

        try {
            // Inicia transação
            $conn->beginTransaction();

            // Atualiza dados básicos do projeto se houver
            if (!empty($setParts)) {
                $sql = "UPDATE projeto SET " . implode(', ', $setParts) . " WHERE id_projeto = :id_projeto";
                $stmt = $conn->prepare($sql);

                // Binds dos campos variáveis
                foreach ($binds as $b) {
                    if (is_null($b['value'])) {
                        $stmt->bindValue(':' . $b['name'], null, PDO::PARAM_NULL);
                    } else {
                        if ($b['type'] === PDO::PARAM_INT) {
                            $stmt->bindValue(':' . $b['name'], (int)$b['value'], PDO::PARAM_INT);
                        } else {
                            $stmt->bindValue(':' . $b['name'], $b['value'], PDO::PARAM_STR);
                        }
                    }
                }

                // Bind do identificador
                $stmt->bindValue(':id_projeto', $id_projeto);
                $stmt->execute();
            }

            // Atualizar integrantes se fornecidos
            if (is_array($integrantes)) {
                // Remove todos os integrantes atuais
                $stmtDelAlunos = $conn->prepare("DELETE FROM projeto_aluno WHERE id_projeto = :id_projeto");
                $stmtDelAlunos->bindParam(':id_projeto', $id_projeto);
                $stmtDelAlunos->execute();

                // Adiciona os novos integrantes
                if (!empty($integrantes)) {
                    $stmtInsAluno = $conn->prepare("INSERT INTO projeto_aluno (id_projeto, id_aluno) VALUES (:id_projeto, :id_aluno)");
                    foreach ($integrantes as $id_aluno) {
                        $stmtInsAluno->bindParam(':id_projeto', $id_projeto);
                        $stmtInsAluno->bindParam(':id_aluno', $id_aluno);
                        $stmtInsAluno->execute();
                    }
                }
            }

            // Atualizar ODS se fornecidas
            if (is_array($ods)) {
                // Remove todas as ODS atuais
                $stmtDelOds = $conn->prepare("DELETE FROM projeto_ods WHERE id_projeto = :id_projeto");
                $stmtDelOds->bindParam(':id_projeto', $id_projeto);
                $stmtDelOds->execute();

                // Adiciona as novas ODS
                if (!empty($ods)) {
                    $stmtInsOds = $conn->prepare("INSERT INTO projeto_ods (id_projeto, id_ods) VALUES (:id_projeto, :id_ods)");
                    foreach ($ods as $id_ods) {
                        $stmtInsOds->bindParam(':id_projeto', $id_projeto);
                        $stmtInsOds->bindParam(':id_ods', $id_ods);
                        $stmtInsOds->execute();
                    }
                }
            }

            // Confirma a transação
            $conn->commit();

            echo json_encode([
                'status' => 'success',
                'message' => 'Projeto atualizado com sucesso.'
            ]);

        } catch (PDOException $e) {
            $conn->rollback();
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }

    public function InserirAluno(){
        require_once __DIR__ . '/../Config/connection.php';
        $dados = json_decode(file_get_contents('php://input'), true);

        $id_projeto = $dados['id_projeto'];
        $id_aluno = $dados['id_aluno'];

        if (empty($id_projeto) || empty($id_aluno)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Preencha todos os campos obrigatórios.']);
            exit;
        }

        try{
            $stmt = $conn->prepare("
                INSERT INTO projeto_aluno (
                    id_projeto, id_aluno
                ) VALUES (
                    :id_projeto, :id_aluno
                )
            ");
            $stmt->bindParam(':id_projeto', $id_projeto);
            $stmt->bindParam(':id_aluno', $id_aluno);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Aluno inserido no projeto com sucesso.']);
            } else {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'Erro ao inserir aluno no projeto.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }

    public function InserirOds(){
        require_once __DIR__ . '/../Config/connection.php';
        $dados = json_decode(file_get_contents('php://input'), true);

        $id_projeto = $dados['id_projeto'];
        $id_ods = $dados['id_ods'];

        if (empty($id_projeto) || empty($id_ods)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Preencha todos os campos obrigatórios.']);
            exit;
        }

        try{
            $stmt = $conn->prepare("
                INSERT INTO projeto_ods (
                    id_projeto, id_ods
                ) VALUES (
                    :id_projeto, :id_ods
                )
            ");
            $stmt->bindParam(':id_projeto', $id_projeto);
            $stmt->bindParam(':id_ods', $id_ods);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Ods inserida no projeto com sucesso.']);
            } else {
                http_response_code(500);
                echo json_encode(['status' => 'error', 'message' => 'Erro ao inserir Ods no projeto.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }

    public function projetosPorCriador() {
        require_once __DIR__ . '/../Config/connection.php';
        
        // Tentar obter o ID do usuário da sessão PHP ou do POST
        session_start();
        $criador_id = $_SESSION['id_aluno'] ?? null;
        
        // Se não tiver na sessão PHP, tentar obter do POST
        if (empty($criador_id)) {
            $dados = json_decode(file_get_contents('php://input'), true);
            $criador_id = $dados['id_aluno'] ?? null;
        }
        
        if (empty($criador_id)) {
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'Usuário não autenticado.']);
            exit;
        }

        try {
            // Buscar projetos com informações de avaliação
            $stmt = $conn->prepare("
                SELECT p.*, 
                       a.nome_aluno as nome_criador,
                       prof.nome_professor as nome_orientador,
                       COUNT(n.id_nota) as qtd_avaliacoes,
                       ROUND(AVG(n.media), 1) as nota_final,
                       CASE 
                           WHEN COUNT(n.id_nota) > 0 THEN 'Avaliado' 
                           ELSE 'Aguardando Avaliação' 
                       END as status_avaliacao
                FROM projeto p 
                LEFT JOIN aluno a ON p.criador_id = a.id_aluno
                LEFT JOIN professor prof ON p.orientador = prof.id_professor
                LEFT JOIN nota n ON n.id_projeto = p.id_projeto
                WHERE p.criador_id = :criador_id
                GROUP BY p.id_projeto
                ORDER BY p.id_projeto DESC
            ");
            $stmt->bindParam(':criador_id', $criador_id);
            $stmt->execute();
            $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Atualizar o campo nota_final na tabela projeto se houver notas
            foreach ($projetos as $projeto) {
                if ($projeto['nota_final'] && $projeto['nota_final'] > 0) {
                    $updateStmt = $conn->prepare("UPDATE projeto SET nota_final = :nota_final WHERE id_projeto = :id_projeto");
                    $updateStmt->bindParam(':nota_final', $projeto['nota_final']);
                    $updateStmt->bindParam(':id_projeto', $projeto['id_projeto']);
                    $updateStmt->execute();
                }
            }

            echo json_encode($projetos);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Erro no banco de dados: ' . $e->getMessage()]);
        }
    }
}
?>
