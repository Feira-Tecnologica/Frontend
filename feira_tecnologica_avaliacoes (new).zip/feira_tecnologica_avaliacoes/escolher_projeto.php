<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolher projeto</title>
    <link rel="stylesheet" href="css/styleB.css">
    <link rel="stylesheet" href="css/escolher_projeto.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- Simplify Material Icons import -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body>
    <?php session_start(); ?>



    <div class="container">
        <img src="img/topo.png" alt="Elemento decorativo" class="top-vector">
        <img src="img/logo_etec.png" alt="Logo ETEC" class="logo">

        <div class="content-container">
            <h2 id="saudacao"></h2>
            <h3 style="text-align: left; color: black; margin-left: 2.5%;">Projetos</h3>

            <div class="controls">
                <div class="search">
                    <span class="material-icons" style="color: #672D91;">search</span>
                    <input type="text" placeholder="Pesquisar projeto...">
                </div>

                <div class="controls-actions">
                    <button class="btn-create" onclick="location.href='criar_projeto.html'">CRIAR PROJETO</button>
                    <button class="btn-logout" onclick="logout()" title="Sair">SAIR</button>
                </div>
            </div>

            <!-- Os cards de projetos serão inseridos aqui dinamicamente pelo JavaScript -->
            <div class="projects-grid" aria-live="polite"></div>

            <h3 style="text-align: left; color: black; margin-left: 2.5%; margin-bottom: 2%;">Suas Publicações</h3>
            <div class="pub-grid"></div>
            <button class="btn-create" onclick="location.href='CadImagem.php'">CRIAR PUBLICAÇÃO</button>
        </div>


        <script src="Backend/config.js.php"></script>
        <script src="js/escolher_projeto.js"></script>
</body>

</html>