<?php

class NotasController
{
    public function cadastroNota()
    {
        require_once __DIR__ . '/../Config/connection.php';

        $dados = json_decode(file_get_contents('php://input'), true);

        $criatividade = floatval($dados['criatividade'] ?? null);
        $capricho = floatval($dados['capricho'] ?? null);
        $abordagem = floatval($dados['abordagem'] ?? null);
        $dominio = floatval($dados['dominio'] ?? null);
        $postura = floatval($dados['postura'] ?? null);
        $oralidade = floatval($dados['oralidade'] ?? null);
        $organizacao = floatval($dados['organizacao'] ?? null);
        $comentario = $dados['comentario'] ?? '';
        $id_professor = $dados['id_professor'] ?? '';
        $id_projeto = $dados['id_projeto'] ?? '';

        if (
            is_null($criatividade) ||
            is_null($capricho) ||
            is_null($abordagem) ||
            is_null($dominio) ||
            is_null($postura) ||
            is_null($oralidade) ||
            is_null($organizacao) ||
            empty($id_professor) ||
            empty($id_projeto) 
        ) {
            http_response_code(400);
            echo json_encode(["erro" => "Preencha todas as notas obrigatórias."]);
            return;
        }

        try {
            // Verificar se já existe uma nota para este professor e projeto
            $stmtCheck = $conn->prepare("SELECT id_nota FROM nota WHERE id_professor = :id_professor AND id_projeto = :id_projeto");
            $stmtCheck->bindParam(':id_professor', $id_professor);
            $stmtCheck->bindParam(':id_projeto', $id_projeto);
            $stmtCheck->execute();
            
            $notaExistente = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            // Cálculo da média
            $media = round(($criatividade + $capricho + $abordagem + $dominio + $postura + $oralidade + $organizacao) / 7, 1);

            if ($notaExistente) {
                // Atualizar nota existente
                $stmt = $conn->prepare("
                    UPDATE nota SET 
                        criatividade = :criatividade, 
                        capricho = :capricho, 
                        abordagem = :abordagem, 
                        dominio = :dominio, 
                        postura = :postura, 
                        oralidade = :oralidade, 
                        organizacao = :organizacao, 
                        media = :media, 
                        comentario = :comentario
                    WHERE id_professor = :id_professor AND id_projeto = :id_projeto
                ");
                $operacao = "atualizada";
            } else {
                // Inserir nova nota
                $stmt = $conn->prepare("
                    INSERT INTO nota (
                        criatividade, capricho, abordagem, dominio, postura, oralidade, comentario, organizacao, media, id_professor, id_projeto
                    ) VALUES (
                        :criatividade, :capricho, :abordagem, :dominio, :postura, :oralidade, :comentario, :organizacao, :media, :id_professor, :id_projeto
                    )
                ");
                $operacao = "cadastrada";
            }

            // Bind dos parâmetros
            $stmt->bindParam(':criatividade', $criatividade);
            $stmt->bindParam(':capricho', $capricho);
            $stmt->bindParam(':abordagem', $abordagem);
            $stmt->bindParam(':dominio', $dominio);
            $stmt->bindParam(':postura', $postura);
            $stmt->bindParam(':oralidade', $oralidade);
            $stmt->bindParam(':organizacao', $organizacao);
            $stmt->bindParam(':media', $media);
            $stmt->bindParam(':id_professor', $id_professor);
            $stmt->bindParam(':id_projeto', $id_projeto);
            $stmt->bindParam(':comentario', $comentario);

            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode([
                    "mensagem" => "Nota {$operacao} com sucesso.",
                    "media" => $media
                ]);
            } else {
                http_response_code(500);
                echo json_encode(["erro" => "Erro ao {$operacao} nota."]);
            }

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }

    public function buscarNota()
    {
        require_once __DIR__ . '/../Config/connection.php';

        $dados = json_decode(file_get_contents('php://input'), true);
        $id_professor = $dados['id_professor'] ?? '';
        $id_projeto = $dados['id_projeto'] ?? '';

        if (empty($id_professor) || empty($id_projeto)) {
            http_response_code(400);
            echo json_encode(["erro" => "ID do professor e projeto são obrigatórios."]);
            return;
        }

        try {
            $stmt = $conn->prepare("
                SELECT criatividade, capricho, abordagem, dominio, postura, oralidade, organizacao, media, comentario 
                FROM nota 
                WHERE id_professor = :id_professor AND id_projeto = :id_projeto
            ");
            $stmt->bindParam(':id_professor', $id_professor);
            $stmt->bindParam(':id_projeto', $id_projeto);
            $stmt->execute();

            $nota = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($nota) {
                echo json_encode($nota);
            } else {
                http_response_code(404);
                echo json_encode(["mensagem" => "Nenhuma nota encontrada."]);
            }

        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }

    /**
     * Lista projetos com status de avaliação para o professor logado (opcional) ou geral.
     * Retorna média (global do projeto calculada pela média das médias dos professores) e status.
     */
    public function listarProjetosComNotas()
    {
        require_once __DIR__ . '/../Config/connection.php';

        // Permitir filtragem opcional por professor (via query string ?id_professor=...)
        $id_professor = isset($_GET['id_professor']) ? $_GET['id_professor'] : null;

        try {
            // Consulta principal: projetos + agregação de notas
            $sql = "
                SELECT 
                    p.id_projeto,
                    p.titulo_projeto,
                    p.posicao,
                    p.turma,
                    p.orientador,
                    GROUP_CONCAT(DISTINCT a.nome_aluno ORDER BY a.nome_aluno SEPARATOR ', ') AS integrantes,
                    COUNT(n.id_nota) AS qtd_avaliacoes,
                    ROUND(AVG(n.media),1) AS media,
                    CASE WHEN COUNT(n.id_nota) > 0 THEN 'Avaliado' ELSE 'Pendente' END AS status_avaliacao
                FROM projeto p
                LEFT JOIN projeto_aluno pa ON pa.id_projeto = p.id_projeto
                LEFT JOIN aluno a ON a.id_aluno = pa.id_aluno
                LEFT JOIN nota n ON n.id_projeto = p.id_projeto
                " . ($id_professor ? " AND n.id_professor = :id_professor" : "") . "
                GROUP BY p.id_projeto
                ORDER BY p.titulo_projeto ASC
            ";

            // Ajuste: a condição com AND em LEFT JOIN precisa estar dentro do ON para não transformar em INNER
            if ($id_professor) {
                $sql = "
                    SELECT 
                        p.id_projeto,
                        p.titulo_projeto,
                        p.posicao,
                        p.turma,
                        p.orientador,
                        GROUP_CONCAT(DISTINCT a.nome_aluno ORDER BY a.nome_aluno SEPARATOR ', ') AS integrantes,
                        COUNT(n.id_nota) AS qtd_avaliacoes,
                        ROUND(AVG(n.media),1) AS media,
                        CASE WHEN COUNT(n.id_nota) > 0 THEN 'Avaliado' ELSE 'Pendente' END AS status_avaliacao
                    FROM projeto p
                    LEFT JOIN projeto_aluno pa ON pa.id_projeto = p.id_projeto
                    LEFT JOIN aluno a ON a.id_aluno = pa.id_aluno
                    LEFT JOIN nota n ON n.id_projeto = p.id_projeto AND n.id_professor = :id_professor
                    GROUP BY p.id_projeto
                    ORDER BY p.titulo_projeto ASC
                ";
            }

            $stmt = $conn->prepare($sql);
            if ($id_professor) {
                $stmt->bindParam(':id_professor', $id_professor);
            }
            $stmt->execute();

            $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            http_response_code(200);
            echo json_encode($projetos, JSON_UNESCAPED_UNICODE);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["erro" => "Erro no banco de dados: " . $e->getMessage()]);
        }
    }
}
