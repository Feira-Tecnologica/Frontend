<?php
class TurmaController {
    public function Turmas() {
        require_once __DIR__ . '/../Config/connection.php';

        // Primeiro tenta buscar da tabela turma
        $stmt = $conn->prepare("SELECT * FROM turma");
        $stmt->execute();
        $turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Se a tabela turma estiver vazia, busca as turmas dos alunos
        if (empty($turmas)) {
            $stmt = $conn->prepare("
                SELECT DISTINCT SUBSTRING_INDEX(id_aluno, '_', 1) as nome_turma,
                       SUBSTRING_INDEX(id_aluno, '_', 1) as id_turma
                FROM aluno 
                WHERE id_aluno LIKE '%_%'
                ORDER BY nome_turma
            ");
            $stmt->execute();
            $turmasFromAlunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Converte para o formato esperado
            $turmas = array_map(function($item) {
                return [
                    'id_turma' => $item['nome_turma'],
                    'nome_turma' => $item['nome_turma']
                ];
            }, $turmasFromAlunos);
        }

        echo json_encode($turmas, JSON_UNESCAPED_UNICODE);
    }
}
?>
