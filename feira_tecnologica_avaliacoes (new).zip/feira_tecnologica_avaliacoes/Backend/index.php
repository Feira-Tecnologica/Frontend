<?php
require_once __DIR__ . '/Config/cors.php';
require_once __DIR__ . '/Routes/rotas.php';
?>
