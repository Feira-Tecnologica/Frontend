// Variáveis globais
let projetoAtual = null;
let selectedIntegrantes = new Set();
let selectedODS = new Set();
let alunosDisponiveis = [];
let odsDisponiveis = [];
let turmasDisponiveis = [];
let turmaSelecionada = null;

document.addEventListener('DOMContentLoaded', function() {
    // Configurar interface
    configurarInterfacePorTipoUsuario();
    
    // Carregar dados iniciais
    carregarTurmas();
    carregarODS();
    
    // Carregar projeto para edição
    carregarProjeto();

    // Event listeners
    const turmaSelect = document.getElementById("turmaSelect");
    if (turmaSelect) {
        turmaSelect.addEventListener('change', function(e) {
            turmaSelecionada = e.target.value;
            if (turmaSelecionada) {
                carregarAlunosPorTurma(turmaSelecionada);
            } else {
                alunosDisponiveis = [];
                atualizarSelectIntegrantes();
            }
        });
    }

    const integrantesSelect = document.getElementById("integrantesSelect");
    if (integrantesSelect) {
        integrantesSelect.addEventListener('change', function(e) {
            if (e.target.value) {
                adicionarIntegrante();
            }
        });
    }

    const form = document.querySelector('#formEditarProjeto');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            salvarProjeto();
        });
    }
});

function configurarInterfacePorTipoUsuario() {
    configurarInterfaceODS();
}

function configurarInterfaceODS() {
    const odsContainer = document.getElementById("odsContainer");
    if (odsContainer) {
        odsContainer.innerHTML = `
            <div class="ods-select-wrapper">
                <select class="integrantes-select" id="odsSelect">
                    <option value="">Carregando ODS...</option>
                </select>
            </div>
            <div class="integrantes-selected-list" id="odsSelectedList"></div>
        `;

        const odsSelect = document.getElementById("odsSelect");
        if (odsSelect) {
            odsSelect.addEventListener('change', function(e) {
                if (e.target.value) {
                    adicionarODS();
                }
            });
        }
    }
}

function carregarProjeto() {
    const urlParams = new URLSearchParams(window.location.search);
    const idProjeto = urlParams.get('id') || localStorage.getItem('projeto_visualizacao');
    if (idProjeto) {
        buscarDadosProjeto(idProjeto);
    } else {
        mostrarErro('Nenhum projeto selecionado para edição');
    }
}

async function buscarDadosProjeto(idProjeto) {
    try {
        // Buscar dados do projeto
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos');
        
        if (!response.ok) {
            throw new Error('Erro ao buscar projetos');
        }

        const data = await response.json();
        let projetos = Array.isArray(data) ? data : (data.data || []);
        
        projetoAtual = projetos.find(p => String(p.id_projeto) === String(idProjeto));
        
        if (!projetoAtual) {
            throw new Error('Projeto não encontrado');
        }

        // Buscar integrantes do projeto
        await carregarIntegrantesProjeto(idProjeto);
        
        // Buscar ODS do projeto
        await carregarODSProjeto(idProjeto);
        
        // Preencher formulário
        preencherFormulario();
        
    } catch (error) {
        console.error('Erro ao carregar projeto:', error);
        mostrarErro('Erro ao carregar dados do projeto');
    }
}

async function carregarIntegrantesProjeto(idProjeto) {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/alunos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_projeto: idProjeto })
        });

        if (response.ok) {
            const alunos = await response.json();
            alunos.forEach(aluno => {
                if (aluno.id_aluno) {
                    selectedIntegrantes.add(aluno.id_aluno);
                }
            });
        }
    } catch (error) {
        console.error('Erro ao carregar integrantes:', error);
    }
}

async function carregarODSProjeto(idProjeto) {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/ods-projeto', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_projeto: idProjeto })
        });

        if (response.ok) {
            const odsList = await response.json();
            odsList.forEach(ods => {
                if (ods.id_ods) {
                    selectedODS.add(String(ods.id_ods));
                }
            });
        }
    } catch (error) {
        console.error('Erro ao carregar ODS:', error);
    }
}

function preencherFormulario() {
    if (!projetoAtual) return;

    // Preencher campos básicos
    document.getElementById('titulo_projeto').value = projetoAtual.titulo_projeto || '';
    document.getElementById('projetoId').value = projetoAtual.id_projeto;

    // Extrair descrição, objetivo e justificativa
    const fullDesc = projetoAtual.descricao || '';
    let descText = fullDesc;
    let objText = '';
    let justText = '';
    
    const objMatch = /Objetivo[:]?\s*/i.exec(fullDesc);
    const justMatch = /Justificativa[:]?\s*/i.exec(fullDesc);
    
    if (objMatch) {
        const objIndex = objMatch.index;
        descText = fullDesc.substring(0, objIndex).trim();
        if (justMatch) {
            objText = fullDesc.substring(objIndex + objMatch[0].length, justMatch.index).trim();
            justText = fullDesc.substring(justMatch.index + justMatch[0].length).trim();
        } else {
            objText = fullDesc.substring(objIndex + objMatch[0].length).trim();
        }
    }

    document.getElementById('descricao').value = descText;
    document.getElementById('objetivo').value = objText;
    document.getElementById('justificativa').value = justText;

    // Definir turma selecionada
    turmaSelecionada = projetoAtual.turma;
    
    // Atualizar informações do stand
    document.getElementById('standInfo').textContent = `STAND ${projetoAtual.posicao || '--'}`;
    document.getElementById('turmaInfo').innerHTML = `${projetoAtual.turma || 'Turma não definida'}<br>--`;

    // Atualizar listas
    updateIntegrantesList();
    updateODSList();
}

// Funções auxiliares similares ao criar_projeto.js
async function carregarTurmas() {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/turmas');
        
        if (response.ok) {
            const data = await response.json();
            turmasDisponiveis = Array.isArray(data) ? data : (data.data || []);
            atualizarSelectTurmas();
        }
    } catch (error) {
        console.error('Erro ao carregar turmas:', error);
    }
}

function atualizarSelectTurmas() {
    const select = document.getElementById("turmaSelect");
    if (!select) return;
    
    if (turmasDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione uma turma...</option>';
        turmasDisponiveis.forEach(turma => {
            const option = document.createElement('option');
            option.value = turma.nome_turma || turma.nome || turma.codigo || turma.id_turma;
            option.textContent = turma.nome_turma || turma.nome || turma.codigo || turma.id_turma;
            if (option.value === turmaSelecionada) {
                option.selected = true;
            }
            select.appendChild(option);
        });
        select.disabled = false;
        
        // Se já há uma turma selecionada, carregar os alunos
        if (turmaSelecionada) {
            carregarAlunosPorTurma(turmaSelecionada);
        }
    } else {
        select.innerHTML = '<option value="">Nenhuma turma encontrada</option>';
        select.disabled = true;
    }
}

async function carregarODS() {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/ods');
        
        if (response.ok) {
            const data = await response.json();
            odsDisponiveis = Array.isArray(data) ? data : (data.data || []);
            atualizarSelectODS();
        }
    } catch (error) {
        console.error('Erro ao carregar ODS:', error);
    }
}

function atualizarSelectODS() {
    const select = document.getElementById("odsSelect");
    if (!select) return;

    if (odsDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione uma ODS...</option>';
        odsDisponiveis.forEach(ods => {
            const option = document.createElement('option');
            option.value = ods.id_ods;
            option.textContent = `ODS ${ods.id_ods} - ${ods.nome}`;
            select.appendChild(option);
        });
        select.disabled = false;
    } else {
        select.innerHTML = '<option value="">Nenhuma ODS encontrada</option>';
        select.disabled = true;
    }
}

async function carregarAlunosPorTurma(turma) {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(`${apiBase}/api/usuarios?turma=${encodeURIComponent(turma)}`);
        
        if (response.ok) {
            const data = await response.json();
            alunosDisponiveis = Array.isArray(data) ? data : (data.data || []);
            atualizarSelectIntegrantes();
        }
    } catch (error) {
        console.error('Erro ao carregar alunos:', error);
        alunosDisponiveis = [];
        atualizarSelectIntegrantes();
    }
}

function atualizarSelectIntegrantes() {
    const select = document.getElementById("integrantesSelect");
    if (!select) return;

    if (alunosDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione um integrante...</option>';
        alunosDisponiveis.forEach(aluno => {
            const option = document.createElement('option');
            option.value = aluno.id_aluno;
            option.textContent = aluno.nome_aluno || aluno.nome;
            select.appendChild(option);
        });
        select.disabled = false;
    } else {
        select.innerHTML = '<option value="">Selecione uma turma primeiro...</option>';
        select.disabled = true;
    }
}

function adicionarIntegrante() {
    const select = document.getElementById("integrantesSelect");
    if (!select.value) return;

    selectedIntegrantes.add(select.value);
    select.value = "";
    updateIntegrantesList();
}

function removerIntegrante(id_aluno) {
    selectedIntegrantes.delete(id_aluno);
    updateIntegrantesList();
}

function adicionarODS() {
    const select = document.getElementById("odsSelect");
    if (!select.value) return;

    selectedODS.add(select.value);
    select.value = "";
    updateODSList();
}

function removerODS(id_ods) {
    selectedODS.delete(id_ods);
    updateODSList();
}

function updateIntegrantesList() {
    const listContainer = document.getElementById("integrantesSelectedList");
    
    if (selectedIntegrantes.size === 0) {
        listContainer.innerHTML = '<div class="integrantes-empty">Nenhum integrante selecionado</div>';
        return;
    }
    
    listContainer.innerHTML = Array.from(selectedIntegrantes).map(id_aluno => {
        const aluno = alunosDisponiveis.find(a => a.id_aluno === id_aluno);
        const nome = aluno ? aluno.nome_aluno : id_aluno;
        return `
            <div class="integrante-item">
                <span>${nome}</span>
                <button type="button" class="remove-integrante-btn" onclick="removerIntegrante('${id_aluno}')">×</button>
            </div>
        `;
    }).join('');
}

function updateODSList() {
    const listContainer = document.getElementById("odsSelectedList");
    
    if (selectedODS.size === 0) {
        listContainer.innerHTML = '<div class="ods-empty">Nenhuma ODS selecionada</div>';
        return;
    }
    
    listContainer.innerHTML = Array.from(selectedODS).map(id_ods => {
        const ods = odsDisponiveis.find(o => o.id_ods == id_ods);
        const nome = ods ? `ODS ${ods.id_ods} - ${ods.nome}` : `ODS ${id_ods}`;
        return `
            <div class="ods-item">
                <span>${nome}</span>
                <button type="button" class="remove-ods-btn" onclick="removerODS('${id_ods}')">×</button>
            </div>
        `;
    }).join('');
}

async function salvarProjeto() {
    if (!projetoAtual || !projetoAtual.id_projeto) {
        alert('Projeto inválido.');
        return;
    }

    const nomeProjeto = document.getElementById("titulo_projeto").value;
    const descricao = document.getElementById("descricao").value;
    const objetivo = document.getElementById("objetivo").value;
    const justificativa = document.getElementById("justificativa").value;

    if (!nomeProjeto || !descricao || !turmaSelecionada) {
        alert("Preencha todos os campos obrigatórios.");
        return;
    }

    // Preparar descrição completa
    const descricaoCompleta = descricao + 
        (objetivo ? `\n\nObjetivo: ${objetivo}` : '') + 
        (justificativa ? `\n\nJustificativa: ${justificativa}` : '');

    const dadosAtualizados = {
        id_projeto: projetoAtual.id_projeto,
        titulo_projeto: nomeProjeto,
        descricao: descricaoCompleta,
        turma: turmaSelecionada,
        integrantes: Array.from(selectedIntegrantes),
        ods: Array.from(selectedODS).map(id => parseInt(id))
    };

    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/editar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dadosAtualizados)
        });

        const resultado = await response.json();

        if (response.ok) {
            alert('Projeto atualizado com sucesso!');
            window.location.href = `visualizar_projeto.html?id=${projetoAtual.id_projeto}`;
        } else {
            alert('Erro ao atualizar projeto: ' + (resultado.erro || resultado.message || 'Erro desconhecido'));
        }
    } catch (error) {
        console.error('Erro ao salvar projeto:', error);
        alert('Erro de conexão ao salvar o projeto.');
    }
}

function mostrarErro(mensagem) {
    const container = document.querySelector('.content-container');
    if (container) {
        container.innerHTML = `<div class="error-message" style="color:#ff4444;text-align:center;padding:20px;">
            ${mensagem}
        </div>`;
    }
}
