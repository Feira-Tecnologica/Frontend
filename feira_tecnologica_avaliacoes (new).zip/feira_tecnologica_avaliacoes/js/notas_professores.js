// Variáveis globais
let projetoAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    const btnConfirmar = document.getElementById('btnConfirmar');
    const confirmModal = document.getElementById('confirmModal');
    const successModal = document.getElementById('successModal');
    const btnSim = document.getElementById('btnSim');
    const btnNao = document.getElementById('btnNao');
    const btnOk = document.getElementById('btnOk');

    // Carregar informações do projeto (pode vir da URL ou localStorage)
    carregarProjeto();

    // Abrir o modal quando clicar em "Confirmar"
    btnConfirmar.addEventListener('click', function() {
        if (validarNotas()) {
            atualizarPreviewMedia();
            confirmModal.classList.add('show');
        }
    });

    // Fechar o modal quando clicar em "Não"
    btnNao.addEventListener('click', function() {
        confirmModal.classList.remove('show');
    });

    // Quando clicar em "Sim"
    btnSim.addEventListener('click', function() {
        enviarNotas();
    });

    // Quando clicar em "OK" no modal de sucesso
    btnOk.addEventListener('click', function() {
        successModal.classList.remove('show');
        // Redirecionar para revisão de notas
        window.location.href = 'revisao_notas.html';
    });

    // Fechar os modais se clicar fora deles
    window.addEventListener('click', function(event) {
        if (event.target === confirmModal) {
            confirmModal.classList.remove('show');
        }
        if (event.target === successModal) {
            successModal.classList.remove('show');
        }
    });
});

function carregarProjeto() {
    // Verificar se há um ID de projeto na URL ou localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const idProjeto = urlParams.get('id') || localStorage.getItem('projeto_avaliacao');
    
    if (idProjeto) {
        buscarDadosProjeto(idProjeto);
    } else {
        // Se não há projeto específico, pode carregar uma lista ou mostrar erro
        console.warn('Nenhum projeto selecionado para avaliação');
    }
}

async function buscarDadosProjeto(idProjeto) {
    try {
        console.log('Buscando projeto com ID:', idProjeto);
        
        // Buscar todos os projetos e filtrar pelo ID
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos');

        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const responseText = await response.text();
        console.log('Resposta da API:', responseText);

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (e) {
            console.error('Erro ao parsear JSON:', e);
            throw new Error('Resposta inválida do servidor');
        }

        // Normalizar o formato da resposta
        let projetos = [];
        if (Array.isArray(data)) {
            projetos = data;
        } else if (data && Array.isArray(data.data)) {
            projetos = data.data;
        } else if (data && Array.isArray(data.projetos)) {
            projetos = data.projetos;
        }

        // Encontrar o projeto pelo ID
        projetoAtual = projetos.find(p => String(p.id_projeto) === String(idProjeto));
        
        if (projetoAtual) {
            console.log('Projeto encontrado:', projetoAtual);
            atualizarInterfaceProjeto();
            // Carregar notas existentes se houver
            carregarNotasExistentes();
        } else {
            console.error('Projeto não encontrado com ID:', idProjeto);
            alert('Projeto não encontrado');
        }

    } catch (error) {
        console.error('Erro ao buscar dados do projeto:', error);
        alert('Erro ao carregar dados do projeto: ' + error.message);
    }
}

function atualizarInterfaceProjeto() {
    if (!projetoAtual) return;

    console.log('Atualizando interface com projeto:', projetoAtual);

    // Atualizar título do projeto
    const tituloElement = document.querySelector('.atribuir-nota h1');
    if (tituloElement) {
        tituloElement.innerHTML = `<strong>${projetoAtual.titulo_projeto || 'Projeto sem título'}</strong>`;
    }

    // Atualizar informações do stand
    const standElement = document.querySelector('.stand-info .stand-text');
    if (standElement) {
        standElement.innerHTML = `
            <strong>STAND ${projetoAtual.posicao || '24'}</strong>
            <p>${projetoAtual.turma || 'Turma não definida'}<br>Manhã</p>
        `;
    } else {
        console.warn('Elemento .stand-info .stand-text não encontrado');
        // Tentar atualizar de forma mais direta
        const standDiv = document.querySelector('.stand-info');
        if (standDiv) {
        }
    }
}

async function carregarNotasExistentes() {
    const usuarioLogado = JSON.parse(sessionStorage.getItem('usuario') || '{}');
    if (!usuarioLogado.usuario || !usuarioLogado.usuario.id_professor || !projetoAtual) {
        return;
    }

    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/notas/buscar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id_professor: usuarioLogado.usuario.id_professor,
                id_projeto: projetoAtual.id_projeto
            })
        });

        if (response.ok) {
            const nota = await response.json();
            console.log('Nota existente encontrada:', nota);
            preencherFormularioComNotas(nota);
        } else if (response.status === 404) {
            console.log('Nenhuma nota existente encontrada - projeto novo para avaliação');
        } else {
            console.error('Erro ao buscar notas existentes');
        }
    } catch (error) {
        console.error('Erro ao carregar notas existentes:', error);
    }
}

function preencherFormularioComNotas(nota) {
    const inputs = document.querySelectorAll('.form-control');
    const criterios = ['oralidade', 'postura', 'organizacao', 'criatividade', 'capricho', 'dominio', 'abordagem'];
    
    inputs.forEach((input, index) => {
        const criterio = criterios[index];
        if (nota[criterio] !== undefined) {
            input.value = nota[criterio];
        }
    });
    
    // Atualizar título para indicar que é uma edição
    const tituloElement = document.querySelector('.atribuir-nota h1');
    if (tituloElement && nota.media) {
        tituloElement.innerHTML = `<strong>${projetoAtual.titulo_projeto || 'Projeto sem título'}</strong><small style="color: #666;">(Editando avaliação - Média atual: ${nota.media})</small>`;
    }

    // Alterar texto do botão
    const btnConfirmar = document.getElementById('btnConfirmar');
    if (btnConfirmar) {
        btnConfirmar.textContent = 'Atualizar Avaliação';
    }
}

function validarNotas() {
    const inputs = document.querySelectorAll('.form-control');
    let todasValidas = true;
    let soma = 0;
    let count = 0;
    
    inputs.forEach(input => {
        const valor = parseFloat(input.value);
        if (isNaN(valor) || valor < 0 || valor > 10) {
            todasValidas = false;
            input.style.borderColor = '#ff4444';
        } else {
            input.style.borderColor = '';
            soma += valor;
            count++;
        }
    });

    if (!todasValidas) {
        mostrarToast('Por favor, preencha todas as notas com valores entre 0 e 10.');
    }

    return todasValidas;
}

function atualizarPreviewMedia(){
    const inputs = document.querySelectorAll('.form-control');
    let soma = 0; let count = 0;
    inputs.forEach(i=>{ const v=parseFloat(i.value); if(!isNaN(v)){ soma+=v; count++; } });
    if(count === 7){
        const media = (soma / 7).toFixed(1);
        console.log('Média prévia:', media);
    }
}

// Cria um pequeno toast reutilizável
function mostrarToast(msg){
    let toast = document.getElementById('app-toast');
    if(!toast){
        toast = document.createElement('div');
        toast.id = 'app-toast';
        toast.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:10px 18px;border-radius:6px;font-size:14px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,.25);opacity:0;transition:opacity .3s';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    requestAnimationFrame(()=>{ toast.style.opacity = '1'; });
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(()=>{ toast.style.opacity='0'; }, 3000);
}

async function enviarNotas() {
    if (!projetoAtual) {
    mostrarToast('Erro: Projeto não identificado.');
        return;
    }

    // Obter dados do professor logado
    const usuarioLogado = JSON.parse(sessionStorage.getItem('usuario') || '{}');
    if (!usuarioLogado.usuario || !usuarioLogado.usuario.id_professor) {
    mostrarToast('Erro: Professor não identificado. Faça login novamente.');
        return;
    }

    // Capturar valores dos inputs
    const inputs = document.querySelectorAll('.form-control');
    const valores = {};
    
    inputs.forEach((input, index) => {
        const criterios = ['oralidade', 'postura', 'organizacao', 'criatividade', 'capricho', 'dominio', 'abordagem'];
        valores[criterios[index]] = parseFloat(input.value);
    });

    const dadosNota = {
        id_projeto: projetoAtual.id_projeto,
        id_professor: usuarioLogado.usuario.id_professor,
        criatividade: valores.criatividade,
        capricho: valores.capricho,
        abordagem: valores.abordagem,
        dominio: valores.dominio,
        postura: valores.postura,
        oralidade: valores.oralidade,
        organizacao: valores.organizacao,
        comentario: '' // Pode adicionar um campo de comentário se necessário
    };

    console.log('Enviando dados da nota:', dadosNota);

    try {
        const apiBase2 = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase2 + '/api/notas/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dadosNota)
        });

        const resultado = await response.json();
        console.log('Resposta do servidor:', resultado);

        if (response.ok) {
            // Fechar modal de confirmação
            document.getElementById('confirmModal').classList.remove('show');
            
            // Mostrar modal de sucesso
            document.getElementById('successModal').classList.add('show');
            
            // Mostrar a média e menção se disponível
            if (resultado.media && resultado.mencao) {
                console.log(`Média: ${resultado.media}, Menção: ${resultado.mencao}`);
            }
        } else {
            console.error('Erro do servidor:', response.status, resultado);
        mostrarToast('Erro ao salvar notas: ' + (resultado.erro || resultado.mensagem || 'Erro desconhecido'));
            document.getElementById('confirmModal').classList.remove('show');
        }
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarToast('Erro de conexão. Tente novamente.');
        document.getElementById('confirmModal').classList.remove('show');
    }
}
