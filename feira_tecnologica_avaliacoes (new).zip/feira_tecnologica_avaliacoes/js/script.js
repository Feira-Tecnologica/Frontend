 // ---------------- INTRO VÍDEO + BACKGROUND ----------------
      document.addEventListener("DOMContentLoaded", function () {
        const introContainer = document.getElementById("intro-video-container");
        const introVideo = document.getElementById("intro-video");
        const banner = document.querySelector(".banner");
        const bannerText = document.querySelector(".banner-text");

        function atualizarBannerBackground() {
          let isMobile = window.innerWidth <= 768;

          if (isMobile) {
            banner.style.backgroundImage = "url('img/backgroundpkt.png')";
            bannerText.style.textAlign = "center";
            bannerText.style.margin = "0 auto";
            bannerText.style.alignItems = "center";
            bannerText.style.justifyContent = "center";
            bannerText.style.display = "flex";
            bannerText.style.flexDirection = "column";
            bannerText.style.height = "100%";
            bannerText.style.marginTop = "250px";
          } else {
            banner.style.backgroundImage = "url('img/backgroundbnr.png')";
            bannerText.style.textAlign = "left";
            bannerText.style.margin = "0";
            bannerText.style.alignItems = "flex-start";
            bannerText.style.justifyContent = "flex-start";
            bannerText.style.display = "flex";
            bannerText.style.flexDirection = "column";
            bannerText.style.marginTop = "40px";
          }
        }

        atualizarBannerBackground();
        window.addEventListener("resize", atualizarBannerBackground);

        // bloqueia scroll enquanto o vídeo está visível
        document.body.classList.add("block-scroll");

        // remove vídeo com fade-out
        const removeIntro = () => {
          introContainer.classList.add("fade-out");
          setTimeout(() => {
            introContainer.remove();
            document.body.classList.remove("block-scroll");
          }, 1000);
        };

        introVideo.addEventListener("ended", removeIntro);
        setTimeout(removeIntro, 7000);
      });

      // ---------------- FADE-IN PARA GALERIA ----------------
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            const el = entry.target;
            if (entry.isIntersecting) {
              el.classList.add("visible");
              el.classList.remove("hidden");
            } else {
              el.classList.remove("visible");
              el.classList.add("hidden");
            }
          });
        },
        { threshold: 0.2 }
      );

      document.querySelectorAll(".galeria-item").forEach((item) => {
        observer.observe(item);
      });

      // ---------------- RELOAD AO MUDAR ENTRE CELULAR E PC ----------------
      let isMobile = window.innerWidth <= 768;
      window.addEventListener("resize", () => {
        const currentlyMobile = window.innerWidth <= 768;
        if (currentlyMobile !== isMobile) location.reload();
        isMobile = currentlyMobile;
      });

      // ---------------- CARREGAR PROJETOS ----------------
      async function carregarProjetos() {
        try {
          const res = await fetch("Backend/api/postagem");
          if (!res.ok) throw new Error("Erro ao buscar projetos");
          const projetos = await res.json();
          const container = document.getElementById("galeria-container");
          container.innerHTML = "";

          projetos.forEach((proj, index) => {
            container.innerHTML += `
              <div class="galeria-item">
                <div class="carousel">
                  <div class="carousel-wrapper">
                    <img src="data:image/png;base64,${proj.png_b64}" class="carousel-img active" alt="Imagem ${
              index + 1
            }">
                  </div>
                  <div class="slide-count">1 / 1</div>
                </div>
                <div class="descricao">
                  <h3>${proj.legenda || "Sem legenda"}</h3>
                  <span>${proj.data || ""}</span><br>
                </div>
              </div>`;
          });
        } catch (err) {
          console.error(err);
        }
      }

      carregarProjetos();