// Variáveis globais
let projetoAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    carregarProjeto();
});

function carregarProjeto() {
    // Verificar se há um ID de projeto na URL ou localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const idProjeto = urlParams.get('id') || localStorage.getItem('projeto_visualizacao');
    console.log('Visualizar Projeto ID:', idProjeto);
    if (idProjeto) {
        buscarDadosProjeto(idProjeto);
    } else {
        mostrarErro('Nenhum projeto selecionado para visualização');
    }
}

async function buscarDadosProjeto(idProjeto) {
    console.log('Buscando dados do projeto com ID:', idProjeto);
    try {
        // Busca direta pelo GET /api/projetos e seleciona o projeto pelo id (sem depender de rota POST inexistente)
    const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
    const listResp = await fetch(apiBase + '/api/projetos');
        if (!listResp.ok) {
            const txt = await listResp.text();
            console.error('GET /api/projetos retornou erro:', listResp.status, txt);
            mostrarErro('Não foi possível carregar os dados do projeto.');
            return;
        }

        const listText = await listResp.text();
        let listData;
        try {
            listData = JSON.parse(listText);
        } catch (e) {
            console.error('Erro ao parsear resposta de /api/projetos:', e, listText);
            mostrarErro('Resposta inválida do servidor ao obter lista de projetos.');
            return;
        }

        // Normalizar formatos possíveis: array direto, { status:'success', data: [...] }, { projetos: [...] }
        let projetosLista = [];
        if (Array.isArray(listData)) {
            projetosLista = listData;
        } else if (listData && Array.isArray(listData.data)) {
            projetosLista = listData.data;
        } else if (listData && Array.isArray(listData.projetos)) {
            projetosLista = listData.projetos;
        } else {
            console.warn('Formato inesperado para lista de projetos:', listData);
        }

        // Procurar pelo projeto pelo id (string ou number)
        const found = projetosLista.find(p => String(p.id_projeto) === String(idProjeto) || String(p.id) === String(idProjeto));
        if (found) {
            projetoAtual = found;
            atualizarInterface();
            return;
        }

        // Se não encontrou, tenta também buscar por título como último recurso
        const foundByTitle = projetosLista.find(p => p.titulo_projeto && p.titulo_projeto.toLowerCase().includes(String(idProjeto).toLowerCase()));
        if (foundByTitle) {
            projetoAtual = foundByTitle;
            atualizarInterface();
            return;
        }

        mostrarErro('Projeto não encontrado.');
        return;
    } catch (error) {
        console.error('Erro na requisição:', error);
        mostrarErro('Erro de conexão');
    }
}

// Função para exibir erros na tela
function mostrarErro(mensagem) {
    console.error(mensagem);
    const container = document.querySelector('.content-container');
    if (container) {
        const erro = document.createElement('div');
        erro.className = 'error-message';
        erro.style.textAlign = 'center';
        erro.style.padding = '20px';
        erro.style.color = '#ff4444';
        erro.innerHTML = `<p>${mensagem}</p>`;
        container.innerHTML = '';
        container.appendChild(erro);
    }
}

function atualizarInterface() {
    if (!projetoAtual) return;

    // Extrair descrição, objetivo e justificativa de uma única descrição
    const fullDesc = projetoAtual.descricao || '';
    let descText = fullDesc;
    let objText = '';
    let justText = '';
    const objMatch = /Objetivo[:]?/i.exec(fullDesc);
    const justMatch = /Justificativa[:]?/i.exec(fullDesc);
    if (objMatch) {
        const objIndex = objMatch.index;
        descText = fullDesc.substring(0, objIndex).trim();
        if (justMatch) {
            objText = fullDesc.substring(objIndex + objMatch[0].length, justMatch.index).trim();
            justText = fullDesc.substring(justMatch.index + justMatch[0].length).trim();
        } else {
            objText = fullDesc.substring(objIndex + objMatch[0].length).trim();
        }
    }

    // Atualizar título do projeto
    const tituloElement = document.querySelector('.project-name');
    if (tituloElement) {
        tituloElement.textContent = projetoAtual.titulo_projeto || 'Projeto sem título';
    }

    // Atualizar informações do stand
    const standElement = document.querySelector('.stand-info strong');
    if (standElement) {
        standElement.textContent = `STAND ${projetoAtual.posicao || 'N/A'}`;
    }

    const turmaElement = document.querySelector('.class-info span');
    if (turmaElement) {
        turmaElement.innerHTML = `${projetoAtual.turma || 'Turma não definida'}<br>`;
    }

    // Atualizar integrantes
    atualizarIntegrantes();

    // Atualizar descrição
    const descricaoElement = document.getElementById('descricao-content');
    if (descricaoElement) {
        descricaoElement.textContent = descText || 'Descrição não disponível';
    }

    // Atualizar objetivo
    const objetivoElement = document.getElementById('objetivo-content');
    if (objetivoElement) {
        objetivoElement.textContent = objText || 'Objetivo não definido';
    }

    // Atualizar justificativa
    const justificativaElement = document.getElementById('justificativa-content');
    if (justificativaElement) {
        justificativaElement.textContent = justText || 'Justificativa não definida';
    }

    // Atualizar ODS
    atualizarODS();
    
    // Atualizar links de edição
    atualizarLinksEdicao();
}

function atualizarIntegrantes() {
    const integrantesContainer = document.querySelector('.integrantes-display');
    if (!integrantesContainer) return;

    integrantesContainer.innerHTML = '';

    // Se já vierem os integrantes no objeto do projeto, usa direto
    if (projetoAtual.integrantes) {
        const integrantes = projetoAtual.integrantes.split(', ');
        integrantes.forEach(nome => {
            const card = document.createElement('div');
            card.className = 'integrante-card';
            card.textContent = nome.trim();
            integrantesContainer.appendChild(card);
        });
        return;
    }

    // Buscar alunos usando a rota correta do backend
    if (projetoAtual.id_projeto) {
        const apiBaseInt = (window.BASE_URL || '').replace(/\/$/, '');
        fetch(apiBaseInt + '/api/projetos/alunos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_projeto: projetoAtual.id_projeto
            })
        })
        .then(resp => {
            if (!resp.ok) throw new Error('Erro ao obter integrantes');
            return resp.json();
        })
        .then(data => {
            if (!Array.isArray(data) || data.length === 0) {
                integrantesContainer.innerHTML = '<p style="color: #666;">Nenhum integrante cadastrado</p>';
                return;
            }

            data.forEach(aluno => {
                const card = document.createElement('div');
                card.className = 'integrante-card';
                card.textContent = aluno.nome_aluno || aluno.nome || aluno.id_aluno;
                integrantesContainer.appendChild(card);
            });
        })
        .catch(err => {
            console.error('Falha ao carregar integrantes:', err);
            integrantesContainer.innerHTML = '<p style="color: #666;">Nenhum integrante cadastrado</p>';
        });
        return;
    }

    integrantesContainer.innerHTML = '<p style="color: #666;">Nenhum integrante cadastrado</p>';
}

function atualizarODS() {
    const odsContainer = document.getElementById('ods-display');
    if (!odsContainer) return;

    odsContainer.innerHTML = '';

    // Se o projeto já traz dados das ODS, usa-os
    if (projetoAtual.ods_ids && projetoAtual.ods_nomes) {
        const odsIds = projetoAtual.ods_ids.split(',');
        const odsNomes = projetoAtual.ods_nomes.split(' | ');
        const odsColors = {
            '1': '#E5243B', '2': '#DDA83A', '3': '#4C9F38', '4': '#C5192D', '5': '#FF3A21',
            '6': '#26BDE2', '7': '#FCC30B', '8': '#A21942', '9': '#FD6925', '10': '#DD1367',
            '11': '#FD9D24', '12': '#BF8B2E', '13': '#3F7E44', '14': '#0A97D9', '15': '#56C02B',
            '16': '#00689D', '17': '#19486A'
        };
        odsIds.forEach((id, index) => {
            if (odsNomes[index]) {
                const odsItem = document.createElement('div');
                odsItem.className = 'ods-item-display';
                odsItem.innerHTML = `
                    <div class="ods-icon" style="background-color: ${odsColors[id.trim()] || '#666'}">${id.trim()}</div>
                    <div class="ods-info">
                        <strong>ODS ${id.trim()} - ${odsNomes[index].trim()}</strong>
                    </div>
                `;
                odsContainer.appendChild(odsItem);
            }
        });
        return;
    }

    // Buscar ODS usando a rota correta do backend
    if (projetoAtual.id_projeto) {
        const apiBaseOds = (window.BASE_URL || '').replace(/\/$/, '');
        fetch(apiBaseOds + '/api/projetos/ods-projeto', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_projeto: projetoAtual.id_projeto
            })
        })
        .then(resp => {
            if (!resp.ok) throw new Error('Erro ao obter ODS');
            return resp.json();
        })
        .then(data => {
                if (!Array.isArray(data) || data.length === 0) {
                    odsContainer.innerHTML = '<p style="color: #666;">Nenhuma ODS associada ao projeto</p>';
                    return;
                }

                const odsColors = {
                    '1': '#E5243B', '2': '#DDA83A', '3': '#4C9F38', '4': '#C5192D', '5': '#FF3A21',
                    '6': '#26BDE2', '7': '#FCC30B', '8': '#A21942', '9': '#FD6925', '10': '#DD1367',
                    '11': '#FD9D24', '12': '#BF8B2E', '13': '#3F7E44', '14': '#0A97D9', '15': '#56C02B',
                    '16': '#00689D', '17': '#19486A'
                };

                data.forEach(item => {
                    const id = String(item.id_ods || item.id);
                    const name = item.nome || '';
                    const odsItem = document.createElement('div');
                    odsItem.className = 'ods-item-display';
                    odsItem.innerHTML = `
                        <div class="ods-icon" style="background-color: ${odsColors[id.trim()] || '#666'}">${id.trim()}</div>
                        <div class="ods-info">
                            <strong>ODS ${id.trim()}${name ? ' - ' + name : ''}</strong>
                        </div>
                    `;
                    odsContainer.appendChild(odsItem);
                });
            })
            .catch(err => {
                console.error('Falha ao carregar ODS:', err);
                odsContainer.innerHTML = '<p style="color: #666;">Nenhuma ODS associada ao projeto</p>';
            });
        return;
    }

    odsContainer.innerHTML = '<p style="color: #666;">Nenhuma ODS associada ao projeto</p>';
}

function atualizarLinksEdicao() {
    if (!projetoAtual) return;
    
    // Atualizar todos os links de edição para incluir o ID do projeto
    const editLinks = document.querySelectorAll('a[href*="editar_projeto"], button[onclick*="editar"]');
    editLinks.forEach(link => {
        if (link.tagName === 'A') {
            link.href = `editar_projeto.html?id=${projetoAtual.id_projeto}`;
        } else if (link.tagName === 'BUTTON') {
            link.onclick = () => window.location.href = `editar_projeto.html?id=${projetoAtual.id_projeto}`;
        }
    });
    
    // Atualizar especificamente o botão de editar
    const editButton = document.querySelector('.btn-edit');
    if (editButton) {
        editButton.onclick = () => window.location.href = `editar_projeto.html?id=${projetoAtual.id_projeto}`;
    }
}

async function verificarNotas() {
    try {
    const apiBaseNotas = (window.BASE_URL || '').replace(/\/$/, '');
    const response = await fetch(apiBaseNotas + '/api/notas/buscar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id_projeto: projetoAtual.id_projeto })
        });

        if (response.ok) {
            const dadosNota = await response.json();
            if (dadosNota.criatividade !== null) {
                mostrarNotas(dadosNota);
            }
        }
    } catch (error) {
        console.error('Erro ao verificar notas:', error);
    }
}

function mostrarNotas(dadosNota) {
    // Criar seção de notas se não existir
    let secaoNotas = document.querySelector('.secao-notas');
    if (!secaoNotas) {
        secaoNotas = document.createElement('div');
        secaoNotas.className = 'section secao-notas';
        secaoNotas.innerHTML = `
            <h4 class="section-title">
                <i class="material-icons">grade</i>
                Avaliação
            </h4>
            <div class="notas-container"></div>
        `;
        
        const projectContent = document.querySelector('.project-content');
        if (projectContent) {
            projectContent.appendChild(secaoNotas);
        }
    }

    const notasContainer = secaoNotas.querySelector('.notas-container');
    if (notasContainer) {
        notasContainer.innerHTML = `
            <div class="notas-grid">
                <div class="nota-item">
                    <span>Criatividade:</span>
                    <span class="nota-valor">${dadosNota.criatividade}</span>
                </div>
                <div class="nota-item">
                    <span>Capricho:</span>
                    <span class="nota-valor">${dadosNota.capricho}</span>
                </div>
                <div class="nota-item">
                    <span>Abordagem:</span>
                    <span class="nota-valor">${dadosNota.abordagem}</span>
                </div>
                <div class="nota-item">
                    <span>Domínio:</span>
                    <span class="nota-valor">${dadosNota.dominio}</span>
                </div>
                <div class="nota-item">
                    <span>Postura:</span>
                    <span class="nota-valor">${dadosNota.postura}</span>
                </div>
                <div class="nota-item">
                    <span>Oralidade:</span>
                    <span class="nota-valor">${dadosNota.oralidade}</span>
                </div>
                <div class="nota-resumo">
                    <div class="media-final">
                        <span>Média:</span>
                        <span class="nota-valor destaque">${dadosNota.media}</span>
                    </div>
                    <div class="mencao-final">
                        <span>Menção:</span>
                        <span class="mencao-valor destaque">${dadosNota.mencao}</span>
                    </div>
                </div>
                ${dadosNota.comentario ? `
                    <div class="comentario">
                        <strong>Comentário:</strong>
                        <p>${dadosNota.comentario}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }
}
