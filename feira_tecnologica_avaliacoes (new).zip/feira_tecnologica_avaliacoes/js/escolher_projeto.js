// Variáveis globais
let projetos = [];
let projetosFiltrados = [];

document.addEventListener("DOMContentLoaded", function () {
  exibirSaudacaoUsuario();
  carregarProjetos();
  configurarPesquisa();
});

async function carregarProjetos() {
  try {
    console.log("Iniciando carregamento de projetos...");
    const url = window.BASE_URL + "/api/projetos";
    console.log("URL da requisição:", url);

    const response = await fetch(url);
    console.log("Status da resposta:", response.status);
    console.log("Headers:", [...response.headers.entries()]);

    const responseText = await response.text();
    console.log("Resposta bruta:", responseText);

    let data;
    try {
      data = JSON.parse(responseText);
      console.log("Dados parseados:", data);
    } catch (e) {
      console.error("Erro ao fazer parse do JSON:", e);
      mostrarMensagemErro("Erro ao processar resposta do servidor");
      return;
    }

    // Compatibilidade com diferentes formatos de resposta do backend:
    // 1) Array simples: [ { ... }, ... ]
    // 2) Objeto com { status: 'success', data: [...] }
    // 3) Objeto com { projetos: [...] }
    let projetosData = [];
    if (Array.isArray(data)) {
      projetosData = data;
    } else if (data && data.status === "success" && Array.isArray(data.data)) {
      projetosData = data.data;
    } else if (data && Array.isArray(data.projetos)) {
      projetosData = data.projetos;
    }

    if (response.ok) {
      // Aceita tanto array simples quanto objeto com status 'success'
      if (
        Array.isArray(data) ||
        (data && data.status === "success") ||
        Array.isArray(data.projetos)
      ) {
        projetos = projetosData;
        projetosFiltrados = [...projetos];
        console.log("Projetos processados:", projetos);
        renderizarProjetos();
      } else {
        console.error("Resposta com formato inesperado:", data);
        mostrarMensagemErro(data.mensagem || "Formato de resposta inválido");
      }
    } else {
      console.error("Erro da API:", data);
      mostrarMensagemErro(data.mensagem || "Erro ao carregar projetos");
    }
  } catch (error) {
    console.error("Erro completo:", error);
    mostrarMensagemErro(
      "Erro de conexão. Verifique o console para mais detalhes."
    );
  }
}

function renderizarProjetos() {
  const grid =
    document.querySelector(".projects-grid") ||
    document.querySelector(".content-container");

  // Limpar grid
  grid.innerHTML = "";

  if (projetosFiltrados.length === 0) {
    const mensagem = document.createElement("div");
    mensagem.className = "no-projects";
    mensagem.innerHTML = "<p>Nenhum projeto encontrado.</p>";
    grid.appendChild(mensagem);
    return;
  }

  // Criar cards para cada projeto
  projetosFiltrados.forEach((projeto) => {
    const card = criarCardProjeto(projeto);
    grid.appendChild(card);
  });
}

function criarCardProjeto(projeto) {
  const card = document.createElement("div");
  card.className = "project-card";

  // Identificação de professor/aluno pela sessão
  const stored = sessionStorage.getItem("usuario");
  let isProfessor = false;
  if (stored) {
    const data = JSON.parse(stored);
    const user = data.usuario || data;
    if (user.matricula) isProfessor = true;
  }

  // Exibir criador (primeiro integrante ou orientador)
  let criador = "Não definido";
  if (projeto.integrantes && projeto.integrantes.trim() !== "") {
    criador = projeto.integrantes.split(", ")[0];
  } else if (projeto.orientador && projeto.orientador.trim() !== "") {
    criador = projeto.orientador;
  }

  // Botões de ação: Visualizar sempre, Avaliar apenas para professor
  let actionButtons = `<button class="btn-enter" onclick="visualizarProjeto('${projeto.id_projeto}')">Visualizar</button>`;
  if (isProfessor) {
    actionButtons += `<button class="btn-avaliar" onclick="avaliarProjeto('${projeto.id_projeto}')">Avaliar</button>`;
  }
  card.innerHTML = `
        <h3>${projeto.titulo_projeto}</h3>
        <p>Criador: ${criador}</p>
        <p>Orientador: ${projeto.orientador || "N/A"}</p>
        <p>STAND ${projeto.posicao || "N/A"}</p>
        <div class="card-actions">
            ${actionButtons}
        </div>
    `;

  return card;
}

function configurarPesquisa() {
  const inputPesquisa = document.querySelector(".search input");
  if (inputPesquisa) {
    inputPesquisa.addEventListener("input", function (e) {
      const termo = e.target.value.toLowerCase();
      filtrarProjetos(termo);
    });
  }
}

function filtrarProjetos(termo) {
  if (!termo) {
    projetosFiltrados = [...projetos];
  } else {
    projetosFiltrados = projetos.filter(
      (projeto) =>
        projeto.titulo_projeto.toLowerCase().includes(termo) ||
        (projeto.integrantes &&
          projeto.integrantes.toLowerCase().includes(termo)) ||
        (projeto.orientador && projeto.orientador.toLowerCase().includes(termo))
    );
  }
  renderizarProjetos();
}

function visualizarProjeto(idProjeto) {
  // Salvar ID do projeto para usar na página de visualização
  localStorage.setItem("projeto_visualizacao", idProjeto);
  window.location.href = "visualizar_projeto.html";
}

function avaliarProjeto(idProjeto) {
  // Salvar ID do projeto para usar na página de avaliação
  localStorage.setItem("projeto_avaliacao", idProjeto);
  window.location.href = "notas_professores.html";
}

function abrirProjeto(nome) {
  // Função mantida para compatibilidade
  alert("Abrindo: " + nome);
}

function mostrarMensagemErro(mensagem) {
  const grid =
    document.querySelector(".projects-grid") ||
    document.querySelector(".content-container");
  const erro = document.createElement("div");
  erro.className = "error-message";
  erro.innerHTML = `<p>${mensagem}</p>`;
  grid.appendChild(erro);
}

// Exibe nome do usuário logado na saudação
function exibirSaudacaoUsuario() {
  const saudacaoElem = document.querySelector(".content-container h2");
  const usuarioStr = sessionStorage.getItem("usuario");
  if (usuarioStr && saudacaoElem) {
    const data = JSON.parse(usuarioStr);
    const usuario = data.usuario || data;
    // Suporta formatos retornados pelo backend:
    // - aluno: campo 'nome_aluno'
    // - professor: campo 'nome_professor'
    // - genérico/antigo: campo 'nome'
    const nome =
      usuario.nome || usuario.nome_aluno || usuario.nome_professor || "Usuário";
    saudacaoElem.textContent = `Olá, ${nome}!`;
  }
}

// Logout: limpa storage de sessão/local e redireciona para página de login
function logout() {
  // limpar session e local storage relevantes
  try {
    sessionStorage.removeItem("usuario");
    localStorage.removeItem("projeto_visualizacao");
    localStorage.removeItem("projeto_avaliacao");
  } catch (e) {
    console.warn("Erro ao limpar storage:", e);
  }
  // redireciona para a página de login de alunos (usar a apropriada se for professor)
  window.location.href = "escolha-login.html";
}

// Expose to global scope for inline onclick handlers
window.logout = logout;

document.addEventListener("DOMContentLoaded", () => {
  carregarPublicacoes();
});

async function carregarPublicacoes() {
  const container = document.querySelector(".pub-grid");
  if (!container) return; // garante que o container exista
  container.innerHTML = "<p>Carregando...</p>";

  // pegar id do aluno AQUI dentro da função
  const inputAluno = document.getElementById("id_aluno");
  if (!inputAluno) {
    container.innerHTML = "<p>Erro: id do aluno não encontrado.</p>";
    console.error("Input #id_aluno não encontrado no DOM");
    return;
  }
  const idAluno = inputAluno.value;
  console.log("idAluno logado:", idAluno);

  try {
    // ajustar o caminho da API pra ter extensão se necessário
    const res = await fetch("Backend/api/postagem");
    if (!res.ok) throw new Error("Erro ao buscar publicações");

    // debug: ver resposta bruta
    const resText = await res.text();
    console.log("Resposta bruta da API:", resText);

    let publicacoes;
    try {
      publicacoes = JSON.parse(resText);
    } catch (e) {
      console.error("Erro ao fazer parse do JSON:", e);
      container.innerHTML = "<p>Erro ao processar resposta do servidor.</p>";
      return;
    }

    console.log("Publicações recebidas:", publicacoes);

    const minhas = publicacoes.filter(
      (pub) => String(pub.id_usuario || pub.id_aluno) === String(idAluno)
    );

    container.innerHTML = "";

    if (minhas.length === 0) {
      container.innerHTML = "<p>Você ainda não tem publicações.</p>";
      return;
    }

    minhas.forEach((pub, index) => {
      const card = document.createElement("div");
      card.classList.add("pub-card");

      const base64Img = pub.png_b64 || pub.imagem || "";

      card.innerHTML = `
        <div class="carousel">
          <div class="carousel-wrapper">
            <img src="data:image/png;base64,${base64Img}" class="carousel-img active" alt="Imagem ${
        index + 1
      }">
          </div>
          <div class="slide-count">1 / 1</div>
        </div>
        <div class="descricao">
          <h3>${pub.legenda || "Sem legenda"}</h3>
          <span>${pub.data || ""}</span><br>
          <button class="btn-delete" data-id="${
            pub.id_postagem || pub.id
          }">Excluir</button>
        </div>
      `;

      container.appendChild(card);
    });

    // adiciona evento aos botões de excluir
    document.querySelectorAll(".btn-delete").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        const idPost = e.target.dataset.id;
        if (!confirm("Deseja realmente excluir esta publicação?")) return;

        try {
          const res = await fetch("Backend/api/postagem/deletar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id_postagem: idPost }),
          });

          const data = await res.json();
          alert(data.mensagem || data.erro || "Erro ao excluir");

          carregarPublicacoes(); // recarrega a lista
        } catch (err) {
          console.error(err);
          alert("Erro ao excluir publicação.");
        }
      });
    });
  } catch (err) {
    console.error(err);
    container.innerHTML = "<p>Erro ao carregar publicações.</p>";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  carregarPublicacoes();
});
