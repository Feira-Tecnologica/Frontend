// Garante que exista um BASE_URL definido (de Backend/config.js.php).
// Se não estiver definido, aplica um fallback para facilitar debug em desenvolvimento.
if (typeof window.BASE_URL === 'undefined' || !window.BASE_URL) {
  // Tenta ler de uma variável .env exposta (caso o backend não tenha carregado)
  // fallback primário: caminho relativo para Backend (útil em dev local)
  // fallback: tenta inferir a base a partir do origin do navegador
  const inferredBase = (location.origin ? location.origin : 'http://localhost') + '/feira_tecnologica_avaliacoes/Backend';
  window.BASE_URL = window.BASE_URL || window.API_BASE || inferredBase;
  console.warn('window.BASE_URL não estava definido. Aplicando fallback inferido:', window.BASE_URL);
} else {
  console.log('window.BASE_URL definido como', window.BASE_URL);
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginAlunoForm');
  const erroLogin = document.getElementById('erroLogin');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value.trim();
    const rm = document.getElementById('rm').value.trim();
    const senha = document.getElementById('senha').value;

    try {
      const endpoint = `${window.BASE_URL.replace(/\/$/, '')}/api/login/aluno`;
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, rm, senha })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Erro na resposta:', response.status, errorText);
        erroLogin.textContent = `Erro ${response.status}: ${errorText || 'Erro desconhecido'}`;
        return;
      }
      
      const data = await response.json();

      if (response.ok) {
        // Save user data in session storage or cookie
        sessionStorage.setItem('usuario', JSON.stringify(data));
        window.location.href = 'escolher_projeto.php';
      } else {
        erroLogin.textContent = data.message || 'Erro ao fazer login';
      }
    } catch (err) {
      console.error(err);
      erroLogin.textContent = 'Erro de rede. Tente novamente.';
    }
  });
});
