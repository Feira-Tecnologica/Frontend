<?php
  session_start(); 
  include('Backend/Config/connection.php');

  // se não tiver logado como aluno, joga pra login
  if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'aluno') {
      // header('Location: login_aluno.php');
      // exit();
  }
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Enviar Fotos</title>
  <link rel="stylesheet" href="css/CadImagem.css">
</head>

<body>
  <div class="container">
    <div class="upload-box">
      <div class="header">
        <a href="escolher_projeto.php" class="back-arrow">←</a>
        <h2>Enviar fotos</h2>
      </div>

      <form id="postForm">
        <label for="foto" class="upload-icon-label">
          <div class="upload-icon">📤</div>
        </label>
        <input type="file" name="png" accept="image/*" required id="foto" style="display: none;">

        <p class="upload-text">Selecione um ou mais arquivos do seu dispositivo.</p>

        <div id="file-preview" class="file-box" style="display: none;">
          <span class="file-name" id="file-name"></span>
          <button type="button" class="remove-file" onclick="removeFile()">✕</button>
        </div>

        <!-- input escondido com id do aluno -->
        <input type="hidden" id="id_usuario" name="id_usuario" value="<?php echo $_SESSION['id_aluno']; ?>">

        <div class="descricao-box">
          <label for="descricao">Legenda</label>
          <textarea type="text" name="legenda" id="descricao" placeholder="Adicione uma legenda da imagem do projeto..." required></textarea>
        </div>

        <div class="buttons">
          <button type="submit" class="enviar">Enviar</button>
          <button type="button" class="cancelar" onclick="removeFile()">Cancelar</button>
        </div>
      </form>

      <div id="resposta" style="margin-top:20px;color:blue;"></div>
    </div>
  </div>

  <script>
    const fileInput = document.getElementById('foto');
    const filePreview = document.getElementById('file-preview');
    const fileNameDisplay = document.getElementById('file-name');

    // preview do arquivo
    fileInput.addEventListener('change', () => {
      if (fileInput.files.length > 0) {
        fileNameDisplay.textContent = fileInput.files[0].name;
        filePreview.style.display = 'flex';
      }
    });

    // remover arquivo
    function removeFile() {
      fileInput.value = '';
      filePreview.style.display = 'none';
      fileNameDisplay.textContent = '';
    }

    // enviar form
    document.getElementById('postForm').addEventListener('submit', async (e) => {
      e.preventDefault();

      const legenda = document.getElementById('descricao').value.trim();
      const id_usuario = document.getElementById('id_usuario').value.trim();
      const file = fileInput.files[0];

      if (!file) {
        alert("Selecione uma imagem.");
        return;
      }
      if (!id_usuario) {
        alert("ID do usuário não encontrado.");
        return;
      }

      const base64 = await toBase64(file);

      try {
        const res = await fetch('Backend/api/postagem/criar', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            legenda: legenda,
            id_usuario: id_usuario,
            png: base64
          })
        });

        const data = await res.json();

        if (res.ok) {
          // redireciona pra página
          window.location.href = "escolher_projeto.php";
        } else {
          document.getElementById('resposta').textContent = JSON.stringify(data);
        }
      } catch (err) {
        document.getElementById('resposta').textContent = 'Erro ao enviar: ' + err;
      }
    });

    function toBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
      });
    }
  </script>
</body>
</html>
